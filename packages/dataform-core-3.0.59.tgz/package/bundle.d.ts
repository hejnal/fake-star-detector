import * as $protobuf from 'protobufjs';

declare function compile(code: string, path: string): string;

/** Namespace dataform. */
namespace dataform {

    /** Properties of a WorkflowSettings. */
    interface IWorkflowSettings {

        /** WorkflowSettings dataformCoreVersion */
        dataformCoreVersion?: (string|null);

        /** WorkflowSettings defaultProject */
        defaultProject?: (string|null);

        /** WorkflowSettings defaultDataset */
        defaultDataset?: (string|null);

        /** WorkflowSettings defaultLocation */
        defaultLocation?: (string|null);

        /** WorkflowSettings defaultAssertionDataset */
        defaultAssertionDataset?: (string|null);

        /** WorkflowSettings vars */
        vars?: ({ [k: string]: string }|null);

        /** WorkflowSettings projectSuffix */
        projectSuffix?: (string|null);

        /** WorkflowSettings datasetSuffix */
        datasetSuffix?: (string|null);

        /** WorkflowSettings namePrefix */
        namePrefix?: (string|null);

        /** WorkflowSettings defaultNotebookRuntimeOptions */
        defaultNotebookRuntimeOptions?: (dataform.INotebookRuntimeOptionsConfig|null);

        /** WorkflowSettings builtinAssertionNamePrefix */
        builtinAssertionNamePrefix?: (string|null);

        /** WorkflowSettings defaultIcebergConfig */
        defaultIcebergConfig?: (dataform.IDefaultIcebergConfig|null);

        /** WorkflowSettings disableAssertions */
        disableAssertions?: (boolean|null);

        /** WorkflowSettings defaultReservation */
        defaultReservation?: (string|null);

        /** WorkflowSettings extension */
        extension?: (dataform.IExtension|null);

        /** WorkflowSettings includeTestsInCompiledGraph */
        includeTestsInCompiledGraph?: (boolean|null);
    }

    /** Represents a WorkflowSettings. */
    class WorkflowSettings implements IWorkflowSettings {

        /**
         * Constructs a new WorkflowSettings.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IWorkflowSettings);

        /** WorkflowSettings dataformCoreVersion. */
        public dataformCoreVersion: string;

        /** WorkflowSettings defaultProject. */
        public defaultProject: string;

        /** WorkflowSettings defaultDataset. */
        public defaultDataset: string;

        /** WorkflowSettings defaultLocation. */
        public defaultLocation: string;

        /** WorkflowSettings defaultAssertionDataset. */
        public defaultAssertionDataset: string;

        /** WorkflowSettings vars. */
        public vars: { [k: string]: string };

        /** WorkflowSettings projectSuffix. */
        public projectSuffix: string;

        /** WorkflowSettings datasetSuffix. */
        public datasetSuffix: string;

        /** WorkflowSettings namePrefix. */
        public namePrefix: string;

        /** WorkflowSettings defaultNotebookRuntimeOptions. */
        public defaultNotebookRuntimeOptions?: (dataform.INotebookRuntimeOptionsConfig|null);

        /** WorkflowSettings builtinAssertionNamePrefix. */
        public builtinAssertionNamePrefix: string;

        /** WorkflowSettings defaultIcebergConfig. */
        public defaultIcebergConfig?: (dataform.IDefaultIcebergConfig|null);

        /** WorkflowSettings disableAssertions. */
        public disableAssertions: boolean;

        /** WorkflowSettings defaultReservation. */
        public defaultReservation: string;

        /** WorkflowSettings extension. */
        public extension?: (dataform.IExtension|null);

        /** WorkflowSettings includeTestsInCompiledGraph. */
        public includeTestsInCompiledGraph: boolean;

        /**
         * Creates a new WorkflowSettings instance using the specified properties.
         * @param [properties] Properties to set
         * @returns WorkflowSettings instance
         */
        public static create(properties?: dataform.IWorkflowSettings): dataform.WorkflowSettings;

        /**
         * Encodes the specified WorkflowSettings message. Does not implicitly {@link dataform.WorkflowSettings.verify|verify} messages.
         * @param message WorkflowSettings message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IWorkflowSettings, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified WorkflowSettings message, length delimited. Does not implicitly {@link dataform.WorkflowSettings.verify|verify} messages.
         * @param message WorkflowSettings message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IWorkflowSettings, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a WorkflowSettings message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns WorkflowSettings
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.WorkflowSettings;

        /**
         * Decodes a WorkflowSettings message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns WorkflowSettings
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.WorkflowSettings;

        /**
         * Verifies a WorkflowSettings message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a WorkflowSettings message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns WorkflowSettings
         */
        public static fromObject(object: { [k: string]: any }): dataform.WorkflowSettings;

        /**
         * Creates a plain object from a WorkflowSettings message. Also converts values to other types if specified.
         * @param message WorkflowSettings
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.WorkflowSettings, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this WorkflowSettings to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for WorkflowSettings
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a DefaultIcebergConfig. */
    interface IDefaultIcebergConfig {

        /** DefaultIcebergConfig bucketName */
        bucketName?: (string|null);

        /** DefaultIcebergConfig tableFolderRoot */
        tableFolderRoot?: (string|null);

        /** DefaultIcebergConfig tableFolderSubpath */
        tableFolderSubpath?: (string|null);

        /** DefaultIcebergConfig connection */
        connection?: (string|null);
    }

    /** Represents a DefaultIcebergConfig. */
    class DefaultIcebergConfig implements IDefaultIcebergConfig {

        /**
         * Constructs a new DefaultIcebergConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IDefaultIcebergConfig);

        /** DefaultIcebergConfig bucketName. */
        public bucketName: string;

        /** DefaultIcebergConfig tableFolderRoot. */
        public tableFolderRoot: string;

        /** DefaultIcebergConfig tableFolderSubpath. */
        public tableFolderSubpath: string;

        /** DefaultIcebergConfig connection. */
        public connection: string;

        /**
         * Creates a new DefaultIcebergConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns DefaultIcebergConfig instance
         */
        public static create(properties?: dataform.IDefaultIcebergConfig): dataform.DefaultIcebergConfig;

        /**
         * Encodes the specified DefaultIcebergConfig message. Does not implicitly {@link dataform.DefaultIcebergConfig.verify|verify} messages.
         * @param message DefaultIcebergConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IDefaultIcebergConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified DefaultIcebergConfig message, length delimited. Does not implicitly {@link dataform.DefaultIcebergConfig.verify|verify} messages.
         * @param message DefaultIcebergConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IDefaultIcebergConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a DefaultIcebergConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns DefaultIcebergConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.DefaultIcebergConfig;

        /**
         * Decodes a DefaultIcebergConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns DefaultIcebergConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.DefaultIcebergConfig;

        /**
         * Verifies a DefaultIcebergConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a DefaultIcebergConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns DefaultIcebergConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.DefaultIcebergConfig;

        /**
         * Creates a plain object from a DefaultIcebergConfig message. Also converts values to other types if specified.
         * @param message DefaultIcebergConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.DefaultIcebergConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this DefaultIcebergConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for DefaultIcebergConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an ActionConfigs. */
    interface IActionConfigs {

        /** ActionConfigs actions */
        actions?: (dataform.IActionConfig[]|null);
    }

    /** Represents an ActionConfigs. */
    class ActionConfigs implements IActionConfigs {

        /**
         * Constructs a new ActionConfigs.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IActionConfigs);

        /** ActionConfigs actions. */
        public actions: dataform.IActionConfig[];

        /**
         * Creates a new ActionConfigs instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ActionConfigs instance
         */
        public static create(properties?: dataform.IActionConfigs): dataform.ActionConfigs;

        /**
         * Encodes the specified ActionConfigs message. Does not implicitly {@link dataform.ActionConfigs.verify|verify} messages.
         * @param message ActionConfigs message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IActionConfigs, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ActionConfigs message, length delimited. Does not implicitly {@link dataform.ActionConfigs.verify|verify} messages.
         * @param message ActionConfigs message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IActionConfigs, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ActionConfigs message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ActionConfigs
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfigs;

        /**
         * Decodes an ActionConfigs message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ActionConfigs
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfigs;

        /**
         * Verifies an ActionConfigs message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ActionConfigs message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ActionConfigs
         */
        public static fromObject(object: { [k: string]: any }): dataform.ActionConfigs;

        /**
         * Creates a plain object from an ActionConfigs message. Also converts values to other types if specified.
         * @param message ActionConfigs
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ActionConfigs, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ActionConfigs to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ActionConfigs
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an ActionConfig. */
    interface IActionConfig {

        /** ActionConfig table */
        table?: (dataform.ActionConfig.ITableConfig|null);

        /** ActionConfig view */
        view?: (dataform.ActionConfig.IViewConfig|null);

        /** ActionConfig incrementalTable */
        incrementalTable?: (dataform.ActionConfig.IIncrementalTableConfig|null);

        /** ActionConfig assertion */
        assertion?: (dataform.ActionConfig.IAssertionConfig|null);

        /** ActionConfig operation */
        operation?: (dataform.ActionConfig.IOperationConfig|null);

        /** ActionConfig declaration */
        declaration?: (dataform.ActionConfig.IDeclarationConfig|null);

        /** ActionConfig notebook */
        notebook?: (dataform.ActionConfig.INotebookConfig|null);

        /** ActionConfig dataPreparation */
        dataPreparation?: (dataform.ActionConfig.IDataPreparationConfig|null);
    }

    /** Represents an ActionConfig. */
    class ActionConfig implements IActionConfig {

        /**
         * Constructs a new ActionConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IActionConfig);

        /** ActionConfig table. */
        public table?: (dataform.ActionConfig.ITableConfig|null);

        /** ActionConfig view. */
        public view?: (dataform.ActionConfig.IViewConfig|null);

        /** ActionConfig incrementalTable. */
        public incrementalTable?: (dataform.ActionConfig.IIncrementalTableConfig|null);

        /** ActionConfig assertion. */
        public assertion?: (dataform.ActionConfig.IAssertionConfig|null);

        /** ActionConfig operation. */
        public operation?: (dataform.ActionConfig.IOperationConfig|null);

        /** ActionConfig declaration. */
        public declaration?: (dataform.ActionConfig.IDeclarationConfig|null);

        /** ActionConfig notebook. */
        public notebook?: (dataform.ActionConfig.INotebookConfig|null);

        /** ActionConfig dataPreparation. */
        public dataPreparation?: (dataform.ActionConfig.IDataPreparationConfig|null);

        /** ActionConfig action. */
        public action?: ("table"|"view"|"incrementalTable"|"assertion"|"operation"|"declaration"|"notebook"|"dataPreparation");

        /**
         * Creates a new ActionConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ActionConfig instance
         */
        public static create(properties?: dataform.IActionConfig): dataform.ActionConfig;

        /**
         * Encodes the specified ActionConfig message. Does not implicitly {@link dataform.ActionConfig.verify|verify} messages.
         * @param message ActionConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IActionConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ActionConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.verify|verify} messages.
         * @param message ActionConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IActionConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ActionConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ActionConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig;

        /**
         * Decodes an ActionConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ActionConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig;

        /**
         * Verifies an ActionConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ActionConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ActionConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.ActionConfig;

        /**
         * Creates a plain object from an ActionConfig message. Also converts values to other types if specified.
         * @param message ActionConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ActionConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ActionConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ActionConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace ActionConfig {

        /** Properties of a Target. */
        interface ITarget {

            /** Target project */
            project?: (string|null);

            /** Target dataset */
            dataset?: (string|null);

            /** Target name */
            name?: (string|null);

            /** Target includeDependentAssertions */
            includeDependentAssertions?: (boolean|null);
        }

        /** Represents a Target. */
        class Target implements ITarget {

            /**
             * Constructs a new Target.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.ITarget);

            /** Target project. */
            public project: string;

            /** Target dataset. */
            public dataset: string;

            /** Target name. */
            public name: string;

            /** Target includeDependentAssertions. */
            public includeDependentAssertions: boolean;

            /**
             * Creates a new Target instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Target instance
             */
            public static create(properties?: dataform.ActionConfig.ITarget): dataform.ActionConfig.Target;

            /**
             * Encodes the specified Target message. Does not implicitly {@link dataform.ActionConfig.Target.verify|verify} messages.
             * @param message Target message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.ITarget, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified Target message, length delimited. Does not implicitly {@link dataform.ActionConfig.Target.verify|verify} messages.
             * @param message Target message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.ITarget, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a Target message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Target
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.Target;

            /**
             * Decodes a Target message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Target
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.Target;

            /**
             * Verifies a Target message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Target message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Target
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.Target;

            /**
             * Creates a plain object from a Target message. Also converts values to other types if specified.
             * @param message Target
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.Target, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Target to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for Target
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a ColumnDescriptor. */
        interface IColumnDescriptor {

            /** ColumnDescriptor path */
            path?: (string[]|null);

            /** ColumnDescriptor description */
            description?: (string|null);

            /** ColumnDescriptor bigqueryPolicyTags */
            bigqueryPolicyTags?: (string[]|null);

            /** ColumnDescriptor tags */
            tags?: (string[]|null);
        }

        /** Represents a ColumnDescriptor. */
        class ColumnDescriptor implements IColumnDescriptor {

            /**
             * Constructs a new ColumnDescriptor.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IColumnDescriptor);

            /** ColumnDescriptor path. */
            public path: string[];

            /** ColumnDescriptor description. */
            public description: string;

            /** ColumnDescriptor bigqueryPolicyTags. */
            public bigqueryPolicyTags: string[];

            /** ColumnDescriptor tags. */
            public tags: string[];

            /**
             * Creates a new ColumnDescriptor instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ColumnDescriptor instance
             */
            public static create(properties?: dataform.ActionConfig.IColumnDescriptor): dataform.ActionConfig.ColumnDescriptor;

            /**
             * Encodes the specified ColumnDescriptor message. Does not implicitly {@link dataform.ActionConfig.ColumnDescriptor.verify|verify} messages.
             * @param message ColumnDescriptor message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IColumnDescriptor, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified ColumnDescriptor message, length delimited. Does not implicitly {@link dataform.ActionConfig.ColumnDescriptor.verify|verify} messages.
             * @param message ColumnDescriptor message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IColumnDescriptor, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a ColumnDescriptor message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ColumnDescriptor
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.ColumnDescriptor;

            /**
             * Decodes a ColumnDescriptor message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ColumnDescriptor
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.ColumnDescriptor;

            /**
             * Verifies a ColumnDescriptor message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ColumnDescriptor message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ColumnDescriptor
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.ColumnDescriptor;

            /**
             * Creates a plain object from a ColumnDescriptor message. Also converts values to other types if specified.
             * @param message ColumnDescriptor
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.ColumnDescriptor, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ColumnDescriptor to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for ColumnDescriptor
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a TableAssertionsConfig. */
        interface ITableAssertionsConfig {

            /** TableAssertionsConfig uniqueKey */
            uniqueKey?: (string[]|null);

            /** TableAssertionsConfig uniqueKeys */
            uniqueKeys?: (dataform.ActionConfig.TableAssertionsConfig.IUniqueKey[]|null);

            /** TableAssertionsConfig nonNull */
            nonNull?: (string[]|null);

            /** TableAssertionsConfig rowConditions */
            rowConditions?: (string[]|null);
        }

        /** Represents a TableAssertionsConfig. */
        class TableAssertionsConfig implements ITableAssertionsConfig {

            /**
             * Constructs a new TableAssertionsConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.ITableAssertionsConfig);

            /** TableAssertionsConfig uniqueKey. */
            public uniqueKey: string[];

            /** TableAssertionsConfig uniqueKeys. */
            public uniqueKeys: dataform.ActionConfig.TableAssertionsConfig.IUniqueKey[];

            /** TableAssertionsConfig nonNull. */
            public nonNull: string[];

            /** TableAssertionsConfig rowConditions. */
            public rowConditions: string[];

            /**
             * Creates a new TableAssertionsConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableAssertionsConfig instance
             */
            public static create(properties?: dataform.ActionConfig.ITableAssertionsConfig): dataform.ActionConfig.TableAssertionsConfig;

            /**
             * Encodes the specified TableAssertionsConfig message. Does not implicitly {@link dataform.ActionConfig.TableAssertionsConfig.verify|verify} messages.
             * @param message TableAssertionsConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.ITableAssertionsConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified TableAssertionsConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.TableAssertionsConfig.verify|verify} messages.
             * @param message TableAssertionsConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.ITableAssertionsConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a TableAssertionsConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableAssertionsConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.TableAssertionsConfig;

            /**
             * Decodes a TableAssertionsConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableAssertionsConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.TableAssertionsConfig;

            /**
             * Verifies a TableAssertionsConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableAssertionsConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableAssertionsConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.TableAssertionsConfig;

            /**
             * Creates a plain object from a TableAssertionsConfig message. Also converts values to other types if specified.
             * @param message TableAssertionsConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.TableAssertionsConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableAssertionsConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for TableAssertionsConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        namespace TableAssertionsConfig {

            /** Properties of an UniqueKey. */
            interface IUniqueKey {

                /** UniqueKey uniqueKey */
                uniqueKey?: (string[]|null);
            }

            /** Represents an UniqueKey. */
            class UniqueKey implements IUniqueKey {

                /**
                 * Constructs a new UniqueKey.
                 * @param [properties] Properties to set
                 */
                constructor(properties?: dataform.ActionConfig.TableAssertionsConfig.IUniqueKey);

                /** UniqueKey uniqueKey. */
                public uniqueKey: string[];

                /**
                 * Creates a new UniqueKey instance using the specified properties.
                 * @param [properties] Properties to set
                 * @returns UniqueKey instance
                 */
                public static create(properties?: dataform.ActionConfig.TableAssertionsConfig.IUniqueKey): dataform.ActionConfig.TableAssertionsConfig.UniqueKey;

                /**
                 * Encodes the specified UniqueKey message. Does not implicitly {@link dataform.ActionConfig.TableAssertionsConfig.UniqueKey.verify|verify} messages.
                 * @param message UniqueKey message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encode(message: dataform.ActionConfig.TableAssertionsConfig.IUniqueKey, writer?: $protobuf.Writer): $protobuf.Writer;

                /**
                 * Encodes the specified UniqueKey message, length delimited. Does not implicitly {@link dataform.ActionConfig.TableAssertionsConfig.UniqueKey.verify|verify} messages.
                 * @param message UniqueKey message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encodeDelimited(message: dataform.ActionConfig.TableAssertionsConfig.IUniqueKey, writer?: $protobuf.Writer): $protobuf.Writer;

                /**
                 * Decodes an UniqueKey message from the specified reader or buffer.
                 * @param reader Reader or buffer to decode from
                 * @param [length] Message length if known beforehand
                 * @returns UniqueKey
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.TableAssertionsConfig.UniqueKey;

                /**
                 * Decodes an UniqueKey message from the specified reader or buffer, length delimited.
                 * @param reader Reader or buffer to decode from
                 * @returns UniqueKey
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.TableAssertionsConfig.UniqueKey;

                /**
                 * Verifies an UniqueKey message.
                 * @param message Plain object to verify
                 * @returns `null` if valid, otherwise the reason why it is not
                 */
                public static verify(message: { [k: string]: any }): (string|null);

                /**
                 * Creates an UniqueKey message from a plain object. Also converts values to their respective internal types.
                 * @param object Plain object
                 * @returns UniqueKey
                 */
                public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.TableAssertionsConfig.UniqueKey;

                /**
                 * Creates a plain object from an UniqueKey message. Also converts values to other types if specified.
                 * @param message UniqueKey
                 * @param [options] Conversion options
                 * @returns Plain object
                 */
                public static toObject(message: dataform.ActionConfig.TableAssertionsConfig.UniqueKey, options?: $protobuf.IConversionOptions): { [k: string]: any };

                /**
                 * Converts this UniqueKey to JSON.
                 * @returns JSON object
                 */
                public toJSON(): { [k: string]: any };

                /**
                 * Gets the default type url for UniqueKey
                 * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
                 * @returns The default type url
                 */
                public static getTypeUrl(typeUrlPrefix?: string): string;
            }
        }

        /** Properties of an IcebergTableConfig. */
        interface IIcebergTableConfig {

            /** IcebergTableConfig fileFormat */
            fileFormat?: (dataform.ActionConfig.IcebergTableConfig.FileFormat|null);

            /** IcebergTableConfig connection */
            connection?: (string|null);

            /** IcebergTableConfig bucketName */
            bucketName?: (string|null);

            /** IcebergTableConfig tableFolderRoot */
            tableFolderRoot?: (string|null);

            /** IcebergTableConfig tableFolderSubpath */
            tableFolderSubpath?: (string|null);
        }

        /** Represents an IcebergTableConfig. */
        class IcebergTableConfig implements IIcebergTableConfig {

            /**
             * Constructs a new IcebergTableConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IIcebergTableConfig);

            /** IcebergTableConfig fileFormat. */
            public fileFormat: dataform.ActionConfig.IcebergTableConfig.FileFormat;

            /** IcebergTableConfig connection. */
            public connection: string;

            /** IcebergTableConfig bucketName. */
            public bucketName: string;

            /** IcebergTableConfig tableFolderRoot. */
            public tableFolderRoot: string;

            /** IcebergTableConfig tableFolderSubpath. */
            public tableFolderSubpath: string;

            /**
             * Creates a new IcebergTableConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns IcebergTableConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IIcebergTableConfig): dataform.ActionConfig.IcebergTableConfig;

            /**
             * Encodes the specified IcebergTableConfig message. Does not implicitly {@link dataform.ActionConfig.IcebergTableConfig.verify|verify} messages.
             * @param message IcebergTableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IIcebergTableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified IcebergTableConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.IcebergTableConfig.verify|verify} messages.
             * @param message IcebergTableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IIcebergTableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes an IcebergTableConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns IcebergTableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.IcebergTableConfig;

            /**
             * Decodes an IcebergTableConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns IcebergTableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.IcebergTableConfig;

            /**
             * Verifies an IcebergTableConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an IcebergTableConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns IcebergTableConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.IcebergTableConfig;

            /**
             * Creates a plain object from an IcebergTableConfig message. Also converts values to other types if specified.
             * @param message IcebergTableConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.IcebergTableConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this IcebergTableConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for IcebergTableConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        namespace IcebergTableConfig {

            /** FileFormat enum. */
            enum FileFormat {
                FILE_FORMAT_UNSPECIFIED = 0,
                PARQUET = 1
            }
        }

        /** Properties of a TableConfig. */
        interface ITableConfig {

            /** TableConfig name */
            name?: (string|null);

            /** TableConfig dataset */
            dataset?: (string|null);

            /** TableConfig project */
            project?: (string|null);

            /** TableConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** TableConfig filename */
            filename?: (string|null);

            /** TableConfig tags */
            tags?: (string[]|null);

            /** TableConfig disabled */
            disabled?: (boolean|null);

            /** TableConfig preOperations */
            preOperations?: (string[]|null);

            /** TableConfig postOperations */
            postOperations?: (string[]|null);

            /** TableConfig description */
            description?: (string|null);

            /** TableConfig columns */
            columns?: (dataform.ActionConfig.IColumnDescriptor[]|null);

            /** TableConfig partitionBy */
            partitionBy?: (string|null);

            /** TableConfig partitionExpirationDays */
            partitionExpirationDays?: (number|null);

            /** TableConfig requirePartitionFilter */
            requirePartitionFilter?: (boolean|null);

            /** TableConfig clusterBy */
            clusterBy?: (string[]|null);

            /** TableConfig labels */
            labels?: ({ [k: string]: string }|null);

            /** TableConfig additionalOptions */
            additionalOptions?: ({ [k: string]: string }|null);

            /** TableConfig dependOnDependencyAssertions */
            dependOnDependencyAssertions?: (boolean|null);

            /** TableConfig assertions */
            assertions?: (dataform.ActionConfig.ITableAssertionsConfig|null);

            /** TableConfig hermetic */
            hermetic?: (boolean|null);

            /** TableConfig iceberg */
            iceberg?: (dataform.ActionConfig.IIcebergTableConfig|null);

            /** TableConfig metadata */
            metadata?: (dataform.ActionConfig.IMetadata|null);

            /** TableConfig reservation */
            reservation?: (string|null);
        }

        /** Represents a TableConfig. */
        class TableConfig implements ITableConfig {

            /**
             * Constructs a new TableConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.ITableConfig);

            /** TableConfig name. */
            public name: string;

            /** TableConfig dataset. */
            public dataset: string;

            /** TableConfig project. */
            public project: string;

            /** TableConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** TableConfig filename. */
            public filename: string;

            /** TableConfig tags. */
            public tags: string[];

            /** TableConfig disabled. */
            public disabled: boolean;

            /** TableConfig preOperations. */
            public preOperations: string[];

            /** TableConfig postOperations. */
            public postOperations: string[];

            /** TableConfig description. */
            public description: string;

            /** TableConfig columns. */
            public columns: dataform.ActionConfig.IColumnDescriptor[];

            /** TableConfig partitionBy. */
            public partitionBy: string;

            /** TableConfig partitionExpirationDays. */
            public partitionExpirationDays: number;

            /** TableConfig requirePartitionFilter. */
            public requirePartitionFilter: boolean;

            /** TableConfig clusterBy. */
            public clusterBy: string[];

            /** TableConfig labels. */
            public labels: { [k: string]: string };

            /** TableConfig additionalOptions. */
            public additionalOptions: { [k: string]: string };

            /** TableConfig dependOnDependencyAssertions. */
            public dependOnDependencyAssertions: boolean;

            /** TableConfig assertions. */
            public assertions?: (dataform.ActionConfig.ITableAssertionsConfig|null);

            /** TableConfig hermetic. */
            public hermetic: boolean;

            /** TableConfig iceberg. */
            public iceberg?: (dataform.ActionConfig.IIcebergTableConfig|null);

            /** TableConfig metadata. */
            public metadata?: (dataform.ActionConfig.IMetadata|null);

            /** TableConfig reservation. */
            public reservation: string;

            /**
             * Creates a new TableConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns TableConfig instance
             */
            public static create(properties?: dataform.ActionConfig.ITableConfig): dataform.ActionConfig.TableConfig;

            /**
             * Encodes the specified TableConfig message. Does not implicitly {@link dataform.ActionConfig.TableConfig.verify|verify} messages.
             * @param message TableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.ITableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified TableConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.TableConfig.verify|verify} messages.
             * @param message TableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.ITableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a TableConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns TableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.TableConfig;

            /**
             * Decodes a TableConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns TableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.TableConfig;

            /**
             * Verifies a TableConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a TableConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns TableConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.TableConfig;

            /**
             * Creates a plain object from a TableConfig message. Also converts values to other types if specified.
             * @param message TableConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.TableConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this TableConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for TableConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a Metadata. */
        interface IMetadata {

            /** Metadata overview */
            overview?: (string|null);

            /** Metadata extraProperties */
            extraProperties?: (google.protobuf.IStruct|null);
        }

        /** Represents a Metadata. */
        class Metadata implements IMetadata {

            /**
             * Constructs a new Metadata.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IMetadata);

            /** Metadata overview. */
            public overview: string;

            /** Metadata extraProperties. */
            public extraProperties?: (google.protobuf.IStruct|null);

            /**
             * Creates a new Metadata instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Metadata instance
             */
            public static create(properties?: dataform.ActionConfig.IMetadata): dataform.ActionConfig.Metadata;

            /**
             * Encodes the specified Metadata message. Does not implicitly {@link dataform.ActionConfig.Metadata.verify|verify} messages.
             * @param message Metadata message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified Metadata message, length delimited. Does not implicitly {@link dataform.ActionConfig.Metadata.verify|verify} messages.
             * @param message Metadata message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a Metadata message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Metadata
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.Metadata;

            /**
             * Decodes a Metadata message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Metadata
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.Metadata;

            /**
             * Verifies a Metadata message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Metadata message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Metadata
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.Metadata;

            /**
             * Creates a plain object from a Metadata message. Also converts values to other types if specified.
             * @param message Metadata
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.Metadata, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Metadata to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for Metadata
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a ViewConfig. */
        interface IViewConfig {

            /** ViewConfig name */
            name?: (string|null);

            /** ViewConfig dataset */
            dataset?: (string|null);

            /** ViewConfig project */
            project?: (string|null);

            /** ViewConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** ViewConfig filename */
            filename?: (string|null);

            /** ViewConfig tags */
            tags?: (string[]|null);

            /** ViewConfig disabled */
            disabled?: (boolean|null);

            /** ViewConfig preOperations */
            preOperations?: (string[]|null);

            /** ViewConfig postOperations */
            postOperations?: (string[]|null);

            /** ViewConfig materialized */
            materialized?: (boolean|null);

            /** ViewConfig partitionBy */
            partitionBy?: (string|null);

            /** ViewConfig clusterBy */
            clusterBy?: (string[]|null);

            /** ViewConfig description */
            description?: (string|null);

            /** ViewConfig columns */
            columns?: (dataform.ActionConfig.IColumnDescriptor[]|null);

            /** ViewConfig labels */
            labels?: ({ [k: string]: string }|null);

            /** ViewConfig additionalOptions */
            additionalOptions?: ({ [k: string]: string }|null);

            /** ViewConfig dependOnDependencyAssertions */
            dependOnDependencyAssertions?: (boolean|null);

            /** ViewConfig hermetic */
            hermetic?: (boolean|null);

            /** ViewConfig assertions */
            assertions?: (dataform.ActionConfig.ITableAssertionsConfig|null);

            /** ViewConfig metadata */
            metadata?: (dataform.ActionConfig.IMetadata|null);

            /** ViewConfig reservation */
            reservation?: (string|null);
        }

        /** Represents a ViewConfig. */
        class ViewConfig implements IViewConfig {

            /**
             * Constructs a new ViewConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IViewConfig);

            /** ViewConfig name. */
            public name: string;

            /** ViewConfig dataset. */
            public dataset: string;

            /** ViewConfig project. */
            public project: string;

            /** ViewConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** ViewConfig filename. */
            public filename: string;

            /** ViewConfig tags. */
            public tags: string[];

            /** ViewConfig disabled. */
            public disabled: boolean;

            /** ViewConfig preOperations. */
            public preOperations: string[];

            /** ViewConfig postOperations. */
            public postOperations: string[];

            /** ViewConfig materialized. */
            public materialized: boolean;

            /** ViewConfig partitionBy. */
            public partitionBy: string;

            /** ViewConfig clusterBy. */
            public clusterBy: string[];

            /** ViewConfig description. */
            public description: string;

            /** ViewConfig columns. */
            public columns: dataform.ActionConfig.IColumnDescriptor[];

            /** ViewConfig labels. */
            public labels: { [k: string]: string };

            /** ViewConfig additionalOptions. */
            public additionalOptions: { [k: string]: string };

            /** ViewConfig dependOnDependencyAssertions. */
            public dependOnDependencyAssertions: boolean;

            /** ViewConfig hermetic. */
            public hermetic: boolean;

            /** ViewConfig assertions. */
            public assertions?: (dataform.ActionConfig.ITableAssertionsConfig|null);

            /** ViewConfig metadata. */
            public metadata?: (dataform.ActionConfig.IMetadata|null);

            /** ViewConfig reservation. */
            public reservation: string;

            /**
             * Creates a new ViewConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ViewConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IViewConfig): dataform.ActionConfig.ViewConfig;

            /**
             * Encodes the specified ViewConfig message. Does not implicitly {@link dataform.ActionConfig.ViewConfig.verify|verify} messages.
             * @param message ViewConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IViewConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified ViewConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.ViewConfig.verify|verify} messages.
             * @param message ViewConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IViewConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a ViewConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ViewConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.ViewConfig;

            /**
             * Decodes a ViewConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ViewConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.ViewConfig;

            /**
             * Verifies a ViewConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ViewConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ViewConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.ViewConfig;

            /**
             * Creates a plain object from a ViewConfig message. Also converts values to other types if specified.
             * @param message ViewConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.ViewConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ViewConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for ViewConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** OnSchemaChange enum. */
        enum OnSchemaChange {
            IGNORE = 0,
            FAIL = 1,
            EXTEND = 2,
            SYNCHRONIZE = 3
        }

        /** Properties of an IncrementalTableConfig. */
        interface IIncrementalTableConfig {

            /** IncrementalTableConfig name */
            name?: (string|null);

            /** IncrementalTableConfig dataset */
            dataset?: (string|null);

            /** IncrementalTableConfig project */
            project?: (string|null);

            /** IncrementalTableConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** IncrementalTableConfig filename */
            filename?: (string|null);

            /** IncrementalTableConfig tags */
            tags?: (string[]|null);

            /** IncrementalTableConfig disabled */
            disabled?: (boolean|null);

            /** IncrementalTableConfig preOperations */
            preOperations?: (string[]|null);

            /** IncrementalTableConfig postOperations */
            postOperations?: (string[]|null);

            /** IncrementalTableConfig protected */
            "protected"?: (boolean|null);

            /** IncrementalTableConfig uniqueKey */
            uniqueKey?: (string[]|null);

            /** IncrementalTableConfig description */
            description?: (string|null);

            /** IncrementalTableConfig columns */
            columns?: (dataform.ActionConfig.IColumnDescriptor[]|null);

            /** IncrementalTableConfig partitionBy */
            partitionBy?: (string|null);

            /** IncrementalTableConfig partitionExpirationDays */
            partitionExpirationDays?: (number|null);

            /** IncrementalTableConfig requirePartitionFilter */
            requirePartitionFilter?: (boolean|null);

            /** IncrementalTableConfig updatePartitionFilter */
            updatePartitionFilter?: (string|null);

            /** IncrementalTableConfig clusterBy */
            clusterBy?: (string[]|null);

            /** IncrementalTableConfig labels */
            labels?: ({ [k: string]: string }|null);

            /** IncrementalTableConfig additionalOptions */
            additionalOptions?: ({ [k: string]: string }|null);

            /** IncrementalTableConfig dependOnDependencyAssertions */
            dependOnDependencyAssertions?: (boolean|null);

            /** IncrementalTableConfig assertions */
            assertions?: (dataform.ActionConfig.ITableAssertionsConfig|null);

            /** IncrementalTableConfig hermetic */
            hermetic?: (boolean|null);

            /** IncrementalTableConfig onSchemaChange */
            onSchemaChange?: (dataform.ActionConfig.OnSchemaChange|null);

            /** IncrementalTableConfig iceberg */
            iceberg?: (dataform.ActionConfig.IIcebergTableConfig|null);

            /** IncrementalTableConfig metadata */
            metadata?: (dataform.ActionConfig.IMetadata|null);

            /** IncrementalTableConfig reservation */
            reservation?: (string|null);
        }

        /** Represents an IncrementalTableConfig. */
        class IncrementalTableConfig implements IIncrementalTableConfig {

            /**
             * Constructs a new IncrementalTableConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IIncrementalTableConfig);

            /** IncrementalTableConfig name. */
            public name: string;

            /** IncrementalTableConfig dataset. */
            public dataset: string;

            /** IncrementalTableConfig project. */
            public project: string;

            /** IncrementalTableConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** IncrementalTableConfig filename. */
            public filename: string;

            /** IncrementalTableConfig tags. */
            public tags: string[];

            /** IncrementalTableConfig disabled. */
            public disabled: boolean;

            /** IncrementalTableConfig preOperations. */
            public preOperations: string[];

            /** IncrementalTableConfig postOperations. */
            public postOperations: string[];

            /** IncrementalTableConfig protected. */
            public protected: boolean;

            /** IncrementalTableConfig uniqueKey. */
            public uniqueKey: string[];

            /** IncrementalTableConfig description. */
            public description: string;

            /** IncrementalTableConfig columns. */
            public columns: dataform.ActionConfig.IColumnDescriptor[];

            /** IncrementalTableConfig partitionBy. */
            public partitionBy: string;

            /** IncrementalTableConfig partitionExpirationDays. */
            public partitionExpirationDays: number;

            /** IncrementalTableConfig requirePartitionFilter. */
            public requirePartitionFilter: boolean;

            /** IncrementalTableConfig updatePartitionFilter. */
            public updatePartitionFilter: string;

            /** IncrementalTableConfig clusterBy. */
            public clusterBy: string[];

            /** IncrementalTableConfig labels. */
            public labels: { [k: string]: string };

            /** IncrementalTableConfig additionalOptions. */
            public additionalOptions: { [k: string]: string };

            /** IncrementalTableConfig dependOnDependencyAssertions. */
            public dependOnDependencyAssertions: boolean;

            /** IncrementalTableConfig assertions. */
            public assertions?: (dataform.ActionConfig.ITableAssertionsConfig|null);

            /** IncrementalTableConfig hermetic. */
            public hermetic: boolean;

            /** IncrementalTableConfig onSchemaChange. */
            public onSchemaChange: dataform.ActionConfig.OnSchemaChange;

            /** IncrementalTableConfig iceberg. */
            public iceberg?: (dataform.ActionConfig.IIcebergTableConfig|null);

            /** IncrementalTableConfig metadata. */
            public metadata?: (dataform.ActionConfig.IMetadata|null);

            /** IncrementalTableConfig reservation. */
            public reservation: string;

            /**
             * Creates a new IncrementalTableConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns IncrementalTableConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IIncrementalTableConfig): dataform.ActionConfig.IncrementalTableConfig;

            /**
             * Encodes the specified IncrementalTableConfig message. Does not implicitly {@link dataform.ActionConfig.IncrementalTableConfig.verify|verify} messages.
             * @param message IncrementalTableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IIncrementalTableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified IncrementalTableConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.IncrementalTableConfig.verify|verify} messages.
             * @param message IncrementalTableConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IIncrementalTableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes an IncrementalTableConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns IncrementalTableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.IncrementalTableConfig;

            /**
             * Decodes an IncrementalTableConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns IncrementalTableConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.IncrementalTableConfig;

            /**
             * Verifies an IncrementalTableConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an IncrementalTableConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns IncrementalTableConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.IncrementalTableConfig;

            /**
             * Creates a plain object from an IncrementalTableConfig message. Also converts values to other types if specified.
             * @param message IncrementalTableConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.IncrementalTableConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this IncrementalTableConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for IncrementalTableConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of an AssertionConfig. */
        interface IAssertionConfig {

            /** AssertionConfig name */
            name?: (string|null);

            /** AssertionConfig dataset */
            dataset?: (string|null);

            /** AssertionConfig project */
            project?: (string|null);

            /** AssertionConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** AssertionConfig filename */
            filename?: (string|null);

            /** AssertionConfig tags */
            tags?: (string[]|null);

            /** AssertionConfig disabled */
            disabled?: (boolean|null);

            /** AssertionConfig description */
            description?: (string|null);

            /** AssertionConfig hermetic */
            hermetic?: (boolean|null);

            /** AssertionConfig dependOnDependencyAssertions */
            dependOnDependencyAssertions?: (boolean|null);

            /** AssertionConfig reservation */
            reservation?: (string|null);
        }

        /** Represents an AssertionConfig. */
        class AssertionConfig implements IAssertionConfig {

            /**
             * Constructs a new AssertionConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IAssertionConfig);

            /** AssertionConfig name. */
            public name: string;

            /** AssertionConfig dataset. */
            public dataset: string;

            /** AssertionConfig project. */
            public project: string;

            /** AssertionConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** AssertionConfig filename. */
            public filename: string;

            /** AssertionConfig tags. */
            public tags: string[];

            /** AssertionConfig disabled. */
            public disabled: boolean;

            /** AssertionConfig description. */
            public description: string;

            /** AssertionConfig hermetic. */
            public hermetic: boolean;

            /** AssertionConfig dependOnDependencyAssertions. */
            public dependOnDependencyAssertions: boolean;

            /** AssertionConfig reservation. */
            public reservation: string;

            /**
             * Creates a new AssertionConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns AssertionConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IAssertionConfig): dataform.ActionConfig.AssertionConfig;

            /**
             * Encodes the specified AssertionConfig message. Does not implicitly {@link dataform.ActionConfig.AssertionConfig.verify|verify} messages.
             * @param message AssertionConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IAssertionConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified AssertionConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.AssertionConfig.verify|verify} messages.
             * @param message AssertionConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IAssertionConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes an AssertionConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns AssertionConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.AssertionConfig;

            /**
             * Decodes an AssertionConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns AssertionConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.AssertionConfig;

            /**
             * Verifies an AssertionConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an AssertionConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns AssertionConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.AssertionConfig;

            /**
             * Creates a plain object from an AssertionConfig message. Also converts values to other types if specified.
             * @param message AssertionConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.AssertionConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this AssertionConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for AssertionConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of an OperationConfig. */
        interface IOperationConfig {

            /** OperationConfig name */
            name?: (string|null);

            /** OperationConfig dataset */
            dataset?: (string|null);

            /** OperationConfig project */
            project?: (string|null);

            /** OperationConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** OperationConfig filename */
            filename?: (string|null);

            /** OperationConfig tags */
            tags?: (string[]|null);

            /** OperationConfig disabled */
            disabled?: (boolean|null);

            /** OperationConfig hasOutput */
            hasOutput?: (boolean|null);

            /** OperationConfig description */
            description?: (string|null);

            /** OperationConfig columns */
            columns?: (dataform.ActionConfig.IColumnDescriptor[]|null);

            /** OperationConfig dependOnDependencyAssertions */
            dependOnDependencyAssertions?: (boolean|null);

            /** OperationConfig hermetic */
            hermetic?: (boolean|null);

            /** OperationConfig reservation */
            reservation?: (string|null);
        }

        /** Represents an OperationConfig. */
        class OperationConfig implements IOperationConfig {

            /**
             * Constructs a new OperationConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IOperationConfig);

            /** OperationConfig name. */
            public name: string;

            /** OperationConfig dataset. */
            public dataset: string;

            /** OperationConfig project. */
            public project: string;

            /** OperationConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** OperationConfig filename. */
            public filename: string;

            /** OperationConfig tags. */
            public tags: string[];

            /** OperationConfig disabled. */
            public disabled: boolean;

            /** OperationConfig hasOutput. */
            public hasOutput: boolean;

            /** OperationConfig description. */
            public description: string;

            /** OperationConfig columns. */
            public columns: dataform.ActionConfig.IColumnDescriptor[];

            /** OperationConfig dependOnDependencyAssertions. */
            public dependOnDependencyAssertions: boolean;

            /** OperationConfig hermetic. */
            public hermetic: boolean;

            /** OperationConfig reservation. */
            public reservation: string;

            /**
             * Creates a new OperationConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns OperationConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IOperationConfig): dataform.ActionConfig.OperationConfig;

            /**
             * Encodes the specified OperationConfig message. Does not implicitly {@link dataform.ActionConfig.OperationConfig.verify|verify} messages.
             * @param message OperationConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IOperationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified OperationConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.OperationConfig.verify|verify} messages.
             * @param message OperationConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IOperationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes an OperationConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns OperationConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.OperationConfig;

            /**
             * Decodes an OperationConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns OperationConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.OperationConfig;

            /**
             * Verifies an OperationConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an OperationConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns OperationConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.OperationConfig;

            /**
             * Creates a plain object from an OperationConfig message. Also converts values to other types if specified.
             * @param message OperationConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.OperationConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this OperationConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for OperationConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a DeclarationConfig. */
        interface IDeclarationConfig {

            /** DeclarationConfig name */
            name?: (string|null);

            /** DeclarationConfig dataset */
            dataset?: (string|null);

            /** DeclarationConfig project */
            project?: (string|null);

            /** DeclarationConfig description */
            description?: (string|null);

            /** DeclarationConfig columns */
            columns?: (dataform.ActionConfig.IColumnDescriptor[]|null);

            /** DeclarationConfig filename */
            filename?: (string|null);

            /** DeclarationConfig tags */
            tags?: (string[]|null);
        }

        /** Represents a DeclarationConfig. */
        class DeclarationConfig implements IDeclarationConfig {

            /**
             * Constructs a new DeclarationConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IDeclarationConfig);

            /** DeclarationConfig name. */
            public name: string;

            /** DeclarationConfig dataset. */
            public dataset: string;

            /** DeclarationConfig project. */
            public project: string;

            /** DeclarationConfig description. */
            public description: string;

            /** DeclarationConfig columns. */
            public columns: dataform.ActionConfig.IColumnDescriptor[];

            /** DeclarationConfig filename. */
            public filename: string;

            /** DeclarationConfig tags. */
            public tags: string[];

            /**
             * Creates a new DeclarationConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns DeclarationConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IDeclarationConfig): dataform.ActionConfig.DeclarationConfig;

            /**
             * Encodes the specified DeclarationConfig message. Does not implicitly {@link dataform.ActionConfig.DeclarationConfig.verify|verify} messages.
             * @param message DeclarationConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IDeclarationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified DeclarationConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.DeclarationConfig.verify|verify} messages.
             * @param message DeclarationConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IDeclarationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a DeclarationConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns DeclarationConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.DeclarationConfig;

            /**
             * Decodes a DeclarationConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns DeclarationConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.DeclarationConfig;

            /**
             * Verifies a DeclarationConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a DeclarationConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns DeclarationConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.DeclarationConfig;

            /**
             * Creates a plain object from a DeclarationConfig message. Also converts values to other types if specified.
             * @param message DeclarationConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.DeclarationConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this DeclarationConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for DeclarationConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a NotebookConfig. */
        interface INotebookConfig {

            /** NotebookConfig name */
            name?: (string|null);

            /** NotebookConfig location */
            location?: (string|null);

            /** NotebookConfig project */
            project?: (string|null);

            /** NotebookConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** NotebookConfig filename */
            filename?: (string|null);

            /** NotebookConfig tags */
            tags?: (string[]|null);

            /** NotebookConfig disabled */
            disabled?: (boolean|null);

            /** NotebookConfig description */
            description?: (string|null);

            /** NotebookConfig dependOnDependencyAssertions */
            dependOnDependencyAssertions?: (boolean|null);
        }

        /** Represents a NotebookConfig. */
        class NotebookConfig implements INotebookConfig {

            /**
             * Constructs a new NotebookConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.INotebookConfig);

            /** NotebookConfig name. */
            public name: string;

            /** NotebookConfig location. */
            public location: string;

            /** NotebookConfig project. */
            public project: string;

            /** NotebookConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** NotebookConfig filename. */
            public filename: string;

            /** NotebookConfig tags. */
            public tags: string[];

            /** NotebookConfig disabled. */
            public disabled: boolean;

            /** NotebookConfig description. */
            public description: string;

            /** NotebookConfig dependOnDependencyAssertions. */
            public dependOnDependencyAssertions: boolean;

            /**
             * Creates a new NotebookConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns NotebookConfig instance
             */
            public static create(properties?: dataform.ActionConfig.INotebookConfig): dataform.ActionConfig.NotebookConfig;

            /**
             * Encodes the specified NotebookConfig message. Does not implicitly {@link dataform.ActionConfig.NotebookConfig.verify|verify} messages.
             * @param message NotebookConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.INotebookConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified NotebookConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.NotebookConfig.verify|verify} messages.
             * @param message NotebookConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.INotebookConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a NotebookConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns NotebookConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.NotebookConfig;

            /**
             * Decodes a NotebookConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns NotebookConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.NotebookConfig;

            /**
             * Verifies a NotebookConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a NotebookConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns NotebookConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.NotebookConfig;

            /**
             * Creates a plain object from a NotebookConfig message. Also converts values to other types if specified.
             * @param message NotebookConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.NotebookConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this NotebookConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for NotebookConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a DataPreparationConfig. */
        interface IDataPreparationConfig {

            /** DataPreparationConfig name */
            name?: (string|null);

            /** DataPreparationConfig dataset */
            dataset?: (string|null);

            /** DataPreparationConfig project */
            project?: (string|null);

            /** DataPreparationConfig dependencyTargets */
            dependencyTargets?: (dataform.ActionConfig.ITarget[]|null);

            /** DataPreparationConfig filename */
            filename?: (string|null);

            /** DataPreparationConfig tags */
            tags?: (string[]|null);

            /** DataPreparationConfig disabled */
            disabled?: (boolean|null);

            /** DataPreparationConfig description */
            description?: (string|null);

            /** DataPreparationConfig errorTable */
            errorTable?: (dataform.ActionConfig.DataPreparationConfig.IErrorTableConfig|null);

            /** DataPreparationConfig loadMode */
            loadMode?: (dataform.ActionConfig.ILoadModeConfig|null);
        }

        /** Represents a DataPreparationConfig. */
        class DataPreparationConfig implements IDataPreparationConfig {

            /**
             * Constructs a new DataPreparationConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.IDataPreparationConfig);

            /** DataPreparationConfig name. */
            public name: string;

            /** DataPreparationConfig dataset. */
            public dataset: string;

            /** DataPreparationConfig project. */
            public project: string;

            /** DataPreparationConfig dependencyTargets. */
            public dependencyTargets: dataform.ActionConfig.ITarget[];

            /** DataPreparationConfig filename. */
            public filename: string;

            /** DataPreparationConfig tags. */
            public tags: string[];

            /** DataPreparationConfig disabled. */
            public disabled: boolean;

            /** DataPreparationConfig description. */
            public description: string;

            /** DataPreparationConfig errorTable. */
            public errorTable?: (dataform.ActionConfig.DataPreparationConfig.IErrorTableConfig|null);

            /** DataPreparationConfig loadMode. */
            public loadMode?: (dataform.ActionConfig.ILoadModeConfig|null);

            /**
             * Creates a new DataPreparationConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns DataPreparationConfig instance
             */
            public static create(properties?: dataform.ActionConfig.IDataPreparationConfig): dataform.ActionConfig.DataPreparationConfig;

            /**
             * Encodes the specified DataPreparationConfig message. Does not implicitly {@link dataform.ActionConfig.DataPreparationConfig.verify|verify} messages.
             * @param message DataPreparationConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.IDataPreparationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified DataPreparationConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.DataPreparationConfig.verify|verify} messages.
             * @param message DataPreparationConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.IDataPreparationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a DataPreparationConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns DataPreparationConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.DataPreparationConfig;

            /**
             * Decodes a DataPreparationConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns DataPreparationConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.DataPreparationConfig;

            /**
             * Verifies a DataPreparationConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a DataPreparationConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns DataPreparationConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.DataPreparationConfig;

            /**
             * Creates a plain object from a DataPreparationConfig message. Also converts values to other types if specified.
             * @param message DataPreparationConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.DataPreparationConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this DataPreparationConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for DataPreparationConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        namespace DataPreparationConfig {

            /** Properties of an ErrorTableConfig. */
            interface IErrorTableConfig {

                /** ErrorTableConfig name */
                name?: (string|null);

                /** ErrorTableConfig dataset */
                dataset?: (string|null);

                /** ErrorTableConfig project */
                project?: (string|null);

                /** ErrorTableConfig retentionDays */
                retentionDays?: (number|null);
            }

            /** Represents an ErrorTableConfig. */
            class ErrorTableConfig implements IErrorTableConfig {

                /**
                 * Constructs a new ErrorTableConfig.
                 * @param [properties] Properties to set
                 */
                constructor(properties?: dataform.ActionConfig.DataPreparationConfig.IErrorTableConfig);

                /** ErrorTableConfig name. */
                public name: string;

                /** ErrorTableConfig dataset. */
                public dataset: string;

                /** ErrorTableConfig project. */
                public project: string;

                /** ErrorTableConfig retentionDays. */
                public retentionDays: number;

                /**
                 * Creates a new ErrorTableConfig instance using the specified properties.
                 * @param [properties] Properties to set
                 * @returns ErrorTableConfig instance
                 */
                public static create(properties?: dataform.ActionConfig.DataPreparationConfig.IErrorTableConfig): dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig;

                /**
                 * Encodes the specified ErrorTableConfig message. Does not implicitly {@link dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig.verify|verify} messages.
                 * @param message ErrorTableConfig message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encode(message: dataform.ActionConfig.DataPreparationConfig.IErrorTableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

                /**
                 * Encodes the specified ErrorTableConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig.verify|verify} messages.
                 * @param message ErrorTableConfig message or plain object to encode
                 * @param [writer] Writer to encode to
                 * @returns Writer
                 */
                public static encodeDelimited(message: dataform.ActionConfig.DataPreparationConfig.IErrorTableConfig, writer?: $protobuf.Writer): $protobuf.Writer;

                /**
                 * Decodes an ErrorTableConfig message from the specified reader or buffer.
                 * @param reader Reader or buffer to decode from
                 * @param [length] Message length if known beforehand
                 * @returns ErrorTableConfig
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig;

                /**
                 * Decodes an ErrorTableConfig message from the specified reader or buffer, length delimited.
                 * @param reader Reader or buffer to decode from
                 * @returns ErrorTableConfig
                 * @throws {Error} If the payload is not a reader or valid buffer
                 * @throws {$protobuf.util.ProtocolError} If required fields are missing
                 */
                public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig;

                /**
                 * Verifies an ErrorTableConfig message.
                 * @param message Plain object to verify
                 * @returns `null` if valid, otherwise the reason why it is not
                 */
                public static verify(message: { [k: string]: any }): (string|null);

                /**
                 * Creates an ErrorTableConfig message from a plain object. Also converts values to their respective internal types.
                 * @param object Plain object
                 * @returns ErrorTableConfig
                 */
                public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig;

                /**
                 * Creates a plain object from an ErrorTableConfig message. Also converts values to other types if specified.
                 * @param message ErrorTableConfig
                 * @param [options] Conversion options
                 * @returns Plain object
                 */
                public static toObject(message: dataform.ActionConfig.DataPreparationConfig.ErrorTableConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

                /**
                 * Converts this ErrorTableConfig to JSON.
                 * @returns JSON object
                 */
                public toJSON(): { [k: string]: any };

                /**
                 * Gets the default type url for ErrorTableConfig
                 * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
                 * @returns The default type url
                 */
                public static getTypeUrl(typeUrlPrefix?: string): string;
            }
        }

        /** Properties of a LoadModeConfig. */
        interface ILoadModeConfig {

            /** LoadModeConfig mode */
            mode?: (dataform.ActionConfig.LoadMode|null);

            /** LoadModeConfig incrementalColumn */
            incrementalColumn?: (string|null);

            /** LoadModeConfig uniqueKey */
            uniqueKey?: (string[]|null);
        }

        /** Represents a LoadModeConfig. */
        class LoadModeConfig implements ILoadModeConfig {

            /**
             * Constructs a new LoadModeConfig.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ActionConfig.ILoadModeConfig);

            /** LoadModeConfig mode. */
            public mode: dataform.ActionConfig.LoadMode;

            /** LoadModeConfig incrementalColumn. */
            public incrementalColumn: string;

            /** LoadModeConfig uniqueKey. */
            public uniqueKey: string[];

            /**
             * Creates a new LoadModeConfig instance using the specified properties.
             * @param [properties] Properties to set
             * @returns LoadModeConfig instance
             */
            public static create(properties?: dataform.ActionConfig.ILoadModeConfig): dataform.ActionConfig.LoadModeConfig;

            /**
             * Encodes the specified LoadModeConfig message. Does not implicitly {@link dataform.ActionConfig.LoadModeConfig.verify|verify} messages.
             * @param message LoadModeConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ActionConfig.ILoadModeConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified LoadModeConfig message, length delimited. Does not implicitly {@link dataform.ActionConfig.LoadModeConfig.verify|verify} messages.
             * @param message LoadModeConfig message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ActionConfig.ILoadModeConfig, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a LoadModeConfig message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns LoadModeConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionConfig.LoadModeConfig;

            /**
             * Decodes a LoadModeConfig message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns LoadModeConfig
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionConfig.LoadModeConfig;

            /**
             * Verifies a LoadModeConfig message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a LoadModeConfig message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns LoadModeConfig
             */
            public static fromObject(object: { [k: string]: any }): dataform.ActionConfig.LoadModeConfig;

            /**
             * Creates a plain object from a LoadModeConfig message. Also converts values to other types if specified.
             * @param message LoadModeConfig
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ActionConfig.LoadModeConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this LoadModeConfig to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for LoadModeConfig
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** LoadMode enum. */
        enum LoadMode {
            REPLACE_TABLE = 0,
            APPEND = 1,
            MAXIMUM = 2,
            UNIQUE = 3,
            MERGE = 4
        }
    }

    /** Properties of a RepositorySnapshotDestinationConfig. */
    interface IRepositorySnapshotDestinationConfig {

        /** RepositorySnapshotDestinationConfig repositorySnapshotUri */
        repositorySnapshotUri?: (string|null);
    }

    /** Represents a RepositorySnapshotDestinationConfig. */
    class RepositorySnapshotDestinationConfig implements IRepositorySnapshotDestinationConfig {

        /**
         * Constructs a new RepositorySnapshotDestinationConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IRepositorySnapshotDestinationConfig);

        /** RepositorySnapshotDestinationConfig repositorySnapshotUri. */
        public repositorySnapshotUri: string;

        /**
         * Creates a new RepositorySnapshotDestinationConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns RepositorySnapshotDestinationConfig instance
         */
        public static create(properties?: dataform.IRepositorySnapshotDestinationConfig): dataform.RepositorySnapshotDestinationConfig;

        /**
         * Encodes the specified RepositorySnapshotDestinationConfig message. Does not implicitly {@link dataform.RepositorySnapshotDestinationConfig.verify|verify} messages.
         * @param message RepositorySnapshotDestinationConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IRepositorySnapshotDestinationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified RepositorySnapshotDestinationConfig message, length delimited. Does not implicitly {@link dataform.RepositorySnapshotDestinationConfig.verify|verify} messages.
         * @param message RepositorySnapshotDestinationConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IRepositorySnapshotDestinationConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a RepositorySnapshotDestinationConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns RepositorySnapshotDestinationConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.RepositorySnapshotDestinationConfig;

        /**
         * Decodes a RepositorySnapshotDestinationConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns RepositorySnapshotDestinationConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.RepositorySnapshotDestinationConfig;

        /**
         * Verifies a RepositorySnapshotDestinationConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a RepositorySnapshotDestinationConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns RepositorySnapshotDestinationConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.RepositorySnapshotDestinationConfig;

        /**
         * Creates a plain object from a RepositorySnapshotDestinationConfig message. Also converts values to other types if specified.
         * @param message RepositorySnapshotDestinationConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.RepositorySnapshotDestinationConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this RepositorySnapshotDestinationConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for RepositorySnapshotDestinationConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a NotebookRuntimeOptionsConfig. */
    interface INotebookRuntimeOptionsConfig {

        /** NotebookRuntimeOptionsConfig outputBucket */
        outputBucket?: (string|null);

        /** NotebookRuntimeOptionsConfig runtimeTemplateName */
        runtimeTemplateName?: (string|null);

        /** NotebookRuntimeOptionsConfig repositorySnapshotDestination */
        repositorySnapshotDestination?: (dataform.IRepositorySnapshotDestinationConfig|null);
    }

    /** Represents a NotebookRuntimeOptionsConfig. */
    class NotebookRuntimeOptionsConfig implements INotebookRuntimeOptionsConfig {

        /**
         * Constructs a new NotebookRuntimeOptionsConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.INotebookRuntimeOptionsConfig);

        /** NotebookRuntimeOptionsConfig outputBucket. */
        public outputBucket?: (string|null);

        /** NotebookRuntimeOptionsConfig runtimeTemplateName. */
        public runtimeTemplateName: string;

        /** NotebookRuntimeOptionsConfig repositorySnapshotDestination. */
        public repositorySnapshotDestination?: (dataform.IRepositorySnapshotDestinationConfig|null);

        /** NotebookRuntimeOptionsConfig outputSink. */
        public outputSink?: "outputBucket";

        /** NotebookRuntimeOptionsConfig repositorySnapshotStorage. */
        public repositorySnapshotStorage?: "repositorySnapshotDestination";

        /**
         * Creates a new NotebookRuntimeOptionsConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns NotebookRuntimeOptionsConfig instance
         */
        public static create(properties?: dataform.INotebookRuntimeOptionsConfig): dataform.NotebookRuntimeOptionsConfig;

        /**
         * Encodes the specified NotebookRuntimeOptionsConfig message. Does not implicitly {@link dataform.NotebookRuntimeOptionsConfig.verify|verify} messages.
         * @param message NotebookRuntimeOptionsConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.INotebookRuntimeOptionsConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified NotebookRuntimeOptionsConfig message, length delimited. Does not implicitly {@link dataform.NotebookRuntimeOptionsConfig.verify|verify} messages.
         * @param message NotebookRuntimeOptionsConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.INotebookRuntimeOptionsConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a NotebookRuntimeOptionsConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns NotebookRuntimeOptionsConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.NotebookRuntimeOptionsConfig;

        /**
         * Decodes a NotebookRuntimeOptionsConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns NotebookRuntimeOptionsConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.NotebookRuntimeOptionsConfig;

        /**
         * Verifies a NotebookRuntimeOptionsConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a NotebookRuntimeOptionsConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns NotebookRuntimeOptionsConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.NotebookRuntimeOptionsConfig;

        /**
         * Creates a plain object from a NotebookRuntimeOptionsConfig message. Also converts values to other types if specified.
         * @param message NotebookRuntimeOptionsConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.NotebookRuntimeOptionsConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this NotebookRuntimeOptionsConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for NotebookRuntimeOptionsConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** ExtensionCompilationMode enum. */
    enum ExtensionCompilationMode {
        COMPILATION_MODE_UNSPECIFIED = 0,
        PROLOGUE = 1,
        APPLICATION_CODE = 2
    }

    /** Properties of an Extension. */
    interface IExtension {

        /** Extension name */
        name?: (string|null);

        /** Extension compilationMode */
        compilationMode?: (dataform.ExtensionCompilationMode|null);

        /** Extension options */
        options?: ({ [k: string]: string }|null);
    }

    /** Represents an Extension. */
    class Extension implements IExtension {

        /**
         * Constructs a new Extension.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExtension);

        /** Extension name. */
        public name: string;

        /** Extension compilationMode. */
        public compilationMode: dataform.ExtensionCompilationMode;

        /** Extension options. */
        public options: { [k: string]: string };

        /**
         * Creates a new Extension instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Extension instance
         */
        public static create(properties?: dataform.IExtension): dataform.Extension;

        /**
         * Encodes the specified Extension message. Does not implicitly {@link dataform.Extension.verify|verify} messages.
         * @param message Extension message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExtension, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Extension message, length delimited. Does not implicitly {@link dataform.Extension.verify|verify} messages.
         * @param message Extension message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExtension, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an Extension message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Extension
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Extension;

        /**
         * Decodes an Extension message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Extension
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Extension;

        /**
         * Verifies an Extension message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an Extension message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Extension
         */
        public static fromObject(object: { [k: string]: any }): dataform.Extension;

        /**
         * Creates a plain object from an Extension message. Also converts values to other types if specified.
         * @param message Extension
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Extension, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Extension to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Extension
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a ProjectConfig. */
    interface IProjectConfig {

        /** ProjectConfig warehouse */
        warehouse?: (string|null);

        /** ProjectConfig defaultDatabase */
        defaultDatabase?: (string|null);

        /** ProjectConfig defaultSchema */
        defaultSchema?: (string|null);

        /** ProjectConfig defaultLocation */
        defaultLocation?: (string|null);

        /** ProjectConfig assertionSchema */
        assertionSchema?: (string|null);

        /** ProjectConfig vars */
        vars?: ({ [k: string]: string }|null);

        /** ProjectConfig databaseSuffix */
        databaseSuffix?: (string|null);

        /** ProjectConfig schemaSuffix */
        schemaSuffix?: (string|null);

        /** ProjectConfig tablePrefix */
        tablePrefix?: (string|null);

        /** ProjectConfig builtinAssertionNamePrefix */
        builtinAssertionNamePrefix?: (string|null);

        /** ProjectConfig defaultNotebookRuntimeOptions */
        defaultNotebookRuntimeOptions?: (dataform.INotebookRuntimeOptions|null);

        /** ProjectConfig defaultIcebergConfig */
        defaultIcebergConfig?: (dataform.IDefaultIcebergConfig|null);

        /** ProjectConfig disableAssertions */
        disableAssertions?: (boolean|null);

        /** ProjectConfig defaultReservation */
        defaultReservation?: (string|null);

        /** ProjectConfig includeTestsInCompiledGraph */
        includeTestsInCompiledGraph?: (boolean|null);
    }

    /** Represents a ProjectConfig. */
    class ProjectConfig implements IProjectConfig {

        /**
         * Constructs a new ProjectConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IProjectConfig);

        /** ProjectConfig warehouse. */
        public warehouse: string;

        /** ProjectConfig defaultDatabase. */
        public defaultDatabase: string;

        /** ProjectConfig defaultSchema. */
        public defaultSchema: string;

        /** ProjectConfig defaultLocation. */
        public defaultLocation: string;

        /** ProjectConfig assertionSchema. */
        public assertionSchema: string;

        /** ProjectConfig vars. */
        public vars: { [k: string]: string };

        /** ProjectConfig databaseSuffix. */
        public databaseSuffix: string;

        /** ProjectConfig schemaSuffix. */
        public schemaSuffix: string;

        /** ProjectConfig tablePrefix. */
        public tablePrefix: string;

        /** ProjectConfig builtinAssertionNamePrefix. */
        public builtinAssertionNamePrefix: string;

        /** ProjectConfig defaultNotebookRuntimeOptions. */
        public defaultNotebookRuntimeOptions?: (dataform.INotebookRuntimeOptions|null);

        /** ProjectConfig defaultIcebergConfig. */
        public defaultIcebergConfig?: (dataform.IDefaultIcebergConfig|null);

        /** ProjectConfig disableAssertions. */
        public disableAssertions: boolean;

        /** ProjectConfig defaultReservation. */
        public defaultReservation: string;

        /** ProjectConfig includeTestsInCompiledGraph. */
        public includeTestsInCompiledGraph: boolean;

        /**
         * Creates a new ProjectConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ProjectConfig instance
         */
        public static create(properties?: dataform.IProjectConfig): dataform.ProjectConfig;

        /**
         * Encodes the specified ProjectConfig message. Does not implicitly {@link dataform.ProjectConfig.verify|verify} messages.
         * @param message ProjectConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IProjectConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ProjectConfig message, length delimited. Does not implicitly {@link dataform.ProjectConfig.verify|verify} messages.
         * @param message ProjectConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IProjectConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a ProjectConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ProjectConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ProjectConfig;

        /**
         * Decodes a ProjectConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ProjectConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ProjectConfig;

        /**
         * Verifies a ProjectConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a ProjectConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ProjectConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.ProjectConfig;

        /**
         * Creates a plain object from a ProjectConfig message. Also converts values to other types if specified.
         * @param message ProjectConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ProjectConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ProjectConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ProjectConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CompileConfig. */
    interface ICompileConfig {

        /** CompileConfig projectDir */
        projectDir?: (string|null);

        /** CompileConfig filePaths */
        filePaths?: (string[]|null);

        /** CompileConfig projectConfigOverride */
        projectConfigOverride?: (dataform.IProjectConfig|null);

        /** CompileConfig timeoutMillis */
        timeoutMillis?: (number|null);

        /** CompileConfig extension */
        extension?: (dataform.IExtension|null);

        /** CompileConfig verbose */
        verbose?: (boolean|null);
    }

    /** Represents a CompileConfig. */
    class CompileConfig implements ICompileConfig {

        /**
         * Constructs a new CompileConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICompileConfig);

        /** CompileConfig projectDir. */
        public projectDir: string;

        /** CompileConfig filePaths. */
        public filePaths: string[];

        /** CompileConfig projectConfigOverride. */
        public projectConfigOverride?: (dataform.IProjectConfig|null);

        /** CompileConfig timeoutMillis. */
        public timeoutMillis: number;

        /** CompileConfig extension. */
        public extension?: (dataform.IExtension|null);

        /** CompileConfig verbose. */
        public verbose: boolean;

        /**
         * Creates a new CompileConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CompileConfig instance
         */
        public static create(properties?: dataform.ICompileConfig): dataform.CompileConfig;

        /**
         * Encodes the specified CompileConfig message. Does not implicitly {@link dataform.CompileConfig.verify|verify} messages.
         * @param message CompileConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICompileConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CompileConfig message, length delimited. Does not implicitly {@link dataform.CompileConfig.verify|verify} messages.
         * @param message CompileConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICompileConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CompileConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CompileConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CompileConfig;

        /**
         * Decodes a CompileConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CompileConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CompileConfig;

        /**
         * Verifies a CompileConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CompileConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CompileConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.CompileConfig;

        /**
         * Creates a plain object from a CompileConfig message. Also converts values to other types if specified.
         * @param message CompileConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CompileConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CompileConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CompileConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a Target. */
    interface ITarget {

        /** Target database */
        database?: (string|null);

        /** Target schema */
        schema?: (string|null);

        /** Target name */
        name?: (string|null);

        /** Target includeDependentAssertions */
        includeDependentAssertions?: (boolean|null);
    }

    /** Represents a Target. */
    class Target implements ITarget {

        /**
         * Constructs a new Target.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITarget);

        /** Target database. */
        public database: string;

        /** Target schema. */
        public schema: string;

        /** Target name. */
        public name: string;

        /** Target includeDependentAssertions. */
        public includeDependentAssertions: boolean;

        /**
         * Creates a new Target instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Target instance
         */
        public static create(properties?: dataform.ITarget): dataform.Target;

        /**
         * Encodes the specified Target message. Does not implicitly {@link dataform.Target.verify|verify} messages.
         * @param message Target message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITarget, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Target message, length delimited. Does not implicitly {@link dataform.Target.verify|verify} messages.
         * @param message Target message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITarget, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Target message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Target
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Target;

        /**
         * Decodes a Target message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Target
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Target;

        /**
         * Verifies a Target message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Target message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Target
         */
        public static fromObject(object: { [k: string]: any }): dataform.Target;

        /**
         * Creates a plain object from a Target message. Also converts values to other types if specified.
         * @param message Target
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Target, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Target to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Target
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** FileFormat enum. */
    enum FileFormat {
        FILE_FORMAT_UNSPECIFIED = 0,
        PARQUET = 1
    }

    /** TableFormat enum. */
    enum TableFormat {
        TABLE_FORMAT_UNSPECIFIED = 0,
        ICEBERG = 1
    }

    /** Properties of a BigQueryOptions. */
    interface IBigQueryOptions {

        /** BigQueryOptions partitionBy */
        partitionBy?: (string|null);

        /** BigQueryOptions clusterBy */
        clusterBy?: (string[]|null);

        /** BigQueryOptions updatePartitionFilter */
        updatePartitionFilter?: (string|null);

        /** BigQueryOptions labels */
        labels?: ({ [k: string]: string }|null);

        /** BigQueryOptions partitionExpirationDays */
        partitionExpirationDays?: (number|null);

        /** BigQueryOptions requirePartitionFilter */
        requirePartitionFilter?: (boolean|null);

        /** BigQueryOptions additionalOptions */
        additionalOptions?: ({ [k: string]: string }|null);

        /** BigQueryOptions connection */
        connection?: (string|null);

        /** BigQueryOptions tableFormat */
        tableFormat?: (dataform.TableFormat|null);

        /** BigQueryOptions fileFormat */
        fileFormat?: (dataform.FileFormat|null);

        /** BigQueryOptions storageUri */
        storageUri?: (string|null);
    }

    /** Represents a BigQueryOptions. */
    class BigQueryOptions implements IBigQueryOptions {

        /**
         * Constructs a new BigQueryOptions.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IBigQueryOptions);

        /** BigQueryOptions partitionBy. */
        public partitionBy: string;

        /** BigQueryOptions clusterBy. */
        public clusterBy: string[];

        /** BigQueryOptions updatePartitionFilter. */
        public updatePartitionFilter: string;

        /** BigQueryOptions labels. */
        public labels: { [k: string]: string };

        /** BigQueryOptions partitionExpirationDays. */
        public partitionExpirationDays: number;

        /** BigQueryOptions requirePartitionFilter. */
        public requirePartitionFilter: boolean;

        /** BigQueryOptions additionalOptions. */
        public additionalOptions: { [k: string]: string };

        /** BigQueryOptions connection. */
        public connection: string;

        /** BigQueryOptions tableFormat. */
        public tableFormat: dataform.TableFormat;

        /** BigQueryOptions fileFormat. */
        public fileFormat: dataform.FileFormat;

        /** BigQueryOptions storageUri. */
        public storageUri: string;

        /**
         * Creates a new BigQueryOptions instance using the specified properties.
         * @param [properties] Properties to set
         * @returns BigQueryOptions instance
         */
        public static create(properties?: dataform.IBigQueryOptions): dataform.BigQueryOptions;

        /**
         * Encodes the specified BigQueryOptions message. Does not implicitly {@link dataform.BigQueryOptions.verify|verify} messages.
         * @param message BigQueryOptions message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IBigQueryOptions, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified BigQueryOptions message, length delimited. Does not implicitly {@link dataform.BigQueryOptions.verify|verify} messages.
         * @param message BigQueryOptions message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IBigQueryOptions, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a BigQueryOptions message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns BigQueryOptions
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.BigQueryOptions;

        /**
         * Decodes a BigQueryOptions message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns BigQueryOptions
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.BigQueryOptions;

        /**
         * Verifies a BigQueryOptions message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a BigQueryOptions message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns BigQueryOptions
         */
        public static fromObject(object: { [k: string]: any }): dataform.BigQueryOptions;

        /**
         * Creates a plain object from a BigQueryOptions message. Also converts values to other types if specified.
         * @param message BigQueryOptions
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.BigQueryOptions, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this BigQueryOptions to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for BigQueryOptions
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a GraphErrors. */
    interface IGraphErrors {

        /** GraphErrors compilationErrors */
        compilationErrors?: (dataform.ICompilationError[]|null);
    }

    /** Represents a GraphErrors. */
    class GraphErrors implements IGraphErrors {

        /**
         * Constructs a new GraphErrors.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IGraphErrors);

        /** GraphErrors compilationErrors. */
        public compilationErrors: dataform.ICompilationError[];

        /**
         * Creates a new GraphErrors instance using the specified properties.
         * @param [properties] Properties to set
         * @returns GraphErrors instance
         */
        public static create(properties?: dataform.IGraphErrors): dataform.GraphErrors;

        /**
         * Encodes the specified GraphErrors message. Does not implicitly {@link dataform.GraphErrors.verify|verify} messages.
         * @param message GraphErrors message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IGraphErrors, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified GraphErrors message, length delimited. Does not implicitly {@link dataform.GraphErrors.verify|verify} messages.
         * @param message GraphErrors message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IGraphErrors, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a GraphErrors message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns GraphErrors
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.GraphErrors;

        /**
         * Decodes a GraphErrors message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns GraphErrors
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.GraphErrors;

        /**
         * Verifies a GraphErrors message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a GraphErrors message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns GraphErrors
         */
        public static fromObject(object: { [k: string]: any }): dataform.GraphErrors;

        /**
         * Creates a plain object from a GraphErrors message. Also converts values to other types if specified.
         * @param message GraphErrors
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.GraphErrors, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this GraphErrors to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for GraphErrors
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CompilationError. */
    interface ICompilationError {

        /** CompilationError fileName */
        fileName?: (string|null);

        /** CompilationError actionName */
        actionName?: (string|null);

        /** CompilationError actionTarget */
        actionTarget?: (dataform.ITarget|null);

        /** CompilationError message */
        message?: (string|null);

        /** CompilationError stack */
        stack?: (string|null);
    }

    /** Represents a CompilationError. */
    class CompilationError implements ICompilationError {

        /**
         * Constructs a new CompilationError.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICompilationError);

        /** CompilationError fileName. */
        public fileName: string;

        /** CompilationError actionName. */
        public actionName: string;

        /** CompilationError actionTarget. */
        public actionTarget?: (dataform.ITarget|null);

        /** CompilationError message. */
        public message: string;

        /** CompilationError stack. */
        public stack: string;

        /**
         * Creates a new CompilationError instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CompilationError instance
         */
        public static create(properties?: dataform.ICompilationError): dataform.CompilationError;

        /**
         * Encodes the specified CompilationError message. Does not implicitly {@link dataform.CompilationError.verify|verify} messages.
         * @param message CompilationError message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICompilationError, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CompilationError message, length delimited. Does not implicitly {@link dataform.CompilationError.verify|verify} messages.
         * @param message CompilationError message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICompilationError, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CompilationError message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CompilationError
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CompilationError;

        /**
         * Decodes a CompilationError message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CompilationError
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CompilationError;

        /**
         * Verifies a CompilationError message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CompilationError message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CompilationError
         */
        public static fromObject(object: { [k: string]: any }): dataform.CompilationError;

        /**
         * Creates a plain object from a CompilationError message. Also converts values to other types if specified.
         * @param message CompilationError
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CompilationError, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CompilationError to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CompilationError
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** ActionCompilationMode enum. */
    enum ActionCompilationMode {
        ACTION_COMPILATION_MODE_UNSPECIFIED = 0,
        ACTION_COMPILATION_MODE_AOT = 1,
        ACTION_COMPILATION_MODE_JIT = 2
    }

    /** Properties of an ActionDescriptor. */
    interface IActionDescriptor {

        /** ActionDescriptor description */
        description?: (string|null);

        /** ActionDescriptor columns */
        columns?: (dataform.IColumnDescriptor[]|null);

        /** ActionDescriptor bigqueryLabels */
        bigqueryLabels?: ({ [k: string]: string }|null);

        /** ActionDescriptor metadata */
        metadata?: (dataform.IMetadata|null);

        /** ActionDescriptor compilationMode */
        compilationMode?: (dataform.ActionCompilationMode|null);

        /** ActionDescriptor reservation */
        reservation?: (string|null);
    }

    /** Represents an ActionDescriptor. */
    class ActionDescriptor implements IActionDescriptor {

        /**
         * Constructs a new ActionDescriptor.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IActionDescriptor);

        /** ActionDescriptor description. */
        public description: string;

        /** ActionDescriptor columns. */
        public columns: dataform.IColumnDescriptor[];

        /** ActionDescriptor bigqueryLabels. */
        public bigqueryLabels: { [k: string]: string };

        /** ActionDescriptor metadata. */
        public metadata?: (dataform.IMetadata|null);

        /** ActionDescriptor compilationMode. */
        public compilationMode: dataform.ActionCompilationMode;

        /** ActionDescriptor reservation. */
        public reservation: string;

        /**
         * Creates a new ActionDescriptor instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ActionDescriptor instance
         */
        public static create(properties?: dataform.IActionDescriptor): dataform.ActionDescriptor;

        /**
         * Encodes the specified ActionDescriptor message. Does not implicitly {@link dataform.ActionDescriptor.verify|verify} messages.
         * @param message ActionDescriptor message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IActionDescriptor, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ActionDescriptor message, length delimited. Does not implicitly {@link dataform.ActionDescriptor.verify|verify} messages.
         * @param message ActionDescriptor message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IActionDescriptor, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ActionDescriptor message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ActionDescriptor
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionDescriptor;

        /**
         * Decodes an ActionDescriptor message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ActionDescriptor
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionDescriptor;

        /**
         * Verifies an ActionDescriptor message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ActionDescriptor message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ActionDescriptor
         */
        public static fromObject(object: { [k: string]: any }): dataform.ActionDescriptor;

        /**
         * Creates a plain object from an ActionDescriptor message. Also converts values to other types if specified.
         * @param message ActionDescriptor
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ActionDescriptor, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ActionDescriptor to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ActionDescriptor
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a Metadata. */
    interface IMetadata {

        /** Metadata overview */
        overview?: (string|null);

        /** Metadata extraProperties */
        extraProperties?: (google.protobuf.IStruct|null);
    }

    /** Represents a Metadata. */
    class Metadata implements IMetadata {

        /**
         * Constructs a new Metadata.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IMetadata);

        /** Metadata overview. */
        public overview: string;

        /** Metadata extraProperties. */
        public extraProperties?: (google.protobuf.IStruct|null);

        /**
         * Creates a new Metadata instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Metadata instance
         */
        public static create(properties?: dataform.IMetadata): dataform.Metadata;

        /**
         * Encodes the specified Metadata message. Does not implicitly {@link dataform.Metadata.verify|verify} messages.
         * @param message Metadata message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Metadata message, length delimited. Does not implicitly {@link dataform.Metadata.verify|verify} messages.
         * @param message Metadata message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Metadata message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Metadata
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Metadata;

        /**
         * Decodes a Metadata message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Metadata
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Metadata;

        /**
         * Verifies a Metadata message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Metadata message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Metadata
         */
        public static fromObject(object: { [k: string]: any }): dataform.Metadata;

        /**
         * Creates a plain object from a Metadata message. Also converts values to other types if specified.
         * @param message Metadata
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Metadata, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Metadata to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Metadata
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a ColumnDescriptor. */
    interface IColumnDescriptor {

        /** ColumnDescriptor description */
        description?: (string|null);

        /** ColumnDescriptor path */
        path?: (string[]|null);

        /** ColumnDescriptor displayName */
        displayName?: (string|null);

        /** ColumnDescriptor tags */
        tags?: (string[]|null);

        /** ColumnDescriptor bigqueryPolicyTags */
        bigqueryPolicyTags?: (string[]|null);
    }

    /** Represents a ColumnDescriptor. */
    class ColumnDescriptor implements IColumnDescriptor {

        /**
         * Constructs a new ColumnDescriptor.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IColumnDescriptor);

        /** ColumnDescriptor description. */
        public description: string;

        /** ColumnDescriptor path. */
        public path: string[];

        /** ColumnDescriptor displayName. */
        public displayName: string;

        /** ColumnDescriptor tags. */
        public tags: string[];

        /** ColumnDescriptor bigqueryPolicyTags. */
        public bigqueryPolicyTags: string[];

        /**
         * Creates a new ColumnDescriptor instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ColumnDescriptor instance
         */
        public static create(properties?: dataform.IColumnDescriptor): dataform.ColumnDescriptor;

        /**
         * Encodes the specified ColumnDescriptor message. Does not implicitly {@link dataform.ColumnDescriptor.verify|verify} messages.
         * @param message ColumnDescriptor message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IColumnDescriptor, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ColumnDescriptor message, length delimited. Does not implicitly {@link dataform.ColumnDescriptor.verify|verify} messages.
         * @param message ColumnDescriptor message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IColumnDescriptor, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a ColumnDescriptor message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ColumnDescriptor
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ColumnDescriptor;

        /**
         * Decodes a ColumnDescriptor message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ColumnDescriptor
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ColumnDescriptor;

        /**
         * Verifies a ColumnDescriptor message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a ColumnDescriptor message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ColumnDescriptor
         */
        public static fromObject(object: { [k: string]: any }): dataform.ColumnDescriptor;

        /**
         * Creates a plain object from a ColumnDescriptor message. Also converts values to other types if specified.
         * @param message ColumnDescriptor
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ColumnDescriptor, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ColumnDescriptor to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ColumnDescriptor
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** TableType enum. */
    enum TableType {
        UNKNOWN_TYPE = 0,
        TABLE = 1,
        INCREMENTAL = 2,
        VIEW = 3
    }

    /** OnSchemaChange enum. */
    enum OnSchemaChange {
        IGNORE = 0,
        FAIL = 1,
        EXTEND = 2,
        SYNCHRONIZE = 3
    }

    /** Properties of a Table. */
    interface ITable {

        /** Table enumType */
        enumType?: (dataform.TableType|null);

        /** Table target */
        target?: (dataform.ITarget|null);

        /** Table canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** Table dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);

        /** Table hermeticity */
        hermeticity?: (dataform.ActionHermeticity|null);

        /** Table disabled */
        disabled?: (boolean|null);

        /** Table type */
        type?: (string|null);

        /** Table query */
        query?: (string|null);

        /** Table protected */
        "protected"?: (boolean|null);

        /** Table materialized */
        materialized?: (boolean|null);

        /** Table actionDescriptor */
        actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Table tags */
        tags?: (string[]|null);

        /** Table where */
        where?: (string|null);

        /** Table incrementalQuery */
        incrementalQuery?: (string|null);

        /** Table uniqueKey */
        uniqueKey?: (string[]|null);

        /** Table onSchemaChange */
        onSchemaChange?: (dataform.OnSchemaChange|null);

        /** Table preOps */
        preOps?: (string[]|null);

        /** Table postOps */
        postOps?: (string[]|null);

        /** Table incrementalPreOps */
        incrementalPreOps?: (string[]|null);

        /** Table incrementalPostOps */
        incrementalPostOps?: (string[]|null);

        /** Table jitCode */
        jitCode?: (string|null);

        /** Table bigquery */
        bigquery?: (dataform.IBigQueryOptions|null);

        /** Table fileName */
        fileName?: (string|null);
    }

    /** Represents a Table. */
    class Table implements ITable {

        /**
         * Constructs a new Table.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITable);

        /** Table enumType. */
        public enumType: dataform.TableType;

        /** Table target. */
        public target?: (dataform.ITarget|null);

        /** Table canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** Table dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /** Table hermeticity. */
        public hermeticity: dataform.ActionHermeticity;

        /** Table disabled. */
        public disabled: boolean;

        /** Table type. */
        public type: string;

        /** Table query. */
        public query: string;

        /** Table protected. */
        public protected: boolean;

        /** Table materialized. */
        public materialized: boolean;

        /** Table actionDescriptor. */
        public actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Table tags. */
        public tags: string[];

        /** Table where. */
        public where: string;

        /** Table incrementalQuery. */
        public incrementalQuery: string;

        /** Table uniqueKey. */
        public uniqueKey: string[];

        /** Table onSchemaChange. */
        public onSchemaChange: dataform.OnSchemaChange;

        /** Table preOps. */
        public preOps: string[];

        /** Table postOps. */
        public postOps: string[];

        /** Table incrementalPreOps. */
        public incrementalPreOps: string[];

        /** Table incrementalPostOps. */
        public incrementalPostOps: string[];

        /** Table jitCode. */
        public jitCode: string;

        /** Table bigquery. */
        public bigquery?: (dataform.IBigQueryOptions|null);

        /** Table fileName. */
        public fileName: string;

        /**
         * Creates a new Table instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Table instance
         */
        public static create(properties?: dataform.ITable): dataform.Table;

        /**
         * Encodes the specified Table message. Does not implicitly {@link dataform.Table.verify|verify} messages.
         * @param message Table message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITable, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Table message, length delimited. Does not implicitly {@link dataform.Table.verify|verify} messages.
         * @param message Table message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITable, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Table message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Table
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Table;

        /**
         * Decodes a Table message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Table
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Table;

        /**
         * Verifies a Table message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Table message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Table
         */
        public static fromObject(object: { [k: string]: any }): dataform.Table;

        /**
         * Creates a plain object from a Table message. Also converts values to other types if specified.
         * @param message Table
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Table, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Table to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Table
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an Operation. */
    interface IOperation {

        /** Operation target */
        target?: (dataform.ITarget|null);

        /** Operation canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** Operation dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);

        /** Operation hermeticity */
        hermeticity?: (dataform.ActionHermeticity|null);

        /** Operation disabled */
        disabled?: (boolean|null);

        /** Operation queries */
        queries?: (string[]|null);

        /** Operation jitCode */
        jitCode?: (string|null);

        /** Operation hasOutput */
        hasOutput?: (boolean|null);

        /** Operation tags */
        tags?: (string[]|null);

        /** Operation actionDescriptor */
        actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Operation fileName */
        fileName?: (string|null);
    }

    /** Represents an Operation. */
    class Operation implements IOperation {

        /**
         * Constructs a new Operation.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IOperation);

        /** Operation target. */
        public target?: (dataform.ITarget|null);

        /** Operation canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** Operation dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /** Operation hermeticity. */
        public hermeticity: dataform.ActionHermeticity;

        /** Operation disabled. */
        public disabled: boolean;

        /** Operation queries. */
        public queries: string[];

        /** Operation jitCode. */
        public jitCode: string;

        /** Operation hasOutput. */
        public hasOutput: boolean;

        /** Operation tags. */
        public tags: string[];

        /** Operation actionDescriptor. */
        public actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Operation fileName. */
        public fileName: string;

        /**
         * Creates a new Operation instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Operation instance
         */
        public static create(properties?: dataform.IOperation): dataform.Operation;

        /**
         * Encodes the specified Operation message. Does not implicitly {@link dataform.Operation.verify|verify} messages.
         * @param message Operation message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IOperation, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Operation message, length delimited. Does not implicitly {@link dataform.Operation.verify|verify} messages.
         * @param message Operation message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IOperation, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an Operation message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Operation
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Operation;

        /**
         * Decodes an Operation message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Operation
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Operation;

        /**
         * Verifies an Operation message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an Operation message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Operation
         */
        public static fromObject(object: { [k: string]: any }): dataform.Operation;

        /**
         * Creates a plain object from an Operation message. Also converts values to other types if specified.
         * @param message Operation
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Operation, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Operation to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Operation
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an Assertion. */
    interface IAssertion {

        /** Assertion target */
        target?: (dataform.ITarget|null);

        /** Assertion canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** Assertion dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);

        /** Assertion hermeticity */
        hermeticity?: (dataform.ActionHermeticity|null);

        /** Assertion disabled */
        disabled?: (boolean|null);

        /** Assertion query */
        query?: (string|null);

        /** Assertion tags */
        tags?: (string[]|null);

        /** Assertion actionDescriptor */
        actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Assertion parentAction */
        parentAction?: (dataform.ITarget|null);

        /** Assertion jitCode */
        jitCode?: (string|null);

        /** Assertion fileName */
        fileName?: (string|null);
    }

    /** Represents an Assertion. */
    class Assertion implements IAssertion {

        /**
         * Constructs a new Assertion.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IAssertion);

        /** Assertion target. */
        public target?: (dataform.ITarget|null);

        /** Assertion canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** Assertion dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /** Assertion hermeticity. */
        public hermeticity: dataform.ActionHermeticity;

        /** Assertion disabled. */
        public disabled: boolean;

        /** Assertion query. */
        public query: string;

        /** Assertion tags. */
        public tags: string[];

        /** Assertion actionDescriptor. */
        public actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Assertion parentAction. */
        public parentAction?: (dataform.ITarget|null);

        /** Assertion jitCode. */
        public jitCode: string;

        /** Assertion fileName. */
        public fileName: string;

        /**
         * Creates a new Assertion instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Assertion instance
         */
        public static create(properties?: dataform.IAssertion): dataform.Assertion;

        /**
         * Encodes the specified Assertion message. Does not implicitly {@link dataform.Assertion.verify|verify} messages.
         * @param message Assertion message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IAssertion, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Assertion message, length delimited. Does not implicitly {@link dataform.Assertion.verify|verify} messages.
         * @param message Assertion message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IAssertion, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an Assertion message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Assertion
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Assertion;

        /**
         * Decodes an Assertion message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Assertion
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Assertion;

        /**
         * Verifies an Assertion message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an Assertion message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Assertion
         */
        public static fromObject(object: { [k: string]: any }): dataform.Assertion;

        /**
         * Creates a plain object from an Assertion message. Also converts values to other types if specified.
         * @param message Assertion
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Assertion, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Assertion to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Assertion
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** ActionHermeticity enum. */
    enum ActionHermeticity {
        UNKNOWN = 0,
        HERMETIC = 1,
        NON_HERMETIC = 2
    }

    /** Properties of a Declaration. */
    interface IDeclaration {

        /** Declaration target */
        target?: (dataform.ITarget|null);

        /** Declaration canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** Declaration actionDescriptor */
        actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Declaration fileName */
        fileName?: (string|null);

        /** Declaration tags */
        tags?: (string[]|null);
    }

    /** Represents a Declaration. */
    class Declaration implements IDeclaration {

        /**
         * Constructs a new Declaration.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IDeclaration);

        /** Declaration target. */
        public target?: (dataform.ITarget|null);

        /** Declaration canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** Declaration actionDescriptor. */
        public actionDescriptor?: (dataform.IActionDescriptor|null);

        /** Declaration fileName. */
        public fileName: string;

        /** Declaration tags. */
        public tags: string[];

        /**
         * Creates a new Declaration instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Declaration instance
         */
        public static create(properties?: dataform.IDeclaration): dataform.Declaration;

        /**
         * Encodes the specified Declaration message. Does not implicitly {@link dataform.Declaration.verify|verify} messages.
         * @param message Declaration message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IDeclaration, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Declaration message, length delimited. Does not implicitly {@link dataform.Declaration.verify|verify} messages.
         * @param message Declaration message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IDeclaration, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Declaration message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Declaration
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Declaration;

        /**
         * Decodes a Declaration message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Declaration
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Declaration;

        /**
         * Verifies a Declaration message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Declaration message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Declaration
         */
        public static fromObject(object: { [k: string]: any }): dataform.Declaration;

        /**
         * Creates a plain object from a Declaration message. Also converts values to other types if specified.
         * @param message Declaration
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Declaration, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Declaration to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Declaration
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a Test. */
    interface ITest {

        /** Test name */
        name?: (string|null);

        /** Test testQuery */
        testQuery?: (string|null);

        /** Test expectedOutputQuery */
        expectedOutputQuery?: (string|null);

        /** Test jitCode */
        jitCode?: (string|null);

        /** Test fileName */
        fileName?: (string|null);

        /** Test disabled */
        disabled?: (boolean|null);

        /** Test tags */
        tags?: (string[]|null);

        /** Test target */
        target?: (dataform.ITarget|null);

        /** Test canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** Test dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);
    }

    /** Represents a Test. */
    class Test implements ITest {

        /**
         * Constructs a new Test.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITest);

        /** Test name. */
        public name: string;

        /** Test testQuery. */
        public testQuery: string;

        /** Test expectedOutputQuery. */
        public expectedOutputQuery: string;

        /** Test jitCode. */
        public jitCode: string;

        /** Test fileName. */
        public fileName: string;

        /** Test disabled. */
        public disabled: boolean;

        /** Test tags. */
        public tags: string[];

        /** Test target. */
        public target?: (dataform.ITarget|null);

        /** Test canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** Test dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /**
         * Creates a new Test instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Test instance
         */
        public static create(properties?: dataform.ITest): dataform.Test;

        /**
         * Encodes the specified Test message. Does not implicitly {@link dataform.Test.verify|verify} messages.
         * @param message Test message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Test message, length delimited. Does not implicitly {@link dataform.Test.verify|verify} messages.
         * @param message Test message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Test message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Test
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Test;

        /**
         * Decodes a Test message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Test
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Test;

        /**
         * Verifies a Test message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Test message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Test
         */
        public static fromObject(object: { [k: string]: any }): dataform.Test;

        /**
         * Creates a plain object from a Test message. Also converts values to other types if specified.
         * @param message Test
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Test, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Test to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Test
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a Notebook. */
    interface INotebook {

        /** Notebook target */
        target?: (dataform.ITarget|null);

        /** Notebook canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** Notebook tags */
        tags?: (string[]|null);

        /** Notebook dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);

        /** Notebook fileName */
        fileName?: (string|null);

        /** Notebook disabled */
        disabled?: (boolean|null);

        /** Notebook notebookContents */
        notebookContents?: (string|null);
    }

    /** Represents a Notebook. */
    class Notebook implements INotebook {

        /**
         * Constructs a new Notebook.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.INotebook);

        /** Notebook target. */
        public target?: (dataform.ITarget|null);

        /** Notebook canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** Notebook tags. */
        public tags: string[];

        /** Notebook dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /** Notebook fileName. */
        public fileName: string;

        /** Notebook disabled. */
        public disabled: boolean;

        /** Notebook notebookContents. */
        public notebookContents: string;

        /**
         * Creates a new Notebook instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Notebook instance
         */
        public static create(properties?: dataform.INotebook): dataform.Notebook;

        /**
         * Encodes the specified Notebook message. Does not implicitly {@link dataform.Notebook.verify|verify} messages.
         * @param message Notebook message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.INotebook, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Notebook message, length delimited. Does not implicitly {@link dataform.Notebook.verify|verify} messages.
         * @param message Notebook message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.INotebook, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Notebook message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Notebook
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Notebook;

        /**
         * Decodes a Notebook message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Notebook
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Notebook;

        /**
         * Verifies a Notebook message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Notebook message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Notebook
         */
        public static fromObject(object: { [k: string]: any }): dataform.Notebook;

        /**
         * Creates a plain object from a Notebook message. Also converts values to other types if specified.
         * @param message Notebook
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Notebook, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Notebook to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Notebook
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a RepositorySnapshotDestination. */
    interface IRepositorySnapshotDestination {

        /** RepositorySnapshotDestination repositorySnapshotUri */
        repositorySnapshotUri?: (string|null);
    }

    /** Represents a RepositorySnapshotDestination. */
    class RepositorySnapshotDestination implements IRepositorySnapshotDestination {

        /**
         * Constructs a new RepositorySnapshotDestination.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IRepositorySnapshotDestination);

        /** RepositorySnapshotDestination repositorySnapshotUri. */
        public repositorySnapshotUri: string;

        /**
         * Creates a new RepositorySnapshotDestination instance using the specified properties.
         * @param [properties] Properties to set
         * @returns RepositorySnapshotDestination instance
         */
        public static create(properties?: dataform.IRepositorySnapshotDestination): dataform.RepositorySnapshotDestination;

        /**
         * Encodes the specified RepositorySnapshotDestination message. Does not implicitly {@link dataform.RepositorySnapshotDestination.verify|verify} messages.
         * @param message RepositorySnapshotDestination message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IRepositorySnapshotDestination, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified RepositorySnapshotDestination message, length delimited. Does not implicitly {@link dataform.RepositorySnapshotDestination.verify|verify} messages.
         * @param message RepositorySnapshotDestination message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IRepositorySnapshotDestination, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a RepositorySnapshotDestination message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns RepositorySnapshotDestination
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.RepositorySnapshotDestination;

        /**
         * Decodes a RepositorySnapshotDestination message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns RepositorySnapshotDestination
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.RepositorySnapshotDestination;

        /**
         * Verifies a RepositorySnapshotDestination message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a RepositorySnapshotDestination message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns RepositorySnapshotDestination
         */
        public static fromObject(object: { [k: string]: any }): dataform.RepositorySnapshotDestination;

        /**
         * Creates a plain object from a RepositorySnapshotDestination message. Also converts values to other types if specified.
         * @param message RepositorySnapshotDestination
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.RepositorySnapshotDestination, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this RepositorySnapshotDestination to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for RepositorySnapshotDestination
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a NotebookRuntimeOptions. */
    interface INotebookRuntimeOptions {

        /** NotebookRuntimeOptions outputBucket */
        outputBucket?: (string|null);

        /** NotebookRuntimeOptions runtimeTemplateName */
        runtimeTemplateName?: (string|null);

        /** NotebookRuntimeOptions repositorySnapshotDestination */
        repositorySnapshotDestination?: (dataform.IRepositorySnapshotDestination|null);
    }

    /** Represents a NotebookRuntimeOptions. */
    class NotebookRuntimeOptions implements INotebookRuntimeOptions {

        /**
         * Constructs a new NotebookRuntimeOptions.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.INotebookRuntimeOptions);

        /** NotebookRuntimeOptions outputBucket. */
        public outputBucket?: (string|null);

        /** NotebookRuntimeOptions runtimeTemplateName. */
        public runtimeTemplateName: string;

        /** NotebookRuntimeOptions repositorySnapshotDestination. */
        public repositorySnapshotDestination?: (dataform.IRepositorySnapshotDestination|null);

        /** NotebookRuntimeOptions outputSink. */
        public outputSink?: "outputBucket";

        /** NotebookRuntimeOptions repositorySnapshotStorage. */
        public repositorySnapshotStorage?: "repositorySnapshotDestination";

        /**
         * Creates a new NotebookRuntimeOptions instance using the specified properties.
         * @param [properties] Properties to set
         * @returns NotebookRuntimeOptions instance
         */
        public static create(properties?: dataform.INotebookRuntimeOptions): dataform.NotebookRuntimeOptions;

        /**
         * Encodes the specified NotebookRuntimeOptions message. Does not implicitly {@link dataform.NotebookRuntimeOptions.verify|verify} messages.
         * @param message NotebookRuntimeOptions message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.INotebookRuntimeOptions, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified NotebookRuntimeOptions message, length delimited. Does not implicitly {@link dataform.NotebookRuntimeOptions.verify|verify} messages.
         * @param message NotebookRuntimeOptions message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.INotebookRuntimeOptions, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a NotebookRuntimeOptions message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns NotebookRuntimeOptions
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.NotebookRuntimeOptions;

        /**
         * Decodes a NotebookRuntimeOptions message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns NotebookRuntimeOptions
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.NotebookRuntimeOptions;

        /**
         * Verifies a NotebookRuntimeOptions message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a NotebookRuntimeOptions message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns NotebookRuntimeOptions
         */
        public static fromObject(object: { [k: string]: any }): dataform.NotebookRuntimeOptions;

        /**
         * Creates a plain object from a NotebookRuntimeOptions message. Also converts values to other types if specified.
         * @param message NotebookRuntimeOptions
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.NotebookRuntimeOptions, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this NotebookRuntimeOptions to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for NotebookRuntimeOptions
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a DataPreparation. */
    interface IDataPreparation {

        /** DataPreparation target */
        target?: (dataform.ITarget|null);

        /** DataPreparation canonicalTarget */
        canonicalTarget?: (dataform.ITarget|null);

        /** DataPreparation targets */
        targets?: (dataform.ITarget[]|null);

        /** DataPreparation canonicalTargets */
        canonicalTargets?: (dataform.ITarget[]|null);

        /** DataPreparation tags */
        tags?: (string[]|null);

        /** DataPreparation dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);

        /** DataPreparation fileName */
        fileName?: (string|null);

        /** DataPreparation disabled */
        disabled?: (boolean|null);

        /** DataPreparation dataPreparationYaml */
        dataPreparationYaml?: (string|null);

        /** DataPreparation query */
        query?: (string|null);

        /** DataPreparation errorTable */
        errorTable?: (dataform.ITarget|null);

        /** DataPreparation errorTableRetentionDays */
        errorTableRetentionDays?: (number|null);

        /** DataPreparation load */
        load?: (dataform.ILoadConfiguration|null);
    }

    /** Represents a DataPreparation. */
    class DataPreparation implements IDataPreparation {

        /**
         * Constructs a new DataPreparation.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IDataPreparation);

        /** DataPreparation target. */
        public target?: (dataform.ITarget|null);

        /** DataPreparation canonicalTarget. */
        public canonicalTarget?: (dataform.ITarget|null);

        /** DataPreparation targets. */
        public targets: dataform.ITarget[];

        /** DataPreparation canonicalTargets. */
        public canonicalTargets: dataform.ITarget[];

        /** DataPreparation tags. */
        public tags: string[];

        /** DataPreparation dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /** DataPreparation fileName. */
        public fileName: string;

        /** DataPreparation disabled. */
        public disabled: boolean;

        /** DataPreparation dataPreparationYaml. */
        public dataPreparationYaml?: (string|null);

        /** DataPreparation query. */
        public query?: (string|null);

        /** DataPreparation errorTable. */
        public errorTable?: (dataform.ITarget|null);

        /** DataPreparation errorTableRetentionDays. */
        public errorTableRetentionDays: number;

        /** DataPreparation load. */
        public load?: (dataform.ILoadConfiguration|null);

        /** DataPreparation definition. */
        public definition?: ("dataPreparationYaml"|"query");

        /**
         * Creates a new DataPreparation instance using the specified properties.
         * @param [properties] Properties to set
         * @returns DataPreparation instance
         */
        public static create(properties?: dataform.IDataPreparation): dataform.DataPreparation;

        /**
         * Encodes the specified DataPreparation message. Does not implicitly {@link dataform.DataPreparation.verify|verify} messages.
         * @param message DataPreparation message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IDataPreparation, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified DataPreparation message, length delimited. Does not implicitly {@link dataform.DataPreparation.verify|verify} messages.
         * @param message DataPreparation message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IDataPreparation, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a DataPreparation message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns DataPreparation
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.DataPreparation;

        /**
         * Decodes a DataPreparation message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns DataPreparation
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.DataPreparation;

        /**
         * Verifies a DataPreparation message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a DataPreparation message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns DataPreparation
         */
        public static fromObject(object: { [k: string]: any }): dataform.DataPreparation;

        /**
         * Creates a plain object from a DataPreparation message. Also converts values to other types if specified.
         * @param message DataPreparation
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.DataPreparation, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this DataPreparation to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for DataPreparation
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a LoadConfiguration. */
    interface ILoadConfiguration {

        /** LoadConfiguration replace */
        replace?: (dataform.ISimpleLoadMode|null);

        /** LoadConfiguration append */
        append?: (dataform.ISimpleLoadMode|null);

        /** LoadConfiguration maximum */
        maximum?: (dataform.IIncrementalLoadMode|null);

        /** LoadConfiguration unique */
        unique?: (dataform.IIncrementalLoadMode|null);

        /** LoadConfiguration automatic */
        automatic?: (dataform.IIncrementalLoadMode|null);

        /** LoadConfiguration merge */
        merge?: (dataform.IMergeLoadMode|null);
    }

    /** Represents a LoadConfiguration. */
    class LoadConfiguration implements ILoadConfiguration {

        /**
         * Constructs a new LoadConfiguration.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ILoadConfiguration);

        /** LoadConfiguration replace. */
        public replace?: (dataform.ISimpleLoadMode|null);

        /** LoadConfiguration append. */
        public append?: (dataform.ISimpleLoadMode|null);

        /** LoadConfiguration maximum. */
        public maximum?: (dataform.IIncrementalLoadMode|null);

        /** LoadConfiguration unique. */
        public unique?: (dataform.IIncrementalLoadMode|null);

        /** LoadConfiguration automatic. */
        public automatic?: (dataform.IIncrementalLoadMode|null);

        /** LoadConfiguration merge. */
        public merge?: (dataform.IMergeLoadMode|null);

        /** LoadConfiguration mode. */
        public mode?: ("replace"|"append"|"maximum"|"unique"|"automatic"|"merge");

        /**
         * Creates a new LoadConfiguration instance using the specified properties.
         * @param [properties] Properties to set
         * @returns LoadConfiguration instance
         */
        public static create(properties?: dataform.ILoadConfiguration): dataform.LoadConfiguration;

        /**
         * Encodes the specified LoadConfiguration message. Does not implicitly {@link dataform.LoadConfiguration.verify|verify} messages.
         * @param message LoadConfiguration message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ILoadConfiguration, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified LoadConfiguration message, length delimited. Does not implicitly {@link dataform.LoadConfiguration.verify|verify} messages.
         * @param message LoadConfiguration message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ILoadConfiguration, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a LoadConfiguration message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns LoadConfiguration
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.LoadConfiguration;

        /**
         * Decodes a LoadConfiguration message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns LoadConfiguration
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.LoadConfiguration;

        /**
         * Verifies a LoadConfiguration message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a LoadConfiguration message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns LoadConfiguration
         */
        public static fromObject(object: { [k: string]: any }): dataform.LoadConfiguration;

        /**
         * Creates a plain object from a LoadConfiguration message. Also converts values to other types if specified.
         * @param message LoadConfiguration
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.LoadConfiguration, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this LoadConfiguration to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for LoadConfiguration
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a SimpleLoadMode. */
    interface ISimpleLoadMode {
    }

    /** Represents a SimpleLoadMode. */
    class SimpleLoadMode implements ISimpleLoadMode {

        /**
         * Constructs a new SimpleLoadMode.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ISimpleLoadMode);

        /**
         * Creates a new SimpleLoadMode instance using the specified properties.
         * @param [properties] Properties to set
         * @returns SimpleLoadMode instance
         */
        public static create(properties?: dataform.ISimpleLoadMode): dataform.SimpleLoadMode;

        /**
         * Encodes the specified SimpleLoadMode message. Does not implicitly {@link dataform.SimpleLoadMode.verify|verify} messages.
         * @param message SimpleLoadMode message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ISimpleLoadMode, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified SimpleLoadMode message, length delimited. Does not implicitly {@link dataform.SimpleLoadMode.verify|verify} messages.
         * @param message SimpleLoadMode message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ISimpleLoadMode, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a SimpleLoadMode message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns SimpleLoadMode
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.SimpleLoadMode;

        /**
         * Decodes a SimpleLoadMode message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns SimpleLoadMode
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.SimpleLoadMode;

        /**
         * Verifies a SimpleLoadMode message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a SimpleLoadMode message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns SimpleLoadMode
         */
        public static fromObject(object: { [k: string]: any }): dataform.SimpleLoadMode;

        /**
         * Creates a plain object from a SimpleLoadMode message. Also converts values to other types if specified.
         * @param message SimpleLoadMode
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.SimpleLoadMode, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this SimpleLoadMode to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for SimpleLoadMode
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an IncrementalLoadMode. */
    interface IIncrementalLoadMode {

        /** IncrementalLoadMode columnName */
        columnName?: (string|null);
    }

    /** Represents an IncrementalLoadMode. */
    class IncrementalLoadMode implements IIncrementalLoadMode {

        /**
         * Constructs a new IncrementalLoadMode.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IIncrementalLoadMode);

        /** IncrementalLoadMode columnName. */
        public columnName: string;

        /**
         * Creates a new IncrementalLoadMode instance using the specified properties.
         * @param [properties] Properties to set
         * @returns IncrementalLoadMode instance
         */
        public static create(properties?: dataform.IIncrementalLoadMode): dataform.IncrementalLoadMode;

        /**
         * Encodes the specified IncrementalLoadMode message. Does not implicitly {@link dataform.IncrementalLoadMode.verify|verify} messages.
         * @param message IncrementalLoadMode message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IIncrementalLoadMode, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified IncrementalLoadMode message, length delimited. Does not implicitly {@link dataform.IncrementalLoadMode.verify|verify} messages.
         * @param message IncrementalLoadMode message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IIncrementalLoadMode, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an IncrementalLoadMode message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns IncrementalLoadMode
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.IncrementalLoadMode;

        /**
         * Decodes an IncrementalLoadMode message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns IncrementalLoadMode
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.IncrementalLoadMode;

        /**
         * Verifies an IncrementalLoadMode message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an IncrementalLoadMode message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns IncrementalLoadMode
         */
        public static fromObject(object: { [k: string]: any }): dataform.IncrementalLoadMode;

        /**
         * Creates a plain object from an IncrementalLoadMode message. Also converts values to other types if specified.
         * @param message IncrementalLoadMode
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.IncrementalLoadMode, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this IncrementalLoadMode to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for IncrementalLoadMode
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a MergeLoadMode. */
    interface IMergeLoadMode {

        /** MergeLoadMode uniqueKey */
        uniqueKey?: (string[]|null);
    }

    /** Represents a MergeLoadMode. */
    class MergeLoadMode implements IMergeLoadMode {

        /**
         * Constructs a new MergeLoadMode.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IMergeLoadMode);

        /** MergeLoadMode uniqueKey. */
        public uniqueKey: string[];

        /**
         * Creates a new MergeLoadMode instance using the specified properties.
         * @param [properties] Properties to set
         * @returns MergeLoadMode instance
         */
        public static create(properties?: dataform.IMergeLoadMode): dataform.MergeLoadMode;

        /**
         * Encodes the specified MergeLoadMode message. Does not implicitly {@link dataform.MergeLoadMode.verify|verify} messages.
         * @param message MergeLoadMode message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IMergeLoadMode, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified MergeLoadMode message, length delimited. Does not implicitly {@link dataform.MergeLoadMode.verify|verify} messages.
         * @param message MergeLoadMode message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IMergeLoadMode, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a MergeLoadMode message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns MergeLoadMode
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.MergeLoadMode;

        /**
         * Decodes a MergeLoadMode message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns MergeLoadMode
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.MergeLoadMode;

        /**
         * Verifies a MergeLoadMode message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a MergeLoadMode message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns MergeLoadMode
         */
        public static fromObject(object: { [k: string]: any }): dataform.MergeLoadMode;

        /**
         * Creates a plain object from a MergeLoadMode message. Also converts values to other types if specified.
         * @param message MergeLoadMode
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.MergeLoadMode, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this MergeLoadMode to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for MergeLoadMode
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CompiledGraph. */
    interface ICompiledGraph {

        /** CompiledGraph projectConfig */
        projectConfig?: (dataform.IProjectConfig|null);

        /** CompiledGraph tables */
        tables?: (dataform.ITable[]|null);

        /** CompiledGraph operations */
        operations?: (dataform.IOperation[]|null);

        /** CompiledGraph assertions */
        assertions?: (dataform.IAssertion[]|null);

        /** CompiledGraph declarations */
        declarations?: (dataform.IDeclaration[]|null);

        /** CompiledGraph tests */
        tests?: (dataform.ITest[]|null);

        /** CompiledGraph notebooks */
        notebooks?: (dataform.INotebook[]|null);

        /** CompiledGraph dataPreparations */
        dataPreparations?: (dataform.IDataPreparation[]|null);

        /** CompiledGraph graphErrors */
        graphErrors?: (dataform.IGraphErrors|null);

        /** CompiledGraph dataformCoreVersion */
        dataformCoreVersion?: (string|null);

        /** CompiledGraph targets */
        targets?: (dataform.ITarget[]|null);

        /** CompiledGraph jitData */
        jitData?: (google.protobuf.IStruct|null);
    }

    /** Represents a CompiledGraph. */
    class CompiledGraph implements ICompiledGraph {

        /**
         * Constructs a new CompiledGraph.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICompiledGraph);

        /** CompiledGraph projectConfig. */
        public projectConfig?: (dataform.IProjectConfig|null);

        /** CompiledGraph tables. */
        public tables: dataform.ITable[];

        /** CompiledGraph operations. */
        public operations: dataform.IOperation[];

        /** CompiledGraph assertions. */
        public assertions: dataform.IAssertion[];

        /** CompiledGraph declarations. */
        public declarations: dataform.IDeclaration[];

        /** CompiledGraph tests. */
        public tests: dataform.ITest[];

        /** CompiledGraph notebooks. */
        public notebooks: dataform.INotebook[];

        /** CompiledGraph dataPreparations. */
        public dataPreparations: dataform.IDataPreparation[];

        /** CompiledGraph graphErrors. */
        public graphErrors?: (dataform.IGraphErrors|null);

        /** CompiledGraph dataformCoreVersion. */
        public dataformCoreVersion: string;

        /** CompiledGraph targets. */
        public targets: dataform.ITarget[];

        /** CompiledGraph jitData. */
        public jitData?: (google.protobuf.IStruct|null);

        /**
         * Creates a new CompiledGraph instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CompiledGraph instance
         */
        public static create(properties?: dataform.ICompiledGraph): dataform.CompiledGraph;

        /**
         * Encodes the specified CompiledGraph message. Does not implicitly {@link dataform.CompiledGraph.verify|verify} messages.
         * @param message CompiledGraph message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICompiledGraph, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CompiledGraph message, length delimited. Does not implicitly {@link dataform.CompiledGraph.verify|verify} messages.
         * @param message CompiledGraph message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICompiledGraph, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CompiledGraph message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CompiledGraph
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CompiledGraph;

        /**
         * Decodes a CompiledGraph message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CompiledGraph
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CompiledGraph;

        /**
         * Verifies a CompiledGraph message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CompiledGraph message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CompiledGraph
         */
        public static fromObject(object: { [k: string]: any }): dataform.CompiledGraph;

        /**
         * Creates a plain object from a CompiledGraph message. Also converts values to other types if specified.
         * @param message CompiledGraph
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CompiledGraph, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CompiledGraph to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CompiledGraph
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CoreExecutionRequest. */
    interface ICoreExecutionRequest {

        /** CoreExecutionRequest compile */
        compile?: (dataform.ICompileExecutionRequest|null);
    }

    /** Represents a CoreExecutionRequest. */
    class CoreExecutionRequest implements ICoreExecutionRequest {

        /**
         * Constructs a new CoreExecutionRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICoreExecutionRequest);

        /** CoreExecutionRequest compile. */
        public compile?: (dataform.ICompileExecutionRequest|null);

        /** CoreExecutionRequest request. */
        public request?: "compile";

        /**
         * Creates a new CoreExecutionRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CoreExecutionRequest instance
         */
        public static create(properties?: dataform.ICoreExecutionRequest): dataform.CoreExecutionRequest;

        /**
         * Encodes the specified CoreExecutionRequest message. Does not implicitly {@link dataform.CoreExecutionRequest.verify|verify} messages.
         * @param message CoreExecutionRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICoreExecutionRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CoreExecutionRequest message, length delimited. Does not implicitly {@link dataform.CoreExecutionRequest.verify|verify} messages.
         * @param message CoreExecutionRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICoreExecutionRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CoreExecutionRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CoreExecutionRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CoreExecutionRequest;

        /**
         * Decodes a CoreExecutionRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CoreExecutionRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CoreExecutionRequest;

        /**
         * Verifies a CoreExecutionRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CoreExecutionRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CoreExecutionRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.CoreExecutionRequest;

        /**
         * Creates a plain object from a CoreExecutionRequest message. Also converts values to other types if specified.
         * @param message CoreExecutionRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CoreExecutionRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CoreExecutionRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CoreExecutionRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CoreExecutionResponse. */
    interface ICoreExecutionResponse {

        /** CoreExecutionResponse compile */
        compile?: (dataform.ICompileExecutionResponse|null);
    }

    /** Represents a CoreExecutionResponse. */
    class CoreExecutionResponse implements ICoreExecutionResponse {

        /**
         * Constructs a new CoreExecutionResponse.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICoreExecutionResponse);

        /** CoreExecutionResponse compile. */
        public compile?: (dataform.ICompileExecutionResponse|null);

        /** CoreExecutionResponse response. */
        public response?: "compile";

        /**
         * Creates a new CoreExecutionResponse instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CoreExecutionResponse instance
         */
        public static create(properties?: dataform.ICoreExecutionResponse): dataform.CoreExecutionResponse;

        /**
         * Encodes the specified CoreExecutionResponse message. Does not implicitly {@link dataform.CoreExecutionResponse.verify|verify} messages.
         * @param message CoreExecutionResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICoreExecutionResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CoreExecutionResponse message, length delimited. Does not implicitly {@link dataform.CoreExecutionResponse.verify|verify} messages.
         * @param message CoreExecutionResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICoreExecutionResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CoreExecutionResponse message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CoreExecutionResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CoreExecutionResponse;

        /**
         * Decodes a CoreExecutionResponse message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CoreExecutionResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CoreExecutionResponse;

        /**
         * Verifies a CoreExecutionResponse message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CoreExecutionResponse message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CoreExecutionResponse
         */
        public static fromObject(object: { [k: string]: any }): dataform.CoreExecutionResponse;

        /**
         * Creates a plain object from a CoreExecutionResponse message. Also converts values to other types if specified.
         * @param message CoreExecutionResponse
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CoreExecutionResponse, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CoreExecutionResponse to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CoreExecutionResponse
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CompileExecutionRequest. */
    interface ICompileExecutionRequest {

        /** CompileExecutionRequest compileConfig */
        compileConfig?: (dataform.ICompileConfig|null);
    }

    /** Represents a CompileExecutionRequest. */
    class CompileExecutionRequest implements ICompileExecutionRequest {

        /**
         * Constructs a new CompileExecutionRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICompileExecutionRequest);

        /** CompileExecutionRequest compileConfig. */
        public compileConfig?: (dataform.ICompileConfig|null);

        /**
         * Creates a new CompileExecutionRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CompileExecutionRequest instance
         */
        public static create(properties?: dataform.ICompileExecutionRequest): dataform.CompileExecutionRequest;

        /**
         * Encodes the specified CompileExecutionRequest message. Does not implicitly {@link dataform.CompileExecutionRequest.verify|verify} messages.
         * @param message CompileExecutionRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICompileExecutionRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CompileExecutionRequest message, length delimited. Does not implicitly {@link dataform.CompileExecutionRequest.verify|verify} messages.
         * @param message CompileExecutionRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICompileExecutionRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CompileExecutionRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CompileExecutionRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CompileExecutionRequest;

        /**
         * Decodes a CompileExecutionRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CompileExecutionRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CompileExecutionRequest;

        /**
         * Verifies a CompileExecutionRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CompileExecutionRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CompileExecutionRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.CompileExecutionRequest;

        /**
         * Creates a plain object from a CompileExecutionRequest message. Also converts values to other types if specified.
         * @param message CompileExecutionRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CompileExecutionRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CompileExecutionRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CompileExecutionRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a CompileExecutionResponse. */
    interface ICompileExecutionResponse {

        /** CompileExecutionResponse compiledGraph */
        compiledGraph?: (dataform.ICompiledGraph|null);
    }

    /** Represents a CompileExecutionResponse. */
    class CompileExecutionResponse implements ICompileExecutionResponse {

        /**
         * Constructs a new CompileExecutionResponse.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ICompileExecutionResponse);

        /** CompileExecutionResponse compiledGraph. */
        public compiledGraph?: (dataform.ICompiledGraph|null);

        /**
         * Creates a new CompileExecutionResponse instance using the specified properties.
         * @param [properties] Properties to set
         * @returns CompileExecutionResponse instance
         */
        public static create(properties?: dataform.ICompileExecutionResponse): dataform.CompileExecutionResponse;

        /**
         * Encodes the specified CompileExecutionResponse message. Does not implicitly {@link dataform.CompileExecutionResponse.verify|verify} messages.
         * @param message CompileExecutionResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ICompileExecutionResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified CompileExecutionResponse message, length delimited. Does not implicitly {@link dataform.CompileExecutionResponse.verify|verify} messages.
         * @param message CompileExecutionResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ICompileExecutionResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a CompileExecutionResponse message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns CompileExecutionResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.CompileExecutionResponse;

        /**
         * Decodes a CompileExecutionResponse message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns CompileExecutionResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.CompileExecutionResponse;

        /**
         * Verifies a CompileExecutionResponse message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a CompileExecutionResponse message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns CompileExecutionResponse
         */
        public static fromObject(object: { [k: string]: any }): dataform.CompileExecutionResponse;

        /**
         * Creates a plain object from a CompileExecutionResponse message. Also converts values to other types if specified.
         * @param message CompileExecutionResponse
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.CompileExecutionResponse, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this CompileExecutionResponse to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for CompileExecutionResponse
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** SupportedFeatures enum. */
    enum SupportedFeatures {
        UNKNOWN_FEATURE = 0,
        ARRAY_BUFFER_IPC = 1
    }

    /** Properties of a Field. */
    interface IField {

        /** Field name */
        name?: (string|null);

        /** Field flags */
        flags?: (dataform.Field.Flag[]|null);

        /** Field primitive */
        primitive?: (dataform.Field.Primitive|null);

        /** Field struct */
        struct?: (dataform.IFields|null);

        /** Field description */
        description?: (string|null);
    }

    /** Represents a Field. */
    class Field implements IField {

        /**
         * Constructs a new Field.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IField);

        /** Field name. */
        public name: string;

        /** Field flags. */
        public flags: dataform.Field.Flag[];

        /** Field primitive. */
        public primitive?: (dataform.Field.Primitive|null);

        /** Field struct. */
        public struct?: (dataform.IFields|null);

        /** Field description. */
        public description: string;

        /** Field type. */
        public type?: ("primitive"|"struct");

        /**
         * Creates a new Field instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Field instance
         */
        public static create(properties?: dataform.IField): dataform.Field;

        /**
         * Encodes the specified Field message. Does not implicitly {@link dataform.Field.verify|verify} messages.
         * @param message Field message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IField, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Field message, length delimited. Does not implicitly {@link dataform.Field.verify|verify} messages.
         * @param message Field message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IField, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Field message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Field
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Field;

        /**
         * Decodes a Field message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Field
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Field;

        /**
         * Verifies a Field message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Field message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Field
         */
        public static fromObject(object: { [k: string]: any }): dataform.Field;

        /**
         * Creates a plain object from a Field message. Also converts values to other types if specified.
         * @param message Field
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Field, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Field to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Field
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace Field {

        /** Primitive enum. */
        enum Primitive {
            UNKNOWN = 0,
            INTEGER = 1,
            FLOAT = 2,
            NUMERIC = 5,
            BOOLEAN = 3,
            STRING = 4,
            DATE = 6,
            DATETIME = 7,
            TIMESTAMP = 8,
            TIME = 9,
            BYTES = 10,
            ANY = 11,
            GEOGRAPHY = 12,
            BIGNUMERIC = 13,
            JSON = 14,
            INTERVAL = 15
        }

        /** Flag enum. */
        enum Flag {
            UNKNOWN_FLAG = 0,
            REPEATED = 1
        }
    }

    /** Properties of a Fields. */
    interface IFields {

        /** Fields fields */
        fields?: (dataform.IField[]|null);
    }

    /** Represents a Fields. */
    class Fields implements IFields {

        /**
         * Constructs a new Fields.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IFields);

        /** Fields fields. */
        public fields: dataform.IField[];

        /**
         * Creates a new Fields instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Fields instance
         */
        public static create(properties?: dataform.IFields): dataform.Fields;

        /**
         * Encodes the specified Fields message. Does not implicitly {@link dataform.Fields.verify|verify} messages.
         * @param message Fields message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IFields, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Fields message, length delimited. Does not implicitly {@link dataform.Fields.verify|verify} messages.
         * @param message Fields message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IFields, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Fields message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Fields
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Fields;

        /**
         * Decodes a Fields message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Fields
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Fields;

        /**
         * Verifies a Fields message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Fields message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Fields
         */
        public static fromObject(object: { [k: string]: any }): dataform.Fields;

        /**
         * Creates a plain object from a Fields message. Also converts values to other types if specified.
         * @param message Fields
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Fields, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Fields to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Fields
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a TableMetadata. */
    interface ITableMetadata {

        /** TableMetadata target */
        target?: (dataform.ITarget|null);

        /** TableMetadata type */
        type?: (dataform.TableMetadata.Type|null);

        /** TableMetadata fields */
        fields?: (dataform.IField[]|null);

        /** TableMetadata description */
        description?: (string|null);

        /** TableMetadata labels */
        labels?: ({ [k: string]: string }|null);

        /** TableMetadata lastUpdatedMillis */
        lastUpdatedMillis?: (Long|null);

        /** TableMetadata bigquery */
        bigquery?: (dataform.TableMetadata.IBigQuery|null);
    }

    /** Represents a TableMetadata. */
    class TableMetadata implements ITableMetadata {

        /**
         * Constructs a new TableMetadata.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITableMetadata);

        /** TableMetadata target. */
        public target?: (dataform.ITarget|null);

        /** TableMetadata type. */
        public type: dataform.TableMetadata.Type;

        /** TableMetadata fields. */
        public fields: dataform.IField[];

        /** TableMetadata description. */
        public description: string;

        /** TableMetadata labels. */
        public labels: { [k: string]: string };

        /** TableMetadata lastUpdatedMillis. */
        public lastUpdatedMillis: Long;

        /** TableMetadata bigquery. */
        public bigquery?: (dataform.TableMetadata.IBigQuery|null);

        /**
         * Creates a new TableMetadata instance using the specified properties.
         * @param [properties] Properties to set
         * @returns TableMetadata instance
         */
        public static create(properties?: dataform.ITableMetadata): dataform.TableMetadata;

        /**
         * Encodes the specified TableMetadata message. Does not implicitly {@link dataform.TableMetadata.verify|verify} messages.
         * @param message TableMetadata message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITableMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified TableMetadata message, length delimited. Does not implicitly {@link dataform.TableMetadata.verify|verify} messages.
         * @param message TableMetadata message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITableMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a TableMetadata message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns TableMetadata
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.TableMetadata;

        /**
         * Decodes a TableMetadata message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns TableMetadata
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.TableMetadata;

        /**
         * Verifies a TableMetadata message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a TableMetadata message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns TableMetadata
         */
        public static fromObject(object: { [k: string]: any }): dataform.TableMetadata;

        /**
         * Creates a plain object from a TableMetadata message. Also converts values to other types if specified.
         * @param message TableMetadata
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.TableMetadata, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this TableMetadata to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for TableMetadata
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace TableMetadata {

        /** Type enum. */
        enum Type {
            UNKNOWN = 0,
            TABLE = 1,
            VIEW = 2
        }

        /** Properties of a BigQuery. */
        interface IBigQuery {

            /** BigQuery hasStreamingBuffer */
            hasStreamingBuffer?: (boolean|null);
        }

        /** Represents a BigQuery. */
        class BigQuery implements IBigQuery {

            /**
             * Constructs a new BigQuery.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.TableMetadata.IBigQuery);

            /** BigQuery hasStreamingBuffer. */
            public hasStreamingBuffer: boolean;

            /**
             * Creates a new BigQuery instance using the specified properties.
             * @param [properties] Properties to set
             * @returns BigQuery instance
             */
            public static create(properties?: dataform.TableMetadata.IBigQuery): dataform.TableMetadata.BigQuery;

            /**
             * Encodes the specified BigQuery message. Does not implicitly {@link dataform.TableMetadata.BigQuery.verify|verify} messages.
             * @param message BigQuery message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.TableMetadata.IBigQuery, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified BigQuery message, length delimited. Does not implicitly {@link dataform.TableMetadata.BigQuery.verify|verify} messages.
             * @param message BigQuery message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.TableMetadata.IBigQuery, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a BigQuery message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns BigQuery
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.TableMetadata.BigQuery;

            /**
             * Decodes a BigQuery message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns BigQuery
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.TableMetadata.BigQuery;

            /**
             * Verifies a BigQuery message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a BigQuery message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns BigQuery
             */
            public static fromObject(object: { [k: string]: any }): dataform.TableMetadata.BigQuery;

            /**
             * Creates a plain object from a BigQuery message. Also converts values to other types if specified.
             * @param message BigQuery
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.TableMetadata.BigQuery, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this BigQuery to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for BigQuery
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    /** Properties of an ExecutionMetadata. */
    interface IExecutionMetadata {

        /** ExecutionMetadata bigquery */
        bigquery?: (dataform.ExecutionMetadata.IBigqueryMetadata|null);
    }

    /** Represents an ExecutionMetadata. */
    class ExecutionMetadata implements IExecutionMetadata {

        /**
         * Constructs a new ExecutionMetadata.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExecutionMetadata);

        /** ExecutionMetadata bigquery. */
        public bigquery?: (dataform.ExecutionMetadata.IBigqueryMetadata|null);

        /**
         * Creates a new ExecutionMetadata instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ExecutionMetadata instance
         */
        public static create(properties?: dataform.IExecutionMetadata): dataform.ExecutionMetadata;

        /**
         * Encodes the specified ExecutionMetadata message. Does not implicitly {@link dataform.ExecutionMetadata.verify|verify} messages.
         * @param message ExecutionMetadata message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExecutionMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ExecutionMetadata message, length delimited. Does not implicitly {@link dataform.ExecutionMetadata.verify|verify} messages.
         * @param message ExecutionMetadata message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExecutionMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ExecutionMetadata message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ExecutionMetadata
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecutionMetadata;

        /**
         * Decodes an ExecutionMetadata message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ExecutionMetadata
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecutionMetadata;

        /**
         * Verifies an ExecutionMetadata message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ExecutionMetadata message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ExecutionMetadata
         */
        public static fromObject(object: { [k: string]: any }): dataform.ExecutionMetadata;

        /**
         * Creates a plain object from an ExecutionMetadata message. Also converts values to other types if specified.
         * @param message ExecutionMetadata
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ExecutionMetadata, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ExecutionMetadata to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ExecutionMetadata
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace ExecutionMetadata {

        /** Properties of a BigqueryMetadata. */
        interface IBigqueryMetadata {

            /** BigqueryMetadata jobId */
            jobId?: (string|null);

            /** BigqueryMetadata totalBytesProcessed */
            totalBytesProcessed?: (Long|null);

            /** BigqueryMetadata totalBytesBilled */
            totalBytesBilled?: (Long|null);
        }

        /** Represents a BigqueryMetadata. */
        class BigqueryMetadata implements IBigqueryMetadata {

            /**
             * Constructs a new BigqueryMetadata.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.ExecutionMetadata.IBigqueryMetadata);

            /** BigqueryMetadata jobId. */
            public jobId: string;

            /** BigqueryMetadata totalBytesProcessed. */
            public totalBytesProcessed: Long;

            /** BigqueryMetadata totalBytesBilled. */
            public totalBytesBilled: Long;

            /**
             * Creates a new BigqueryMetadata instance using the specified properties.
             * @param [properties] Properties to set
             * @returns BigqueryMetadata instance
             */
            public static create(properties?: dataform.ExecutionMetadata.IBigqueryMetadata): dataform.ExecutionMetadata.BigqueryMetadata;

            /**
             * Encodes the specified BigqueryMetadata message. Does not implicitly {@link dataform.ExecutionMetadata.BigqueryMetadata.verify|verify} messages.
             * @param message BigqueryMetadata message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.ExecutionMetadata.IBigqueryMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified BigqueryMetadata message, length delimited. Does not implicitly {@link dataform.ExecutionMetadata.BigqueryMetadata.verify|verify} messages.
             * @param message BigqueryMetadata message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.ExecutionMetadata.IBigqueryMetadata, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a BigqueryMetadata message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns BigqueryMetadata
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecutionMetadata.BigqueryMetadata;

            /**
             * Decodes a BigqueryMetadata message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns BigqueryMetadata
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecutionMetadata.BigqueryMetadata;

            /**
             * Verifies a BigqueryMetadata message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a BigqueryMetadata message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns BigqueryMetadata
             */
            public static fromObject(object: { [k: string]: any }): dataform.ExecutionMetadata.BigqueryMetadata;

            /**
             * Creates a plain object from a BigqueryMetadata message. Also converts values to other types if specified.
             * @param message BigqueryMetadata
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.ExecutionMetadata.BigqueryMetadata, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this BigqueryMetadata to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for BigqueryMetadata
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    /** Properties of a QueryEvaluationError. */
    interface IQueryEvaluationError {

        /** QueryEvaluationError message */
        message?: (string|null);

        /** QueryEvaluationError errorLocation */
        errorLocation?: (dataform.QueryEvaluationError.IErrorLocation|null);
    }

    /** Represents a QueryEvaluationError. */
    class QueryEvaluationError implements IQueryEvaluationError {

        /**
         * Constructs a new QueryEvaluationError.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IQueryEvaluationError);

        /** QueryEvaluationError message. */
        public message: string;

        /** QueryEvaluationError errorLocation. */
        public errorLocation?: (dataform.QueryEvaluationError.IErrorLocation|null);

        /**
         * Creates a new QueryEvaluationError instance using the specified properties.
         * @param [properties] Properties to set
         * @returns QueryEvaluationError instance
         */
        public static create(properties?: dataform.IQueryEvaluationError): dataform.QueryEvaluationError;

        /**
         * Encodes the specified QueryEvaluationError message. Does not implicitly {@link dataform.QueryEvaluationError.verify|verify} messages.
         * @param message QueryEvaluationError message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IQueryEvaluationError, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified QueryEvaluationError message, length delimited. Does not implicitly {@link dataform.QueryEvaluationError.verify|verify} messages.
         * @param message QueryEvaluationError message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IQueryEvaluationError, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a QueryEvaluationError message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns QueryEvaluationError
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.QueryEvaluationError;

        /**
         * Decodes a QueryEvaluationError message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns QueryEvaluationError
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.QueryEvaluationError;

        /**
         * Verifies a QueryEvaluationError message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a QueryEvaluationError message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns QueryEvaluationError
         */
        public static fromObject(object: { [k: string]: any }): dataform.QueryEvaluationError;

        /**
         * Creates a plain object from a QueryEvaluationError message. Also converts values to other types if specified.
         * @param message QueryEvaluationError
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.QueryEvaluationError, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this QueryEvaluationError to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for QueryEvaluationError
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace QueryEvaluationError {

        /** Properties of an ErrorLocation. */
        interface IErrorLocation {

            /** ErrorLocation line */
            line?: (number|null);

            /** ErrorLocation column */
            column?: (number|null);
        }

        /** Represents an ErrorLocation. */
        class ErrorLocation implements IErrorLocation {

            /**
             * Constructs a new ErrorLocation.
             * @param [properties] Properties to set
             */
            constructor(properties?: dataform.QueryEvaluationError.IErrorLocation);

            /** ErrorLocation line. */
            public line: number;

            /** ErrorLocation column. */
            public column: number;

            /**
             * Creates a new ErrorLocation instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ErrorLocation instance
             */
            public static create(properties?: dataform.QueryEvaluationError.IErrorLocation): dataform.QueryEvaluationError.ErrorLocation;

            /**
             * Encodes the specified ErrorLocation message. Does not implicitly {@link dataform.QueryEvaluationError.ErrorLocation.verify|verify} messages.
             * @param message ErrorLocation message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: dataform.QueryEvaluationError.IErrorLocation, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified ErrorLocation message, length delimited. Does not implicitly {@link dataform.QueryEvaluationError.ErrorLocation.verify|verify} messages.
             * @param message ErrorLocation message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: dataform.QueryEvaluationError.IErrorLocation, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes an ErrorLocation message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ErrorLocation
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.QueryEvaluationError.ErrorLocation;

            /**
             * Decodes an ErrorLocation message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ErrorLocation
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.QueryEvaluationError.ErrorLocation;

            /**
             * Verifies an ErrorLocation message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an ErrorLocation message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ErrorLocation
             */
            public static fromObject(object: { [k: string]: any }): dataform.QueryEvaluationError.ErrorLocation;

            /**
             * Creates a plain object from an ErrorLocation message. Also converts values to other types if specified.
             * @param message ErrorLocation
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: dataform.QueryEvaluationError.ErrorLocation, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ErrorLocation to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for ErrorLocation
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }

    /** Properties of a QueryEvaluation. */
    interface IQueryEvaluation {

        /** QueryEvaluation status */
        status?: (dataform.QueryEvaluation.QueryEvaluationStatus|null);

        /** QueryEvaluation error */
        error?: (dataform.IQueryEvaluationError|null);

        /** QueryEvaluation incremental */
        incremental?: (boolean|null);

        /** QueryEvaluation query */
        query?: (string|null);
    }

    /** Represents a QueryEvaluation. */
    class QueryEvaluation implements IQueryEvaluation {

        /**
         * Constructs a new QueryEvaluation.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IQueryEvaluation);

        /** QueryEvaluation status. */
        public status: dataform.QueryEvaluation.QueryEvaluationStatus;

        /** QueryEvaluation error. */
        public error?: (dataform.IQueryEvaluationError|null);

        /** QueryEvaluation incremental. */
        public incremental: boolean;

        /** QueryEvaluation query. */
        public query: string;

        /**
         * Creates a new QueryEvaluation instance using the specified properties.
         * @param [properties] Properties to set
         * @returns QueryEvaluation instance
         */
        public static create(properties?: dataform.IQueryEvaluation): dataform.QueryEvaluation;

        /**
         * Encodes the specified QueryEvaluation message. Does not implicitly {@link dataform.QueryEvaluation.verify|verify} messages.
         * @param message QueryEvaluation message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IQueryEvaluation, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified QueryEvaluation message, length delimited. Does not implicitly {@link dataform.QueryEvaluation.verify|verify} messages.
         * @param message QueryEvaluation message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IQueryEvaluation, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a QueryEvaluation message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns QueryEvaluation
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.QueryEvaluation;

        /**
         * Decodes a QueryEvaluation message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns QueryEvaluation
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.QueryEvaluation;

        /**
         * Verifies a QueryEvaluation message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a QueryEvaluation message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns QueryEvaluation
         */
        public static fromObject(object: { [k: string]: any }): dataform.QueryEvaluation;

        /**
         * Creates a plain object from a QueryEvaluation message. Also converts values to other types if specified.
         * @param message QueryEvaluation
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.QueryEvaluation, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this QueryEvaluation to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for QueryEvaluation
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace QueryEvaluation {

        /** QueryEvaluationStatus enum. */
        enum QueryEvaluationStatus {
            SUCCESS = 0,
            FAILURE = 1
        }
    }

    /** Properties of a RunConfig. */
    interface IRunConfig {

        /** RunConfig actions */
        actions?: (string[]|null);

        /** RunConfig tags */
        tags?: (string[]|null);

        /** RunConfig includeDependencies */
        includeDependencies?: (boolean|null);

        /** RunConfig includeDependents */
        includeDependents?: (boolean|null);

        /** RunConfig fullRefresh */
        fullRefresh?: (boolean|null);

        /** RunConfig timeoutMillis */
        timeoutMillis?: (number|null);

        /** RunConfig disableSetMetadata */
        disableSetMetadata?: (boolean|null);

        /** RunConfig useRunCache */
        useRunCache?: (boolean|null);
    }

    /** Represents a RunConfig. */
    class RunConfig implements IRunConfig {

        /**
         * Constructs a new RunConfig.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IRunConfig);

        /** RunConfig actions. */
        public actions: string[];

        /** RunConfig tags. */
        public tags: string[];

        /** RunConfig includeDependencies. */
        public includeDependencies: boolean;

        /** RunConfig includeDependents. */
        public includeDependents: boolean;

        /** RunConfig fullRefresh. */
        public fullRefresh: boolean;

        /** RunConfig timeoutMillis. */
        public timeoutMillis: number;

        /** RunConfig disableSetMetadata. */
        public disableSetMetadata: boolean;

        /** RunConfig useRunCache. */
        public useRunCache: boolean;

        /**
         * Creates a new RunConfig instance using the specified properties.
         * @param [properties] Properties to set
         * @returns RunConfig instance
         */
        public static create(properties?: dataform.IRunConfig): dataform.RunConfig;

        /**
         * Encodes the specified RunConfig message. Does not implicitly {@link dataform.RunConfig.verify|verify} messages.
         * @param message RunConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IRunConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified RunConfig message, length delimited. Does not implicitly {@link dataform.RunConfig.verify|verify} messages.
         * @param message RunConfig message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IRunConfig, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a RunConfig message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns RunConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.RunConfig;

        /**
         * Decodes a RunConfig message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns RunConfig
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.RunConfig;

        /**
         * Verifies a RunConfig message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a RunConfig message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns RunConfig
         */
        public static fromObject(object: { [k: string]: any }): dataform.RunConfig;

        /**
         * Creates a plain object from a RunConfig message. Also converts values to other types if specified.
         * @param message RunConfig
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.RunConfig, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this RunConfig to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for RunConfig
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an ExecutionTask. */
    interface IExecutionTask {

        /** ExecutionTask type */
        type?: (string|null);

        /** ExecutionTask statement */
        statement?: (string|null);
    }

    /** Represents an ExecutionTask. */
    class ExecutionTask implements IExecutionTask {

        /**
         * Constructs a new ExecutionTask.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExecutionTask);

        /** ExecutionTask type. */
        public type: string;

        /** ExecutionTask statement. */
        public statement: string;

        /**
         * Creates a new ExecutionTask instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ExecutionTask instance
         */
        public static create(properties?: dataform.IExecutionTask): dataform.ExecutionTask;

        /**
         * Encodes the specified ExecutionTask message. Does not implicitly {@link dataform.ExecutionTask.verify|verify} messages.
         * @param message ExecutionTask message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExecutionTask, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ExecutionTask message, length delimited. Does not implicitly {@link dataform.ExecutionTask.verify|verify} messages.
         * @param message ExecutionTask message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExecutionTask, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ExecutionTask message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ExecutionTask
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecutionTask;

        /**
         * Decodes an ExecutionTask message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ExecutionTask
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecutionTask;

        /**
         * Verifies an ExecutionTask message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ExecutionTask message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ExecutionTask
         */
        public static fromObject(object: { [k: string]: any }): dataform.ExecutionTask;

        /**
         * Creates a plain object from an ExecutionTask message. Also converts values to other types if specified.
         * @param message ExecutionTask
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ExecutionTask, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ExecutionTask to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ExecutionTask
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an ExecutionAction. */
    interface IExecutionAction {

        /** ExecutionAction target */
        target?: (dataform.ITarget|null);

        /** ExecutionAction fileName */
        fileName?: (string|null);

        /** ExecutionAction type */
        type?: (string|null);

        /** ExecutionAction tableType */
        tableType?: (string|null);

        /** ExecutionAction dependencyTargets */
        dependencyTargets?: (dataform.ITarget[]|null);

        /** ExecutionAction hermeticity */
        hermeticity?: (dataform.ActionHermeticity|null);

        /** ExecutionAction tasks */
        tasks?: (dataform.IExecutionTask[]|null);

        /** ExecutionAction actionDescriptor */
        actionDescriptor?: (dataform.IActionDescriptor|null);

        /** ExecutionAction jitCode */
        jitCode?: (string|null);
    }

    /** Represents an ExecutionAction. */
    class ExecutionAction implements IExecutionAction {

        /**
         * Constructs a new ExecutionAction.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExecutionAction);

        /** ExecutionAction target. */
        public target?: (dataform.ITarget|null);

        /** ExecutionAction fileName. */
        public fileName: string;

        /** ExecutionAction type. */
        public type: string;

        /** ExecutionAction tableType. */
        public tableType: string;

        /** ExecutionAction dependencyTargets. */
        public dependencyTargets: dataform.ITarget[];

        /** ExecutionAction hermeticity. */
        public hermeticity: dataform.ActionHermeticity;

        /** ExecutionAction tasks. */
        public tasks: dataform.IExecutionTask[];

        /** ExecutionAction actionDescriptor. */
        public actionDescriptor?: (dataform.IActionDescriptor|null);

        /** ExecutionAction jitCode. */
        public jitCode: string;

        /**
         * Creates a new ExecutionAction instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ExecutionAction instance
         */
        public static create(properties?: dataform.IExecutionAction): dataform.ExecutionAction;

        /**
         * Encodes the specified ExecutionAction message. Does not implicitly {@link dataform.ExecutionAction.verify|verify} messages.
         * @param message ExecutionAction message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExecutionAction, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ExecutionAction message, length delimited. Does not implicitly {@link dataform.ExecutionAction.verify|verify} messages.
         * @param message ExecutionAction message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExecutionAction, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ExecutionAction message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ExecutionAction
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecutionAction;

        /**
         * Decodes an ExecutionAction message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ExecutionAction
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecutionAction;

        /**
         * Verifies an ExecutionAction message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ExecutionAction message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ExecutionAction
         */
        public static fromObject(object: { [k: string]: any }): dataform.ExecutionAction;

        /**
         * Creates a plain object from an ExecutionAction message. Also converts values to other types if specified.
         * @param message ExecutionAction
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ExecutionAction, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ExecutionAction to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ExecutionAction
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a WarehouseState. */
    interface IWarehouseState {

        /** WarehouseState tables */
        tables?: (dataform.ITableMetadata[]|null);
    }

    /** Represents a WarehouseState. */
    class WarehouseState implements IWarehouseState {

        /**
         * Constructs a new WarehouseState.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IWarehouseState);

        /** WarehouseState tables. */
        public tables: dataform.ITableMetadata[];

        /**
         * Creates a new WarehouseState instance using the specified properties.
         * @param [properties] Properties to set
         * @returns WarehouseState instance
         */
        public static create(properties?: dataform.IWarehouseState): dataform.WarehouseState;

        /**
         * Encodes the specified WarehouseState message. Does not implicitly {@link dataform.WarehouseState.verify|verify} messages.
         * @param message WarehouseState message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IWarehouseState, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified WarehouseState message, length delimited. Does not implicitly {@link dataform.WarehouseState.verify|verify} messages.
         * @param message WarehouseState message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IWarehouseState, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a WarehouseState message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns WarehouseState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.WarehouseState;

        /**
         * Decodes a WarehouseState message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns WarehouseState
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.WarehouseState;

        /**
         * Verifies a WarehouseState message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a WarehouseState message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns WarehouseState
         */
        public static fromObject(object: { [k: string]: any }): dataform.WarehouseState;

        /**
         * Creates a plain object from a WarehouseState message. Also converts values to other types if specified.
         * @param message WarehouseState
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.WarehouseState, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this WarehouseState to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for WarehouseState
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an ExecutionGraph. */
    interface IExecutionGraph {

        /** ExecutionGraph projectConfig */
        projectConfig?: (dataform.IProjectConfig|null);

        /** ExecutionGraph runConfig */
        runConfig?: (dataform.IRunConfig|null);

        /** ExecutionGraph warehouseState */
        warehouseState?: (dataform.IWarehouseState|null);

        /** ExecutionGraph declarationTargets */
        declarationTargets?: (dataform.ITarget[]|null);

        /** ExecutionGraph actions */
        actions?: (dataform.IExecutionAction[]|null);

        /** ExecutionGraph jitData */
        jitData?: (google.protobuf.IStruct|null);
    }

    /** Represents an ExecutionGraph. */
    class ExecutionGraph implements IExecutionGraph {

        /**
         * Constructs a new ExecutionGraph.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExecutionGraph);

        /** ExecutionGraph projectConfig. */
        public projectConfig?: (dataform.IProjectConfig|null);

        /** ExecutionGraph runConfig. */
        public runConfig?: (dataform.IRunConfig|null);

        /** ExecutionGraph warehouseState. */
        public warehouseState?: (dataform.IWarehouseState|null);

        /** ExecutionGraph declarationTargets. */
        public declarationTargets: dataform.ITarget[];

        /** ExecutionGraph actions. */
        public actions: dataform.IExecutionAction[];

        /** ExecutionGraph jitData. */
        public jitData?: (google.protobuf.IStruct|null);

        /**
         * Creates a new ExecutionGraph instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ExecutionGraph instance
         */
        public static create(properties?: dataform.IExecutionGraph): dataform.ExecutionGraph;

        /**
         * Encodes the specified ExecutionGraph message. Does not implicitly {@link dataform.ExecutionGraph.verify|verify} messages.
         * @param message ExecutionGraph message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExecutionGraph, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ExecutionGraph message, length delimited. Does not implicitly {@link dataform.ExecutionGraph.verify|verify} messages.
         * @param message ExecutionGraph message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExecutionGraph, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ExecutionGraph message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ExecutionGraph
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecutionGraph;

        /**
         * Decodes an ExecutionGraph message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ExecutionGraph
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecutionGraph;

        /**
         * Verifies an ExecutionGraph message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ExecutionGraph message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ExecutionGraph
         */
        public static fromObject(object: { [k: string]: any }): dataform.ExecutionGraph;

        /**
         * Creates a plain object from an ExecutionGraph message. Also converts values to other types if specified.
         * @param message ExecutionGraph
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ExecutionGraph, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ExecutionGraph to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ExecutionGraph
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a Timing. */
    interface ITiming {

        /** Timing startTimeMillis */
        startTimeMillis?: (Long|null);

        /** Timing endTimeMillis */
        endTimeMillis?: (Long|null);
    }

    /** Represents a Timing. */
    class Timing implements ITiming {

        /**
         * Constructs a new Timing.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITiming);

        /** Timing startTimeMillis. */
        public startTimeMillis: Long;

        /** Timing endTimeMillis. */
        public endTimeMillis: Long;

        /**
         * Creates a new Timing instance using the specified properties.
         * @param [properties] Properties to set
         * @returns Timing instance
         */
        public static create(properties?: dataform.ITiming): dataform.Timing;

        /**
         * Encodes the specified Timing message. Does not implicitly {@link dataform.Timing.verify|verify} messages.
         * @param message Timing message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITiming, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified Timing message, length delimited. Does not implicitly {@link dataform.Timing.verify|verify} messages.
         * @param message Timing message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITiming, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a Timing message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns Timing
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.Timing;

        /**
         * Decodes a Timing message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns Timing
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.Timing;

        /**
         * Verifies a Timing message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a Timing message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns Timing
         */
        public static fromObject(object: { [k: string]: any }): dataform.Timing;

        /**
         * Creates a plain object from a Timing message. Also converts values to other types if specified.
         * @param message Timing
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.Timing, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this Timing to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for Timing
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a RunResult. */
    interface IRunResult {

        /** RunResult status */
        status?: (dataform.RunResult.ExecutionStatus|null);

        /** RunResult actions */
        actions?: (dataform.IActionResult[]|null);

        /** RunResult timing */
        timing?: (dataform.ITiming|null);
    }

    /** Represents a RunResult. */
    class RunResult implements IRunResult {

        /**
         * Constructs a new RunResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IRunResult);

        /** RunResult status. */
        public status: dataform.RunResult.ExecutionStatus;

        /** RunResult actions. */
        public actions: dataform.IActionResult[];

        /** RunResult timing. */
        public timing?: (dataform.ITiming|null);

        /**
         * Creates a new RunResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns RunResult instance
         */
        public static create(properties?: dataform.IRunResult): dataform.RunResult;

        /**
         * Encodes the specified RunResult message. Does not implicitly {@link dataform.RunResult.verify|verify} messages.
         * @param message RunResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IRunResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified RunResult message, length delimited. Does not implicitly {@link dataform.RunResult.verify|verify} messages.
         * @param message RunResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IRunResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a RunResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns RunResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.RunResult;

        /**
         * Decodes a RunResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns RunResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.RunResult;

        /**
         * Verifies a RunResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a RunResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns RunResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.RunResult;

        /**
         * Creates a plain object from a RunResult message. Also converts values to other types if specified.
         * @param message RunResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.RunResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this RunResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for RunResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace RunResult {

        /** ExecutionStatus enum. */
        enum ExecutionStatus {
            UNKNOWN = 0,
            RUNNING = 1,
            SUCCESSFUL = 2,
            FAILED = 3,
            CANCELLED = 4,
            TIMED_OUT = 5
        }
    }

    /** Properties of an ActionResult. */
    interface IActionResult {

        /** ActionResult target */
        target?: (dataform.ITarget|null);

        /** ActionResult status */
        status?: (dataform.ActionResult.ExecutionStatus|null);

        /** ActionResult tasks */
        tasks?: (dataform.ITaskResult[]|null);

        /** ActionResult timing */
        timing?: (dataform.ITiming|null);
    }

    /** Represents an ActionResult. */
    class ActionResult implements IActionResult {

        /**
         * Constructs a new ActionResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IActionResult);

        /** ActionResult target. */
        public target?: (dataform.ITarget|null);

        /** ActionResult status. */
        public status: dataform.ActionResult.ExecutionStatus;

        /** ActionResult tasks. */
        public tasks: dataform.ITaskResult[];

        /** ActionResult timing. */
        public timing?: (dataform.ITiming|null);

        /**
         * Creates a new ActionResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ActionResult instance
         */
        public static create(properties?: dataform.IActionResult): dataform.ActionResult;

        /**
         * Encodes the specified ActionResult message. Does not implicitly {@link dataform.ActionResult.verify|verify} messages.
         * @param message ActionResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IActionResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ActionResult message, length delimited. Does not implicitly {@link dataform.ActionResult.verify|verify} messages.
         * @param message ActionResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IActionResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ActionResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ActionResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ActionResult;

        /**
         * Decodes an ActionResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ActionResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ActionResult;

        /**
         * Verifies an ActionResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ActionResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ActionResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.ActionResult;

        /**
         * Creates a plain object from an ActionResult message. Also converts values to other types if specified.
         * @param message ActionResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ActionResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ActionResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ActionResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace ActionResult {

        /** ExecutionStatus enum. */
        enum ExecutionStatus {
            UNKNOWN = 0,
            RUNNING = 1,
            SUCCESSFUL = 2,
            FAILED = 3,
            SKIPPED = 4,
            DISABLED = 5,
            CANCELLED = 6
        }
    }

    /** Properties of a TaskResult. */
    interface ITaskResult {

        /** TaskResult status */
        status?: (dataform.TaskResult.ExecutionStatus|null);

        /** TaskResult errorMessage */
        errorMessage?: (string|null);

        /** TaskResult timing */
        timing?: (dataform.ITiming|null);

        /** TaskResult metadata */
        metadata?: (dataform.IExecutionMetadata|null);
    }

    /** Represents a TaskResult. */
    class TaskResult implements ITaskResult {

        /**
         * Constructs a new TaskResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITaskResult);

        /** TaskResult status. */
        public status: dataform.TaskResult.ExecutionStatus;

        /** TaskResult errorMessage. */
        public errorMessage: string;

        /** TaskResult timing. */
        public timing?: (dataform.ITiming|null);

        /** TaskResult metadata. */
        public metadata?: (dataform.IExecutionMetadata|null);

        /**
         * Creates a new TaskResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns TaskResult instance
         */
        public static create(properties?: dataform.ITaskResult): dataform.TaskResult;

        /**
         * Encodes the specified TaskResult message. Does not implicitly {@link dataform.TaskResult.verify|verify} messages.
         * @param message TaskResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITaskResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified TaskResult message, length delimited. Does not implicitly {@link dataform.TaskResult.verify|verify} messages.
         * @param message TaskResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITaskResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a TaskResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns TaskResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.TaskResult;

        /**
         * Decodes a TaskResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns TaskResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.TaskResult;

        /**
         * Verifies a TaskResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a TaskResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns TaskResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.TaskResult;

        /**
         * Creates a plain object from a TaskResult message. Also converts values to other types if specified.
         * @param message TaskResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.TaskResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this TaskResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for TaskResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    namespace TaskResult {

        /** ExecutionStatus enum. */
        enum ExecutionStatus {
            UNKNOWN = 0,
            RUNNING = 1,
            SUCCESSFUL = 2,
            FAILED = 3,
            SKIPPED = 4,
            CANCELLED = 5
        }
    }

    /** Properties of a TestResult. */
    interface ITestResult {

        /** TestResult name */
        name?: (string|null);

        /** TestResult successful */
        successful?: (boolean|null);

        /** TestResult messages */
        messages?: (string[]|null);
    }

    /** Represents a TestResult. */
    class TestResult implements ITestResult {

        /**
         * Constructs a new TestResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.ITestResult);

        /** TestResult name. */
        public name: string;

        /** TestResult successful. */
        public successful: boolean;

        /** TestResult messages. */
        public messages: string[];

        /**
         * Creates a new TestResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns TestResult instance
         */
        public static create(properties?: dataform.ITestResult): dataform.TestResult;

        /**
         * Encodes the specified TestResult message. Does not implicitly {@link dataform.TestResult.verify|verify} messages.
         * @param message TestResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.ITestResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified TestResult message, length delimited. Does not implicitly {@link dataform.TestResult.verify|verify} messages.
         * @param message TestResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.ITestResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a TestResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns TestResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.TestResult;

        /**
         * Decodes a TestResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns TestResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.TestResult;

        /**
         * Verifies a TestResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a TestResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns TestResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.TestResult;

        /**
         * Creates a plain object from a TestResult message. Also converts values to other types if specified.
         * @param message TestResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.TestResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this TestResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for TestResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Represents a DbAdapter */
    class DbAdapter extends $protobuf.rpc.Service {

        /**
         * Constructs a new DbAdapter service.
         * @param rpcImpl RPC implementation
         * @param [requestDelimited=false] Whether requests are length-delimited
         * @param [responseDelimited=false] Whether responses are length-delimited
         */
        constructor(rpcImpl: $protobuf.RPCImpl, requestDelimited?: boolean, responseDelimited?: boolean);

        /**
         * Creates new DbAdapter service using the specified rpc implementation.
         * @param rpcImpl RPC implementation
         * @param [requestDelimited=false] Whether requests are length-delimited
         * @param [responseDelimited=false] Whether responses are length-delimited
         * @returns RPC service. Useful where requests and/or responses are streamed.
         */
        public static create(rpcImpl: $protobuf.RPCImpl, requestDelimited?: boolean, responseDelimited?: boolean): DbAdapter;

        /**
         * Calls Execute.
         * @param request ExecuteRequest message or plain object
         * @param callback Node-style callback called with the error, if any, and ExecuteResponse
         */
        public execute(request: dataform.IExecuteRequest, callback: dataform.DbAdapter.ExecuteCallback): void;

        /**
         * Calls Execute.
         * @param request ExecuteRequest message or plain object
         * @returns Promise
         */
        public execute(request: dataform.IExecuteRequest): Promise<dataform.ExecuteResponse>;

        /**
         * Calls ListTables.
         * @param request ListTablesRequest message or plain object
         * @param callback Node-style callback called with the error, if any, and ListTablesResponse
         */
        public listTables(request: dataform.IListTablesRequest, callback: dataform.DbAdapter.ListTablesCallback): void;

        /**
         * Calls ListTables.
         * @param request ListTablesRequest message or plain object
         * @returns Promise
         */
        public listTables(request: dataform.IListTablesRequest): Promise<dataform.ListTablesResponse>;

        /**
         * Calls GetTable.
         * @param request GetTableRequest message or plain object
         * @param callback Node-style callback called with the error, if any, and TableMetadata
         */
        public getTable(request: dataform.IGetTableRequest, callback: dataform.DbAdapter.GetTableCallback): void;

        /**
         * Calls GetTable.
         * @param request GetTableRequest message or plain object
         * @returns Promise
         */
        public getTable(request: dataform.IGetTableRequest): Promise<dataform.TableMetadata>;

        /**
         * Calls DeleteTable.
         * @param request DeleteTableRequest message or plain object
         * @param callback Node-style callback called with the error, if any, and Empty
         */
        public deleteTable(request: dataform.IDeleteTableRequest, callback: dataform.DbAdapter.DeleteTableCallback): void;

        /**
         * Calls DeleteTable.
         * @param request DeleteTableRequest message or plain object
         * @returns Promise
         */
        public deleteTable(request: dataform.IDeleteTableRequest): Promise<google.protobuf.Empty>;
    }

    namespace DbAdapter {

        /**
         * Callback as used by {@link dataform.DbAdapter#execute}.
         * @param error Error, if any
         * @param [response] ExecuteResponse
         */
        type ExecuteCallback = (error: (Error|null), response?: dataform.ExecuteResponse) => void;

        /**
         * Callback as used by {@link dataform.DbAdapter#listTables}.
         * @param error Error, if any
         * @param [response] ListTablesResponse
         */
        type ListTablesCallback = (error: (Error|null), response?: dataform.ListTablesResponse) => void;

        /**
         * Callback as used by {@link dataform.DbAdapter#getTable}.
         * @param error Error, if any
         * @param [response] TableMetadata
         */
        type GetTableCallback = (error: (Error|null), response?: dataform.TableMetadata) => void;

        /**
         * Callback as used by {@link dataform.DbAdapter#deleteTable}.
         * @param error Error, if any
         * @param [response] Empty
         */
        type DeleteTableCallback = (error: (Error|null), response?: google.protobuf.Empty) => void;
    }

    /** Properties of an ExecuteRequest. */
    interface IExecuteRequest {

        /** ExecuteRequest statement */
        statement?: (string|null);

        /** ExecuteRequest rowLimit */
        rowLimit?: (Long|null);

        /** ExecuteRequest byteLimit */
        byteLimit?: (Long|null);

        /** ExecuteRequest fetchResults */
        fetchResults?: (boolean|null);

        /** ExecuteRequest bigQueryOptions */
        bigQueryOptions?: (dataform.IBigQueryExecuteOptions|null);

        /** ExecuteRequest params */
        params?: (google.protobuf.IStruct|null);
    }

    /** Represents an ExecuteRequest. */
    class ExecuteRequest implements IExecuteRequest {

        /**
         * Constructs a new ExecuteRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExecuteRequest);

        /** ExecuteRequest statement. */
        public statement: string;

        /** ExecuteRequest rowLimit. */
        public rowLimit: Long;

        /** ExecuteRequest byteLimit. */
        public byteLimit: Long;

        /** ExecuteRequest fetchResults. */
        public fetchResults: boolean;

        /** ExecuteRequest bigQueryOptions. */
        public bigQueryOptions?: (dataform.IBigQueryExecuteOptions|null);

        /** ExecuteRequest params. */
        public params?: (google.protobuf.IStruct|null);

        /**
         * Creates a new ExecuteRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ExecuteRequest instance
         */
        public static create(properties?: dataform.IExecuteRequest): dataform.ExecuteRequest;

        /**
         * Encodes the specified ExecuteRequest message. Does not implicitly {@link dataform.ExecuteRequest.verify|verify} messages.
         * @param message ExecuteRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExecuteRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ExecuteRequest message, length delimited. Does not implicitly {@link dataform.ExecuteRequest.verify|verify} messages.
         * @param message ExecuteRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExecuteRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ExecuteRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ExecuteRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecuteRequest;

        /**
         * Decodes an ExecuteRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ExecuteRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecuteRequest;

        /**
         * Verifies an ExecuteRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ExecuteRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ExecuteRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.ExecuteRequest;

        /**
         * Creates a plain object from an ExecuteRequest message. Also converts values to other types if specified.
         * @param message ExecuteRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ExecuteRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ExecuteRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ExecuteRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a BigQueryExecuteOptions. */
    interface IBigQueryExecuteOptions {

        /** BigQueryExecuteOptions interactive */
        interactive?: (boolean|null);

        /** BigQueryExecuteOptions useLegacySql */
        useLegacySql?: (boolean|null);

        /** BigQueryExecuteOptions labels */
        labels?: ({ [k: string]: string }|null);

        /** BigQueryExecuteOptions location */
        location?: (string|null);

        /** BigQueryExecuteOptions jobPrefix */
        jobPrefix?: (string|null);

        /** BigQueryExecuteOptions dryRun */
        dryRun?: (boolean|null);

        /** BigQueryExecuteOptions reservation */
        reservation?: (string|null);
    }

    /** Represents a BigQueryExecuteOptions. */
    class BigQueryExecuteOptions implements IBigQueryExecuteOptions {

        /**
         * Constructs a new BigQueryExecuteOptions.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IBigQueryExecuteOptions);

        /** BigQueryExecuteOptions interactive. */
        public interactive: boolean;

        /** BigQueryExecuteOptions useLegacySql. */
        public useLegacySql: boolean;

        /** BigQueryExecuteOptions labels. */
        public labels: { [k: string]: string };

        /** BigQueryExecuteOptions location. */
        public location: string;

        /** BigQueryExecuteOptions jobPrefix. */
        public jobPrefix: string;

        /** BigQueryExecuteOptions dryRun. */
        public dryRun: boolean;

        /** BigQueryExecuteOptions reservation. */
        public reservation: string;

        /**
         * Creates a new BigQueryExecuteOptions instance using the specified properties.
         * @param [properties] Properties to set
         * @returns BigQueryExecuteOptions instance
         */
        public static create(properties?: dataform.IBigQueryExecuteOptions): dataform.BigQueryExecuteOptions;

        /**
         * Encodes the specified BigQueryExecuteOptions message. Does not implicitly {@link dataform.BigQueryExecuteOptions.verify|verify} messages.
         * @param message BigQueryExecuteOptions message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IBigQueryExecuteOptions, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified BigQueryExecuteOptions message, length delimited. Does not implicitly {@link dataform.BigQueryExecuteOptions.verify|verify} messages.
         * @param message BigQueryExecuteOptions message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IBigQueryExecuteOptions, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a BigQueryExecuteOptions message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns BigQueryExecuteOptions
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.BigQueryExecuteOptions;

        /**
         * Decodes a BigQueryExecuteOptions message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns BigQueryExecuteOptions
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.BigQueryExecuteOptions;

        /**
         * Verifies a BigQueryExecuteOptions message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a BigQueryExecuteOptions message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns BigQueryExecuteOptions
         */
        public static fromObject(object: { [k: string]: any }): dataform.BigQueryExecuteOptions;

        /**
         * Creates a plain object from a BigQueryExecuteOptions message. Also converts values to other types if specified.
         * @param message BigQueryExecuteOptions
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.BigQueryExecuteOptions, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this BigQueryExecuteOptions to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for BigQueryExecuteOptions
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of an ExecuteResponse. */
    interface IExecuteResponse {

        /** ExecuteResponse executionMetadata */
        executionMetadata?: (dataform.IExecutionMetadata|null);

        /** ExecuteResponse rows */
        rows?: (google.protobuf.IStruct[]|null);

        /** ExecuteResponse errors */
        errors?: (string[]|null);

        /** ExecuteResponse schemaFields */
        schemaFields?: (dataform.IField[]|null);
    }

    /** Represents an ExecuteResponse. */
    class ExecuteResponse implements IExecuteResponse {

        /**
         * Constructs a new ExecuteResponse.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IExecuteResponse);

        /** ExecuteResponse executionMetadata. */
        public executionMetadata?: (dataform.IExecutionMetadata|null);

        /** ExecuteResponse rows. */
        public rows: google.protobuf.IStruct[];

        /** ExecuteResponse errors. */
        public errors: string[];

        /** ExecuteResponse schemaFields. */
        public schemaFields: dataform.IField[];

        /**
         * Creates a new ExecuteResponse instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ExecuteResponse instance
         */
        public static create(properties?: dataform.IExecuteResponse): dataform.ExecuteResponse;

        /**
         * Encodes the specified ExecuteResponse message. Does not implicitly {@link dataform.ExecuteResponse.verify|verify} messages.
         * @param message ExecuteResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IExecuteResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ExecuteResponse message, length delimited. Does not implicitly {@link dataform.ExecuteResponse.verify|verify} messages.
         * @param message ExecuteResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IExecuteResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes an ExecuteResponse message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ExecuteResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ExecuteResponse;

        /**
         * Decodes an ExecuteResponse message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ExecuteResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ExecuteResponse;

        /**
         * Verifies an ExecuteResponse message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates an ExecuteResponse message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ExecuteResponse
         */
        public static fromObject(object: { [k: string]: any }): dataform.ExecuteResponse;

        /**
         * Creates a plain object from an ExecuteResponse message. Also converts values to other types if specified.
         * @param message ExecuteResponse
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ExecuteResponse, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ExecuteResponse to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ExecuteResponse
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a ListTablesRequest. */
    interface IListTablesRequest {

        /** ListTablesRequest database */
        database?: (string|null);

        /** ListTablesRequest schema */
        schema?: (string|null);
    }

    /** Represents a ListTablesRequest. */
    class ListTablesRequest implements IListTablesRequest {

        /**
         * Constructs a new ListTablesRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IListTablesRequest);

        /** ListTablesRequest database. */
        public database: string;

        /** ListTablesRequest schema. */
        public schema: string;

        /**
         * Creates a new ListTablesRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ListTablesRequest instance
         */
        public static create(properties?: dataform.IListTablesRequest): dataform.ListTablesRequest;

        /**
         * Encodes the specified ListTablesRequest message. Does not implicitly {@link dataform.ListTablesRequest.verify|verify} messages.
         * @param message ListTablesRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IListTablesRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ListTablesRequest message, length delimited. Does not implicitly {@link dataform.ListTablesRequest.verify|verify} messages.
         * @param message ListTablesRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IListTablesRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a ListTablesRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ListTablesRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ListTablesRequest;

        /**
         * Decodes a ListTablesRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ListTablesRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ListTablesRequest;

        /**
         * Verifies a ListTablesRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a ListTablesRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ListTablesRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.ListTablesRequest;

        /**
         * Creates a plain object from a ListTablesRequest message. Also converts values to other types if specified.
         * @param message ListTablesRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ListTablesRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ListTablesRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ListTablesRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a ListTablesResponse. */
    interface IListTablesResponse {

        /** ListTablesResponse tables */
        tables?: (dataform.ITableMetadata[]|null);
    }

    /** Represents a ListTablesResponse. */
    class ListTablesResponse implements IListTablesResponse {

        /**
         * Constructs a new ListTablesResponse.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IListTablesResponse);

        /** ListTablesResponse tables. */
        public tables: dataform.ITableMetadata[];

        /**
         * Creates a new ListTablesResponse instance using the specified properties.
         * @param [properties] Properties to set
         * @returns ListTablesResponse instance
         */
        public static create(properties?: dataform.IListTablesResponse): dataform.ListTablesResponse;

        /**
         * Encodes the specified ListTablesResponse message. Does not implicitly {@link dataform.ListTablesResponse.verify|verify} messages.
         * @param message ListTablesResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IListTablesResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified ListTablesResponse message, length delimited. Does not implicitly {@link dataform.ListTablesResponse.verify|verify} messages.
         * @param message ListTablesResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IListTablesResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a ListTablesResponse message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns ListTablesResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.ListTablesResponse;

        /**
         * Decodes a ListTablesResponse message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns ListTablesResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.ListTablesResponse;

        /**
         * Verifies a ListTablesResponse message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a ListTablesResponse message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns ListTablesResponse
         */
        public static fromObject(object: { [k: string]: any }): dataform.ListTablesResponse;

        /**
         * Creates a plain object from a ListTablesResponse message. Also converts values to other types if specified.
         * @param message ListTablesResponse
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.ListTablesResponse, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this ListTablesResponse to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for ListTablesResponse
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a GetTableRequest. */
    interface IGetTableRequest {

        /** GetTableRequest target */
        target?: (dataform.ITarget|null);
    }

    /** Represents a GetTableRequest. */
    class GetTableRequest implements IGetTableRequest {

        /**
         * Constructs a new GetTableRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IGetTableRequest);

        /** GetTableRequest target. */
        public target?: (dataform.ITarget|null);

        /**
         * Creates a new GetTableRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns GetTableRequest instance
         */
        public static create(properties?: dataform.IGetTableRequest): dataform.GetTableRequest;

        /**
         * Encodes the specified GetTableRequest message. Does not implicitly {@link dataform.GetTableRequest.verify|verify} messages.
         * @param message GetTableRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IGetTableRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified GetTableRequest message, length delimited. Does not implicitly {@link dataform.GetTableRequest.verify|verify} messages.
         * @param message GetTableRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IGetTableRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a GetTableRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns GetTableRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.GetTableRequest;

        /**
         * Decodes a GetTableRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns GetTableRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.GetTableRequest;

        /**
         * Verifies a GetTableRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a GetTableRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns GetTableRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.GetTableRequest;

        /**
         * Creates a plain object from a GetTableRequest message. Also converts values to other types if specified.
         * @param message GetTableRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.GetTableRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this GetTableRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for GetTableRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a DeleteTableRequest. */
    interface IDeleteTableRequest {

        /** DeleteTableRequest target */
        target?: (dataform.ITarget|null);
    }

    /** Represents a DeleteTableRequest. */
    class DeleteTableRequest implements IDeleteTableRequest {

        /**
         * Constructs a new DeleteTableRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IDeleteTableRequest);

        /** DeleteTableRequest target. */
        public target?: (dataform.ITarget|null);

        /**
         * Creates a new DeleteTableRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns DeleteTableRequest instance
         */
        public static create(properties?: dataform.IDeleteTableRequest): dataform.DeleteTableRequest;

        /**
         * Encodes the specified DeleteTableRequest message. Does not implicitly {@link dataform.DeleteTableRequest.verify|verify} messages.
         * @param message DeleteTableRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IDeleteTableRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified DeleteTableRequest message, length delimited. Does not implicitly {@link dataform.DeleteTableRequest.verify|verify} messages.
         * @param message DeleteTableRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IDeleteTableRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a DeleteTableRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns DeleteTableRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.DeleteTableRequest;

        /**
         * Decodes a DeleteTableRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns DeleteTableRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.DeleteTableRequest;

        /**
         * Verifies a DeleteTableRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a DeleteTableRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns DeleteTableRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.DeleteTableRequest;

        /**
         * Creates a plain object from a DeleteTableRequest message. Also converts values to other types if specified.
         * @param message DeleteTableRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.DeleteTableRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this DeleteTableRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for DeleteTableRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a RunningExecutionData. */
    interface IRunningExecutionData {

        /** RunningExecutionData runTargets */
        runTargets?: (dataform.ITarget[]|null);

        /** RunningExecutionData executionId */
        executionId?: (string|null);

        /** RunningExecutionData executionStartTime */
        executionStartTime?: (google.protobuf.ITimestamp|null);
    }

    /** Represents a RunningExecutionData. */
    class RunningExecutionData implements IRunningExecutionData {

        /**
         * Constructs a new RunningExecutionData.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IRunningExecutionData);

        /** RunningExecutionData runTargets. */
        public runTargets: dataform.ITarget[];

        /** RunningExecutionData executionId. */
        public executionId: string;

        /** RunningExecutionData executionStartTime. */
        public executionStartTime?: (google.protobuf.ITimestamp|null);

        /**
         * Creates a new RunningExecutionData instance using the specified properties.
         * @param [properties] Properties to set
         * @returns RunningExecutionData instance
         */
        public static create(properties?: dataform.IRunningExecutionData): dataform.RunningExecutionData;

        /**
         * Encodes the specified RunningExecutionData message. Does not implicitly {@link dataform.RunningExecutionData.verify|verify} messages.
         * @param message RunningExecutionData message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IRunningExecutionData, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified RunningExecutionData message, length delimited. Does not implicitly {@link dataform.RunningExecutionData.verify|verify} messages.
         * @param message RunningExecutionData message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IRunningExecutionData, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a RunningExecutionData message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns RunningExecutionData
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.RunningExecutionData;

        /**
         * Decodes a RunningExecutionData message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns RunningExecutionData
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.RunningExecutionData;

        /**
         * Verifies a RunningExecutionData message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a RunningExecutionData message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns RunningExecutionData
         */
        public static fromObject(object: { [k: string]: any }): dataform.RunningExecutionData;

        /**
         * Creates a plain object from a RunningExecutionData message. Also converts values to other types if specified.
         * @param message RunningExecutionData
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.RunningExecutionData, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this RunningExecutionData to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for RunningExecutionData
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** JitCompilationTargetType enum. */
    enum JitCompilationTargetType {
        JIT_COMPILATION_TARGET_TYPE_UNSPECIFIED = 0,
        JIT_COMPILATION_TARGET_TYPE_TABLE = 1,
        JIT_COMPILATION_TARGET_TYPE_OPERATION = 2,
        JIT_COMPILATION_TARGET_TYPE_INCREMENTAL_TABLE = 3,
        JIT_COMPILATION_TARGET_TYPE_ASSERTION = 4
    }

    /** Properties of a JitCompilationRequest. */
    interface IJitCompilationRequest {

        /** JitCompilationRequest target */
        target?: (dataform.ITarget|null);

        /** JitCompilationRequest dependencies */
        dependencies?: (dataform.ITarget[]|null);

        /** JitCompilationRequest jitCode */
        jitCode?: (string|null);

        /** JitCompilationRequest jitData */
        jitData?: (google.protobuf.IStruct|null);

        /** JitCompilationRequest compilationTargetType */
        compilationTargetType?: (dataform.JitCompilationTargetType|null);

        /** JitCompilationRequest filePaths */
        filePaths?: (string[]|null);

        /** JitCompilationRequest executionData */
        executionData?: (dataform.IRunningExecutionData|null);
    }

    /** Represents a JitCompilationRequest. */
    class JitCompilationRequest implements IJitCompilationRequest {

        /**
         * Constructs a new JitCompilationRequest.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IJitCompilationRequest);

        /** JitCompilationRequest target. */
        public target?: (dataform.ITarget|null);

        /** JitCompilationRequest dependencies. */
        public dependencies: dataform.ITarget[];

        /** JitCompilationRequest jitCode. */
        public jitCode: string;

        /** JitCompilationRequest jitData. */
        public jitData?: (google.protobuf.IStruct|null);

        /** JitCompilationRequest compilationTargetType. */
        public compilationTargetType: dataform.JitCompilationTargetType;

        /** JitCompilationRequest filePaths. */
        public filePaths: string[];

        /** JitCompilationRequest executionData. */
        public executionData?: (dataform.IRunningExecutionData|null);

        /**
         * Creates a new JitCompilationRequest instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JitCompilationRequest instance
         */
        public static create(properties?: dataform.IJitCompilationRequest): dataform.JitCompilationRequest;

        /**
         * Encodes the specified JitCompilationRequest message. Does not implicitly {@link dataform.JitCompilationRequest.verify|verify} messages.
         * @param message JitCompilationRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IJitCompilationRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JitCompilationRequest message, length delimited. Does not implicitly {@link dataform.JitCompilationRequest.verify|verify} messages.
         * @param message JitCompilationRequest message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IJitCompilationRequest, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JitCompilationRequest message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JitCompilationRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.JitCompilationRequest;

        /**
         * Decodes a JitCompilationRequest message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JitCompilationRequest
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.JitCompilationRequest;

        /**
         * Verifies a JitCompilationRequest message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JitCompilationRequest message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JitCompilationRequest
         */
        public static fromObject(object: { [k: string]: any }): dataform.JitCompilationRequest;

        /**
         * Creates a plain object from a JitCompilationRequest message. Also converts values to other types if specified.
         * @param message JitCompilationRequest
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.JitCompilationRequest, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JitCompilationRequest to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for JitCompilationRequest
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a JitCompilationResponse. */
    interface IJitCompilationResponse {

        /** JitCompilationResponse table */
        table?: (dataform.IJitTableResult|null);

        /** JitCompilationResponse operation */
        operation?: (dataform.IJitOperationResult|null);

        /** JitCompilationResponse incrementalTable */
        incrementalTable?: (dataform.IJitIncrementalTableResult|null);

        /** JitCompilationResponse assertion */
        assertion?: (dataform.IJitAssertionResult|null);
    }

    /** Represents a JitCompilationResponse. */
    class JitCompilationResponse implements IJitCompilationResponse {

        /**
         * Constructs a new JitCompilationResponse.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IJitCompilationResponse);

        /** JitCompilationResponse table. */
        public table?: (dataform.IJitTableResult|null);

        /** JitCompilationResponse operation. */
        public operation?: (dataform.IJitOperationResult|null);

        /** JitCompilationResponse incrementalTable. */
        public incrementalTable?: (dataform.IJitIncrementalTableResult|null);

        /** JitCompilationResponse assertion. */
        public assertion?: (dataform.IJitAssertionResult|null);

        /** JitCompilationResponse response. */
        public response?: ("table"|"operation"|"incrementalTable"|"assertion");

        /**
         * Creates a new JitCompilationResponse instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JitCompilationResponse instance
         */
        public static create(properties?: dataform.IJitCompilationResponse): dataform.JitCompilationResponse;

        /**
         * Encodes the specified JitCompilationResponse message. Does not implicitly {@link dataform.JitCompilationResponse.verify|verify} messages.
         * @param message JitCompilationResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IJitCompilationResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JitCompilationResponse message, length delimited. Does not implicitly {@link dataform.JitCompilationResponse.verify|verify} messages.
         * @param message JitCompilationResponse message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IJitCompilationResponse, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JitCompilationResponse message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JitCompilationResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.JitCompilationResponse;

        /**
         * Decodes a JitCompilationResponse message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JitCompilationResponse
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.JitCompilationResponse;

        /**
         * Verifies a JitCompilationResponse message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JitCompilationResponse message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JitCompilationResponse
         */
        public static fromObject(object: { [k: string]: any }): dataform.JitCompilationResponse;

        /**
         * Creates a plain object from a JitCompilationResponse message. Also converts values to other types if specified.
         * @param message JitCompilationResponse
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.JitCompilationResponse, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JitCompilationResponse to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for JitCompilationResponse
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a JitTableResult. */
    interface IJitTableResult {

        /** JitTableResult query */
        query?: (string|null);

        /** JitTableResult preOps */
        preOps?: (string[]|null);

        /** JitTableResult postOps */
        postOps?: (string[]|null);
    }

    /** Represents a JitTableResult. */
    class JitTableResult implements IJitTableResult {

        /**
         * Constructs a new JitTableResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IJitTableResult);

        /** JitTableResult query. */
        public query: string;

        /** JitTableResult preOps. */
        public preOps: string[];

        /** JitTableResult postOps. */
        public postOps: string[];

        /**
         * Creates a new JitTableResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JitTableResult instance
         */
        public static create(properties?: dataform.IJitTableResult): dataform.JitTableResult;

        /**
         * Encodes the specified JitTableResult message. Does not implicitly {@link dataform.JitTableResult.verify|verify} messages.
         * @param message JitTableResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IJitTableResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JitTableResult message, length delimited. Does not implicitly {@link dataform.JitTableResult.verify|verify} messages.
         * @param message JitTableResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IJitTableResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JitTableResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JitTableResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.JitTableResult;

        /**
         * Decodes a JitTableResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JitTableResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.JitTableResult;

        /**
         * Verifies a JitTableResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JitTableResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JitTableResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.JitTableResult;

        /**
         * Creates a plain object from a JitTableResult message. Also converts values to other types if specified.
         * @param message JitTableResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.JitTableResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JitTableResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for JitTableResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a JitIncrementalTableResult. */
    interface IJitIncrementalTableResult {

        /** JitIncrementalTableResult regular */
        regular?: (dataform.IJitTableResult|null);

        /** JitIncrementalTableResult incremental */
        incremental?: (dataform.IJitTableResult|null);
    }

    /** Represents a JitIncrementalTableResult. */
    class JitIncrementalTableResult implements IJitIncrementalTableResult {

        /**
         * Constructs a new JitIncrementalTableResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IJitIncrementalTableResult);

        /** JitIncrementalTableResult regular. */
        public regular?: (dataform.IJitTableResult|null);

        /** JitIncrementalTableResult incremental. */
        public incremental?: (dataform.IJitTableResult|null);

        /**
         * Creates a new JitIncrementalTableResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JitIncrementalTableResult instance
         */
        public static create(properties?: dataform.IJitIncrementalTableResult): dataform.JitIncrementalTableResult;

        /**
         * Encodes the specified JitIncrementalTableResult message. Does not implicitly {@link dataform.JitIncrementalTableResult.verify|verify} messages.
         * @param message JitIncrementalTableResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IJitIncrementalTableResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JitIncrementalTableResult message, length delimited. Does not implicitly {@link dataform.JitIncrementalTableResult.verify|verify} messages.
         * @param message JitIncrementalTableResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IJitIncrementalTableResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JitIncrementalTableResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JitIncrementalTableResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.JitIncrementalTableResult;

        /**
         * Decodes a JitIncrementalTableResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JitIncrementalTableResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.JitIncrementalTableResult;

        /**
         * Verifies a JitIncrementalTableResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JitIncrementalTableResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JitIncrementalTableResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.JitIncrementalTableResult;

        /**
         * Creates a plain object from a JitIncrementalTableResult message. Also converts values to other types if specified.
         * @param message JitIncrementalTableResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.JitIncrementalTableResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JitIncrementalTableResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for JitIncrementalTableResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a JitOperationResult. */
    interface IJitOperationResult {

        /** JitOperationResult queries */
        queries?: (string[]|null);
    }

    /** Represents a JitOperationResult. */
    class JitOperationResult implements IJitOperationResult {

        /**
         * Constructs a new JitOperationResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IJitOperationResult);

        /** JitOperationResult queries. */
        public queries: string[];

        /**
         * Creates a new JitOperationResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JitOperationResult instance
         */
        public static create(properties?: dataform.IJitOperationResult): dataform.JitOperationResult;

        /**
         * Encodes the specified JitOperationResult message. Does not implicitly {@link dataform.JitOperationResult.verify|verify} messages.
         * @param message JitOperationResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IJitOperationResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JitOperationResult message, length delimited. Does not implicitly {@link dataform.JitOperationResult.verify|verify} messages.
         * @param message JitOperationResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IJitOperationResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JitOperationResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JitOperationResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.JitOperationResult;

        /**
         * Decodes a JitOperationResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JitOperationResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.JitOperationResult;

        /**
         * Verifies a JitOperationResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JitOperationResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JitOperationResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.JitOperationResult;

        /**
         * Creates a plain object from a JitOperationResult message. Also converts values to other types if specified.
         * @param message JitOperationResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.JitOperationResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JitOperationResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for JitOperationResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a JitAssertionResult. */
    interface IJitAssertionResult {

        /** JitAssertionResult query */
        query?: (string|null);
    }

    /** Represents a JitAssertionResult. */
    class JitAssertionResult implements IJitAssertionResult {

        /**
         * Constructs a new JitAssertionResult.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IJitAssertionResult);

        /** JitAssertionResult query. */
        public query: string;

        /**
         * Creates a new JitAssertionResult instance using the specified properties.
         * @param [properties] Properties to set
         * @returns JitAssertionResult instance
         */
        public static create(properties?: dataform.IJitAssertionResult): dataform.JitAssertionResult;

        /**
         * Encodes the specified JitAssertionResult message. Does not implicitly {@link dataform.JitAssertionResult.verify|verify} messages.
         * @param message JitAssertionResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IJitAssertionResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified JitAssertionResult message, length delimited. Does not implicitly {@link dataform.JitAssertionResult.verify|verify} messages.
         * @param message JitAssertionResult message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IJitAssertionResult, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a JitAssertionResult message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns JitAssertionResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.JitAssertionResult;

        /**
         * Decodes a JitAssertionResult message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns JitAssertionResult
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.JitAssertionResult;

        /**
         * Verifies a JitAssertionResult message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a JitAssertionResult message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns JitAssertionResult
         */
        public static fromObject(object: { [k: string]: any }): dataform.JitAssertionResult;

        /**
         * Creates a plain object from a JitAssertionResult message. Also converts values to other types if specified.
         * @param message JitAssertionResult
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.JitAssertionResult, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this JitAssertionResult to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for JitAssertionResult
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }

    /** Properties of a BigQuery. */
    interface IBigQuery {

        /** BigQuery projectId */
        projectId?: (string|null);

        /** BigQuery credentials */
        credentials?: (string|null);

        /** BigQuery location */
        location?: (string|null);
    }

    /** Represents a BigQuery. */
    class BigQuery implements IBigQuery {

        /**
         * Constructs a new BigQuery.
         * @param [properties] Properties to set
         */
        constructor(properties?: dataform.IBigQuery);

        /** BigQuery projectId. */
        public projectId: string;

        /** BigQuery credentials. */
        public credentials: string;

        /** BigQuery location. */
        public location: string;

        /**
         * Creates a new BigQuery instance using the specified properties.
         * @param [properties] Properties to set
         * @returns BigQuery instance
         */
        public static create(properties?: dataform.IBigQuery): dataform.BigQuery;

        /**
         * Encodes the specified BigQuery message. Does not implicitly {@link dataform.BigQuery.verify|verify} messages.
         * @param message BigQuery message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encode(message: dataform.IBigQuery, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Encodes the specified BigQuery message, length delimited. Does not implicitly {@link dataform.BigQuery.verify|verify} messages.
         * @param message BigQuery message or plain object to encode
         * @param [writer] Writer to encode to
         * @returns Writer
         */
        public static encodeDelimited(message: dataform.IBigQuery, writer?: $protobuf.Writer): $protobuf.Writer;

        /**
         * Decodes a BigQuery message from the specified reader or buffer.
         * @param reader Reader or buffer to decode from
         * @param [length] Message length if known beforehand
         * @returns BigQuery
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): dataform.BigQuery;

        /**
         * Decodes a BigQuery message from the specified reader or buffer, length delimited.
         * @param reader Reader or buffer to decode from
         * @returns BigQuery
         * @throws {Error} If the payload is not a reader or valid buffer
         * @throws {$protobuf.util.ProtocolError} If required fields are missing
         */
        public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): dataform.BigQuery;

        /**
         * Verifies a BigQuery message.
         * @param message Plain object to verify
         * @returns `null` if valid, otherwise the reason why it is not
         */
        public static verify(message: { [k: string]: any }): (string|null);

        /**
         * Creates a BigQuery message from a plain object. Also converts values to their respective internal types.
         * @param object Plain object
         * @returns BigQuery
         */
        public static fromObject(object: { [k: string]: any }): dataform.BigQuery;

        /**
         * Creates a plain object from a BigQuery message. Also converts values to other types if specified.
         * @param message BigQuery
         * @param [options] Conversion options
         * @returns Plain object
         */
        public static toObject(message: dataform.BigQuery, options?: $protobuf.IConversionOptions): { [k: string]: any };

        /**
         * Converts this BigQuery to JSON.
         * @returns JSON object
         */
        public toJSON(): { [k: string]: any };

        /**
         * Gets the default type url for BigQuery
         * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
         * @returns The default type url
         */
        public static getTypeUrl(typeUrlPrefix?: string): string;
    }
}

/** Namespace google. */
namespace google {

    /** Namespace protobuf. */
    namespace protobuf {

        /** Properties of a Struct. */
        interface IStruct {

            /** Struct fields */
            fields?: ({ [k: string]: google.protobuf.IValue }|null);
        }

        /** Represents a Struct. */
        class Struct implements IStruct {

            /**
             * Constructs a new Struct.
             * @param [properties] Properties to set
             */
            constructor(properties?: google.protobuf.IStruct);

            /** Struct fields. */
            public fields: { [k: string]: google.protobuf.IValue };

            /**
             * Creates a new Struct instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Struct instance
             */
            public static create(properties?: google.protobuf.IStruct): google.protobuf.Struct;

            /**
             * Encodes the specified Struct message. Does not implicitly {@link google.protobuf.Struct.verify|verify} messages.
             * @param message Struct message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: google.protobuf.IStruct, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified Struct message, length delimited. Does not implicitly {@link google.protobuf.Struct.verify|verify} messages.
             * @param message Struct message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: google.protobuf.IStruct, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a Struct message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Struct
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): google.protobuf.Struct;

            /**
             * Decodes a Struct message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Struct
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): google.protobuf.Struct;

            /**
             * Verifies a Struct message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Struct message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Struct
             */
            public static fromObject(object: { [k: string]: any }): google.protobuf.Struct;

            /**
             * Creates a plain object from a Struct message. Also converts values to other types if specified.
             * @param message Struct
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: google.protobuf.Struct, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Struct to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for Struct
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a Value. */
        interface IValue {

            /** Value nullValue */
            nullValue?: (google.protobuf.NullValue|null);

            /** Value numberValue */
            numberValue?: (number|null);

            /** Value stringValue */
            stringValue?: (string|null);

            /** Value boolValue */
            boolValue?: (boolean|null);

            /** Value structValue */
            structValue?: (google.protobuf.IStruct|null);

            /** Value listValue */
            listValue?: (google.protobuf.IListValue|null);
        }

        /** Represents a Value. */
        class Value implements IValue {

            /**
             * Constructs a new Value.
             * @param [properties] Properties to set
             */
            constructor(properties?: google.protobuf.IValue);

            /** Value nullValue. */
            public nullValue?: (google.protobuf.NullValue|null);

            /** Value numberValue. */
            public numberValue?: (number|null);

            /** Value stringValue. */
            public stringValue?: (string|null);

            /** Value boolValue. */
            public boolValue?: (boolean|null);

            /** Value structValue. */
            public structValue?: (google.protobuf.IStruct|null);

            /** Value listValue. */
            public listValue?: (google.protobuf.IListValue|null);

            /** Value kind. */
            public kind?: ("nullValue"|"numberValue"|"stringValue"|"boolValue"|"structValue"|"listValue");

            /**
             * Creates a new Value instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Value instance
             */
            public static create(properties?: google.protobuf.IValue): google.protobuf.Value;

            /**
             * Encodes the specified Value message. Does not implicitly {@link google.protobuf.Value.verify|verify} messages.
             * @param message Value message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: google.protobuf.IValue, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified Value message, length delimited. Does not implicitly {@link google.protobuf.Value.verify|verify} messages.
             * @param message Value message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: google.protobuf.IValue, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a Value message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Value
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): google.protobuf.Value;

            /**
             * Decodes a Value message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Value
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): google.protobuf.Value;

            /**
             * Verifies a Value message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Value message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Value
             */
            public static fromObject(object: { [k: string]: any }): google.protobuf.Value;

            /**
             * Creates a plain object from a Value message. Also converts values to other types if specified.
             * @param message Value
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: google.protobuf.Value, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Value to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for Value
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** NullValue enum. */
        enum NullValue {
            NULL_VALUE = 0
        }

        /** Properties of a ListValue. */
        interface IListValue {

            /** ListValue values */
            values?: (google.protobuf.IValue[]|null);
        }

        /** Represents a ListValue. */
        class ListValue implements IListValue {

            /**
             * Constructs a new ListValue.
             * @param [properties] Properties to set
             */
            constructor(properties?: google.protobuf.IListValue);

            /** ListValue values. */
            public values: google.protobuf.IValue[];

            /**
             * Creates a new ListValue instance using the specified properties.
             * @param [properties] Properties to set
             * @returns ListValue instance
             */
            public static create(properties?: google.protobuf.IListValue): google.protobuf.ListValue;

            /**
             * Encodes the specified ListValue message. Does not implicitly {@link google.protobuf.ListValue.verify|verify} messages.
             * @param message ListValue message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: google.protobuf.IListValue, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified ListValue message, length delimited. Does not implicitly {@link google.protobuf.ListValue.verify|verify} messages.
             * @param message ListValue message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: google.protobuf.IListValue, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a ListValue message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns ListValue
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): google.protobuf.ListValue;

            /**
             * Decodes a ListValue message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns ListValue
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): google.protobuf.ListValue;

            /**
             * Verifies a ListValue message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a ListValue message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns ListValue
             */
            public static fromObject(object: { [k: string]: any }): google.protobuf.ListValue;

            /**
             * Creates a plain object from a ListValue message. Also converts values to other types if specified.
             * @param message ListValue
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: google.protobuf.ListValue, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this ListValue to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for ListValue
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of an Empty. */
        interface IEmpty {
        }

        /** Represents an Empty. */
        class Empty implements IEmpty {

            /**
             * Constructs a new Empty.
             * @param [properties] Properties to set
             */
            constructor(properties?: google.protobuf.IEmpty);

            /**
             * Creates a new Empty instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Empty instance
             */
            public static create(properties?: google.protobuf.IEmpty): google.protobuf.Empty;

            /**
             * Encodes the specified Empty message. Does not implicitly {@link google.protobuf.Empty.verify|verify} messages.
             * @param message Empty message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: google.protobuf.IEmpty, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified Empty message, length delimited. Does not implicitly {@link google.protobuf.Empty.verify|verify} messages.
             * @param message Empty message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: google.protobuf.IEmpty, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes an Empty message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Empty
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): google.protobuf.Empty;

            /**
             * Decodes an Empty message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Empty
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): google.protobuf.Empty;

            /**
             * Verifies an Empty message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates an Empty message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Empty
             */
            public static fromObject(object: { [k: string]: any }): google.protobuf.Empty;

            /**
             * Creates a plain object from an Empty message. Also converts values to other types if specified.
             * @param message Empty
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: google.protobuf.Empty, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Empty to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for Empty
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }

        /** Properties of a Timestamp. */
        interface ITimestamp {

            /** Timestamp seconds */
            seconds?: (Long|null);

            /** Timestamp nanos */
            nanos?: (number|null);
        }

        /** Represents a Timestamp. */
        class Timestamp implements ITimestamp {

            /**
             * Constructs a new Timestamp.
             * @param [properties] Properties to set
             */
            constructor(properties?: google.protobuf.ITimestamp);

            /** Timestamp seconds. */
            public seconds: Long;

            /** Timestamp nanos. */
            public nanos: number;

            /**
             * Creates a new Timestamp instance using the specified properties.
             * @param [properties] Properties to set
             * @returns Timestamp instance
             */
            public static create(properties?: google.protobuf.ITimestamp): google.protobuf.Timestamp;

            /**
             * Encodes the specified Timestamp message. Does not implicitly {@link google.protobuf.Timestamp.verify|verify} messages.
             * @param message Timestamp message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encode(message: google.protobuf.ITimestamp, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Encodes the specified Timestamp message, length delimited. Does not implicitly {@link google.protobuf.Timestamp.verify|verify} messages.
             * @param message Timestamp message or plain object to encode
             * @param [writer] Writer to encode to
             * @returns Writer
             */
            public static encodeDelimited(message: google.protobuf.ITimestamp, writer?: $protobuf.Writer): $protobuf.Writer;

            /**
             * Decodes a Timestamp message from the specified reader or buffer.
             * @param reader Reader or buffer to decode from
             * @param [length] Message length if known beforehand
             * @returns Timestamp
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decode(reader: ($protobuf.Reader|Uint8Array), length?: number): google.protobuf.Timestamp;

            /**
             * Decodes a Timestamp message from the specified reader or buffer, length delimited.
             * @param reader Reader or buffer to decode from
             * @returns Timestamp
             * @throws {Error} If the payload is not a reader or valid buffer
             * @throws {$protobuf.util.ProtocolError} If required fields are missing
             */
            public static decodeDelimited(reader: ($protobuf.Reader|Uint8Array)): google.protobuf.Timestamp;

            /**
             * Verifies a Timestamp message.
             * @param message Plain object to verify
             * @returns `null` if valid, otherwise the reason why it is not
             */
            public static verify(message: { [k: string]: any }): (string|null);

            /**
             * Creates a Timestamp message from a plain object. Also converts values to their respective internal types.
             * @param object Plain object
             * @returns Timestamp
             */
            public static fromObject(object: { [k: string]: any }): google.protobuf.Timestamp;

            /**
             * Creates a plain object from a Timestamp message. Also converts values to other types if specified.
             * @param message Timestamp
             * @param [options] Conversion options
             * @returns Plain object
             */
            public static toObject(message: google.protobuf.Timestamp, options?: $protobuf.IConversionOptions): { [k: string]: any };

            /**
             * Converts this Timestamp to JSON.
             * @returns JSON object
             */
            public toJSON(): { [k: string]: any };

            /**
             * Gets the default type url for Timestamp
             * @param [typeUrlPrefix] your custom typeUrlPrefix(default "type.googleapis.com")
             * @returns The default type url
             */
            public static getTypeUrl(typeUrlPrefix?: string): string;
        }
    }
}

declare type Resolvable = string | dataform.ITarget;
declare type Contextable<Context, T> = T | ((ctx: Context) => T);
interface IActionContext {
    self: () => string;
    name: () => string;
    ref: (ref: Resolvable | string[], ...rest: string[]) => string;
    resolve: (ref: Resolvable | string[], ...rest: string[]) => string;
    schema: () => string;
    database: () => string;
}
interface ITableContext extends IActionContext {
    when: (cond: boolean, trueCase: string, falseCase?: string) => string;
    incremental: () => boolean;
}
declare type JitContext<T> = T & {
    adapter: dataform.DbAdapter;
    data?: {
        [k: string]: any;
    };
    request: dataform.IJitCompilationRequest;
    executionData: dataform.IRunningExecutionData;
};
declare type JitContextable<Context, T> = string | ((jctx: JitContext<Context>) => Promise<T>);

declare type AContextable<T> = T | ((ctx: AssertionContext) => T);
declare type JitAssertionResult = string;
declare class Assertion extends ActionBuilder<dataform.Assertion> {
    session: Session;
    private proto;
    private contextableQuery;
    private contextableJitCode;
    constructor(session?: Session, unverifiedConfig?: any, configPath?: string);
    query(query: AContextable<string>): this;
    jitCode(jitCode: JitContextable<AssertionContext, JitAssertionResult>): this;
    dependencies(value: Resolvable | Resolvable[]): this;
    hermetic(hermetic: boolean): void;
    disabled(disabled?: boolean): this;
    tags(value: string | string[]): this;
    description(description: string): this;
    database(database: string): this;
    schema(schema: string): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    getParentAction(): dataform.Target;
    setParentAction(target: dataform.Target): void;
    compile(): dataform.Assertion;
    private verifyConfig;
}
declare class AssertionContext implements IActionContext {
    private assertion?;
    constructor(assertion: Assertion);
    self(): string;
    name(): string;
    ref(ref: Resolvable | string[], ...rest: string[]): string;
    resolve(ref: Resolvable | string[], ...rest: string[]): string;
    schema(): string;
    database(): string;
    dependencies(name: Resolvable | Resolvable[]): string;
    tags(name: string | string[]): string;
    when(cond: boolean, trueCase: string, falseCase?: string): string;
    apply<T>(value: AContextable<T>): T;
}

declare class DataPreparation extends ActionBuilder<dataform.DataPreparation> {
    session: Session;
    contextableQuery: Contextable<ITableContext, string>;
    private proto;
    constructor(session?: Session, config?: dataform.ActionConfig.DataPreparationConfig, configPath?: string);
    config(config: any): this;
    query(query: Contextable<ITableContext, string>): this;
    dependencies(value: Resolvable | Resolvable[]): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    compile(): dataform.DataPreparation;
    database(database: string): this;
    schema(schema: string): this;
    private configureYamlWithoutTargets;
    private configureYamlWithTargets;
    private applySessionToDataPreparationContents;
    private applySessionToTableReference;
    private getTargets;
    private configureYaml;
    private configureSqlx;
    private mapLoadMode;
    private validateLoadModeColumnName;
    private validateUniqueKey;
}
declare class DataPreparationContext implements ITableContext {
    private dataPreparation;
    private isIncremental;
    EXPECT: string;
    constructor(dataPreparation: DataPreparation, isIncremental?: boolean);
    config(config: dataform.ActionConfig.DataPreparationConfig): string;
    self(): string;
    name(): string;
    ref(ref: Resolvable | string[], ...rest: string[]): string;
    resolve(ref: Resolvable | string[], ...rest: string[]): string;
    schema(): string;
    database(): string;
    when(cond: boolean, trueCase: string, falseCase?: string): string;
    incremental(): boolean;
    dependencies(res: Resolvable): string;
    apply<T>(value: Contextable<ITableContext, T>): T;
}

declare class Declaration extends ActionBuilder<dataform.Declaration> {
    session: Session;
    private proto;
    constructor(session?: Session, unverifiedConfig?: any, filename?: string);
    description(description: string): this;
    columns(columns: dataform.ActionConfig.ColumnDescriptor[]): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    compile(): dataform.Declaration;
    private verifyConfig;
}

declare type JitTableResult = string | dataform.IJitTableResult;
declare class Table extends ActionBuilder<dataform.Table> {
    session: Session;
    dependOnDependencyAssertions: boolean;
    contextableQuery: Contextable<ITableContext, string>;
    private contextableWhere;
    private contextableJitCode;
    private contextablePreOps;
    private contextablePostOps;
    private proto;
    private uniqueKeyAssertions;
    private rowConditionsAssertion;
    private unverifiedConfig;
    private configPath;
    constructor(session?: Session, unverifiedConfig?: any, configPath?: string);
    type(type: TableType): this;
    query(query: Contextable<ITableContext, string>): this;
    where(where: Contextable<ITableContext, string>): this;
    jitCode(jitCode: JitContextable<ITableContext, JitTableResult>): this;
    preOps(pres: Contextable<ITableContext, string | string[]>): this;
    postOps(posts: Contextable<ITableContext, string | string[]>): this;
    disabled(disabled?: boolean): this;
    bigquery(bigquery: dataform.IBigQueryOptions): this;
    dependencies(value: Resolvable | Resolvable[]): this;
    hermetic(hermetic: boolean): void;
    tags(value: string | string[]): this;
    description(description: string): this;
    columns(columns: dataform.ActionConfig.ColumnDescriptor[]): this;
    database(database: string): this;
    schema(schema: string): this;
    assertions(tableAssertionsConfig: dataform.ActionConfig.TableAssertionsConfig): Table;
    setDependOnDependencyAssertions(dependOnDependencyAssertions: boolean): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    compile(): dataform.Table;
    private compileJit;
    private compileAot;
    private contextifyOps;
    private verifyConfig;
}
declare class TableContext implements ITableContext {
    private table;
    private isIncremental;
    constructor(table: Table, isIncremental?: boolean);
    self(): string;
    name(): string;
    ref(ref: Resolvable | string[], ...rest: string[]): string;
    resolve(ref: Resolvable | string[], ...rest: string[]): string;
    schema(): string;
    database(): string;
    type(type: TableType): string;
    where(where: Contextable<ITableContext, string>): string;
    when(cond: boolean, trueCase: string, falseCase?: string): string;
    incremental(): boolean;
    preOps(statement: Contextable<ITableContext, string | string[]>): string;
    postOps(statement: Contextable<ITableContext, string | string[]>): string;
    disabled(): string;
    bigquery(bigquery: dataform.IBigQueryOptions): string;
    dependencies(res: Resolvable): string;
    apply<T>(value: Contextable<ITableContext, T>): T;
    tags(tags: string[]): string;
}

declare class IncrementalTable extends ActionBuilder<dataform.Table> {
    session: Session;
    dependOnDependencyAssertions: boolean;
    contextableQuery: Contextable<ITableContext, string>;
    private contextableWhere;
    private contextableJitCode;
    private contextablePreOps;
    private contextablePostOps;
    private proto;
    private uniqueKeyAssertions;
    private rowConditionsAssertion;
    private unverifiedConfig;
    private configPath;
    constructor(session?: Session, unverifiedConfig?: any, configPath?: string);
    type(type: TableType): this;
    query(query: Contextable<ITableContext, string>): this;
    where(where: Contextable<ITableContext, string>): this;
    jitCode(jitCode: JitContextable<ITableContext, JitTableResult>): this;
    preOps(pres: Contextable<ITableContext, string | string[]>): this;
    postOps(posts: Contextable<ITableContext, string | string[]>): this;
    disabled(disabled?: boolean): this;
    protected(isProtected: boolean): this;
    uniqueKey(uniqueKey: string[]): void;
    bigquery(bigquery: dataform.IBigQueryOptions): this;
    dependencies(value: Resolvable | Resolvable[]): this;
    hermetic(hermetic: boolean): void;
    tags(value: string | string[]): this;
    description(description: string): this;
    columns(columns: dataform.ActionConfig.ColumnDescriptor[]): this;
    database(database: string): this;
    schema(schema: string): this;
    assertions(tableAssertionsConfig: dataform.ActionConfig.TableAssertionsConfig): IncrementalTable;
    setDependOnDependencyAssertions(dependOnDependencyAssertions: boolean): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    compile(): dataform.Table;
    private compileJit;
    private compileAot;
    private contextifyOps;
    private verifyConfig;
    private mapOnSchemaChange;
}

declare class Notebook extends ActionBuilder<dataform.Notebook> {
    session: Session;
    dependOnDependencyAssertions: boolean;
    private proto;
    constructor(session?: Session, unverifiedConfig?: any, configPath?: string);
    ipynb(contents: object): Notebook;
    dependencies(value: Resolvable | Resolvable[]): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    compile(): dataform.Notebook;
    private verifyConfig;
}

declare type JitOperationResult = string | string[] | dataform.IJitOperationResult;
declare class Operation extends ActionBuilder<dataform.Operation> {
    session: Session;
    dependOnDependencyAssertions: boolean;
    private proto;
    private contextableQueries;
    private contextableJitCode;
    constructor(session?: Session, unverifiedConfig?: any, configPath?: string);
    queries(queries: Contextable<IActionContext, string | string[]>): this;
    jitCode(jitCode: JitContextable<IActionContext, JitOperationResult>): this;
    dependencies(value: Resolvable | Resolvable[]): this;
    hermetic(hermetic: boolean): void;
    disabled(disabled?: boolean): this;
    tags(value: string | string[]): this;
    hasOutput(hasOutput: boolean): this;
    description(description: string): this;
    columns(columns: dataform.ActionConfig.ColumnDescriptor[]): this;
    database(database: string): this;
    schema(schema: string): this;
    setDependOnDependencyAssertions(dependOnDependencyAssertions: boolean): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    getHasOutput(): boolean;
    compile(): dataform.Operation;
    private compileJit;
    private verifyConfig;
}
declare class OperationContext implements IActionContext {
    private operation?;
    constructor(operation: Operation);
    self(): string;
    name(): string;
    ref(ref: Resolvable | string[], ...rest: string[]): string;
    resolve(ref: Resolvable | string[], ...rest: string[]): string;
    schema(): string;
    database(): string;
    dependencies(name: Resolvable | Resolvable[]): string;
    tags(name: string | string[]): string;
    hasOutput(hasOutput: boolean): string;
    when(cond: boolean, trueCase: string, falseCase?: string): string;
    apply<T>(value: Contextable<IActionContext, T>): T;
}

interface ITestConfig extends INamedConfig {
    dataset?: Resolvable;
    name?: string;
    filename?: string;
    tags?: string[];
}
declare class Test extends ActionBuilder<dataform.Test> {
    session: Session;
    contextableInputs: Map<string, Contextable<IActionContext, string>>;
    private contextableQuery;
    private testTarget;
    private proto;
    constructor(session?: Session, config?: ITestConfig);
    config(config: ITestConfig): this;
    dataset(ref: Resolvable): this;
    input(refName: string | string[], contextableQuery: Contextable<IActionContext, string>): this;
    expect(contextableQuery: Contextable<IActionContext, string>): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    getTestTarget(): dataform.Target;
    setFilename(filename: string): void;
    compile(): dataform.Test;
}

declare type JitViewResult = string | dataform.IJitTableResult;
declare class View extends ActionBuilder<dataform.Table> {
    session: Session;
    dependOnDependencyAssertions: boolean;
    contextableQuery: Contextable<ITableContext, string>;
    private contextableWhere;
    private contextableJitCode;
    private contextablePreOps;
    private contextablePostOps;
    private proto;
    private uniqueKeyAssertions;
    private rowConditionsAssertion;
    private unverifiedConfig;
    private configPath;
    constructor(session?: Session, unverifiedConfig?: any, configPath?: string);
    type(type: TableType): this;
    query(query: Contextable<ITableContext, string>): this;
    where(where: Contextable<ITableContext, string>): this;
    preOps(pres: Contextable<ITableContext, string | string[]>): this;
    postOps(posts: Contextable<ITableContext, string | string[]>): this;
    disabled(disabled?: boolean): this;
    materialized(materialized: boolean): void;
    bigquery(bigquery: dataform.IBigQueryOptions): this;
    dependencies(value: Resolvable | Resolvable[]): this;
    hermetic(hermetic: boolean): void;
    tags(value: string | string[]): this;
    description(description: string): this;
    columns(columns: dataform.ActionConfig.ColumnDescriptor[]): this;
    database(database: string): this;
    schema(schema: string): this;
    assertions(tableAssertionsConfig: dataform.ActionConfig.TableAssertionsConfig): View;
    setDependOnDependencyAssertions(dependOnDependencyAssertions: boolean): this;
    jitCode(jitCode: JitContextable<ITableContext, JitViewResult>): this;
    getFileName(): string;
    getTarget(): dataform.Target;
    compile(): dataform.Table;
    private compileJit;
    private compileAot;
    private contextifyOps;
    private verifyConfig;
}

interface IColumnsDescriptor {
    [name: string]: string | IRecordDescriptor;
}
interface IRecordDescriptor {
    description?: string;
    columns?: IColumnsDescriptor;
    displayName?: string;
    tags?: string | string[];
    bigqueryPolicyTags?: string | string[];
}

declare type Action = Table | View | IncrementalTable | Operation | Assertion | Declaration | Notebook | DataPreparation | Test;
declare abstract class ActionBuilder<T> {
    session: Session;
    includeAssertionsForDependency: Map<string, boolean>;
    constructor(session?: Session);
    applySessionToTarget(targetFromConfig: dataform.Target, projectConfig: dataform.ProjectConfig, fileName?: string, options?: {
        validateTarget?: boolean;
        useDefaultAssertionDataset?: boolean;
    }): dataform.Target;
    finalizeTarget(targetFromConfig: dataform.Target): dataform.Target;
    abstract getFileName(): string;
    abstract getTarget(): dataform.Target;
    abstract compile(): T;
    protected generateInlineAssertions(tableAssertionsConfig: dataform.ActionConfig.TableAssertionsConfig, proto: dataform.Table): {
        uniqueKeyAssertions: Assertion[];
        rowConditionsAssertion?: Assertion;
    };
    private validateTarget;
}
interface INamedConfig {
    type?: string;
    name?: string;
}
interface IActionConfig {
    tags?: string[];
    dependencies?: Resolvable | Resolvable[];
    disabled?: boolean;
}
interface ITargetableConfig {
    database?: string;
    schema?: string;
}
interface IDependenciesConfig {
    dependencies?: Resolvable | Resolvable[];
    hermetic?: boolean;
    dependOnDependencyAssertions?: boolean;
}
interface IDocumentableConfig {
    columns?: IColumnsDescriptor;
    description?: string;
}
declare type TableType = typeof TableType[number];
declare const TableType: readonly ["table", "view", "incremental"];
interface ILegacyTableConfig extends IActionConfig, IDependenciesConfig, IDocumentableConfig, INamedConfig, ITargetableConfig {
    type?: TableType;
    protected?: boolean;
    bigquery?: ILegacyBigQueryOptions;
    assertions?: ILegacyTableAssertions;
    uniqueKey?: string[];
    materialized?: boolean;
}
interface ILegacyBigQueryOptions {
    partitionBy?: string;
    clusterBy?: string[];
    updatePartitionFilter?: string;
    labels?: {
        [name: string]: string;
    };
    partitionExpirationDays?: number;
    requirePartitionFilter?: boolean;
    additionalOptions?: {
        [name: string]: string;
    };
    iceberg?: {
        fileFormat?: string;
        tableFormat?: string;
        connection?: string;
        bucketName?: string;
        tableFolderRoot?: string;
        tableFolderSubpath?: string;
    };
}
interface ILegacyTableAssertions {
    uniqueKey?: string | string[];
    uniqueKeys?: string[][];
    nonNull?: string | string[];
    rowConditions?: string[];
}

declare class CompilationSql {
    private readonly project;
    private readonly dataformCoreVersion;
    constructor(project: dataform.IProjectConfig, dataformCoreVersion: string);
    resolveTarget(target: dataform.ITarget): string;
    sqlString(stringContents: string): string;
    indexAssertion(dataset: string, indexCols: string[]): string;
    rowConditionsAssertion(dataset: string, rowConditions: string[]): string;
}

declare class ResolvableMap<T> {
    private byName;
    private bySchemaAndName;
    private byDatabaseAndName;
    private byDatabaseSchemaAndName;
    constructor(values?: Array<{
        actionTarget: dataform.ITarget;
        value: T;
    }>);
    set(actionTarget: dataform.ITarget, value: T): void;
    find(actionTarget: dataform.ITarget): T[];
    private setByNameLevel;
    private setBySchemaLevel;
}

declare class Session {
    rootDir: string;
    projectConfig: dataform.ProjectConfig;
    canonicalProjectConfig: dataform.ProjectConfig;
    actions: Action[];
    indexedActions: ResolvableMap<Action>;
    tests: Action[];
    actionAssertionMap: ResolvableMap<Action>;
    graphErrors: dataform.IGraphErrors;
    jitContextData: google.protobuf.Struct | undefined;
    constructor(rootDir?: string, projectConfig?: dataform.ProjectConfig, originalProjectConfig?: dataform.ProjectConfig);
    init(rootDir: string, projectConfig?: dataform.ProjectConfig, originalProjectConfig?: dataform.ProjectConfig): void;
    compilationSql(): CompilationSql;
    sqlxAction(actionOptions: {
        sqlxConfig: any;
        sqlStatementCount: number;
        sqlContextable: (ctx: TableContext | AssertionContext | OperationContext | DataPreparationContext | IActionContext) => string[];
        incrementalWhereContextable: (ctx: ITableContext) => string;
        preOperationsContextable: (ctx: ITableContext) => string[];
        postOperationsContextable: (ctx: ITableContext) => string[];
        inputContextables: [{
            refName: string[];
            contextable: (ctx: IActionContext) => string;
        }];
    }): void;
    resolve(ref: Resolvable | string[], ...rest: string[]): string;
    operate(name: string, queryOrConfig?: Contextable<IActionContext, string | string[]> | dataform.ActionConfig.OperationConfig): Operation;
    publish(name: string, queryOrConfig?: Contextable<ITableContext, string> | dataform.ActionConfig.TableConfig | dataform.ActionConfig.ViewConfig | dataform.ActionConfig.IncrementalTableConfig | ILegacyTableConfig | any): Table | IncrementalTable | View;
    assert(name: string, queryOrConfig?: AContextable<string> | dataform.ActionConfig.AssertionConfig): Assertion;
    declare(config: dataform.ActionConfig.DeclarationConfig | any): Declaration;
    test(name: string): Test;
    notebook(config: dataform.ActionConfig.NotebookConfig): Notebook;
    jitData(key: string, data: unknown): void;
    compileError(err: Error | string, path?: string, actionTarget?: dataform.ITarget): void;
    compile(): dataform.CompiledGraph;
    compileToBase64(): string;
    finalizeDatabase(database: string): string;
    finalizeSchema(schema: string): string;
    finalizeName(name: string): string;
    private getDatabaseSuffixWithUnderscore;
    private getSchemaSuffixWithUnderscore;
    private getTablePrefixWithUnderscore;
    private compileGraphChunk;
    private fullyQualifyDependencies;
    private alterActionName;
    private checkTestNameUniqueness;
    private checkCircularity;
    private addTestsToCompiledGraph;
    private removeNonUniqueActionsFromCompiledGraph;
}

interface IDataformExtension {
    compile(request: dataform.ICompileExecutionRequest, session: Session): void;
}

interface IJitCompiler {
    compile: (request: Uint8Array) => Promise<Uint8Array>;
}
declare type RpcCallback = (method: string, request: Uint8Array, callback: (error: Error | null, response: Uint8Array) => void) => void;
declare function jitCompiler(rpcCallback: RpcCallback): IJitCompiler;

declare function main(coreExecutionRequest: Uint8Array | string): Uint8Array | string;

declare const version = "3.0.59";

declare const session: Session;
declare const supportedFeatures: dataform.SupportedFeatures[];
declare function indexFileGenerator(): void;

export { IDataformExtension, IJitCompiler, compile as compiler, indexFileGenerator, jitCompiler, main, session, supportedFeatures, version };
